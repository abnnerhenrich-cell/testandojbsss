__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _views_layout_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/views/layout/header */ "./src/views/layout/header.vue");
/* harmony import */ var _views_layout_nav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/views/layout/nav */ "./src/views/layout/nav.vue");
/* harmony import */ var _views_layout_menuFooter_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/views/layout/menuFooter.vue */ "./src/views/layout/menuFooter.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _core_service_firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/core/service/firebase */ "./src/core/service/firebase.js");
/* harmony import */ var _views_layout_manutencao_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/views/layout/manutencao.vue */ "./src/views/layout/manutencao.vue");
/* harmony import */ var _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/loader.vue */ "./src/components/loader.vue");








// import Raspadinha from '@/views/raspadinha/initRaspadinha.vue'
// import modalJogoResponsavel from '@/views/produtos/components/modalJogoResponsavel.vue'
// import ModalLogin from '@/views/auth/components/modalLogin.vue'
// import ModalCadastro from '@/views/auth/components/modalCadastro.vue'
// import ModalRecuperarSenha from '@/views/auth/components/modalRecuperarSenha.vue'



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'INIT',
  components: {
    topMenu: _views_layout_header__WEBPACK_IMPORTED_MODULE_0__["default"],
    Menu: _views_layout_nav__WEBPACK_IMPORTED_MODULE_1__["default"],
    MenuFooter: _views_layout_menuFooter_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    // Raspadinha,
    siteManutencao: _views_layout_manutencao_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    viewLoader: _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    // modalJogoResponsavel,
    ModalLogin: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("src_views_auth_components_modalLogin_vue"), __webpack_require__.e("node_modules_vue-recaptcha_dist_vue-recaptcha_es_js")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/modalLogin.vue */ "./src/views/auth/components/modalLogin.vue"))),
    ModalCadastro: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("src_views_auth_components_modalCadastro_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/modalCadastro.vue */ "./src/views/auth/components/modalCadastro.vue"))),
    ModalRecuperarSenha: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("src_views_auth_components_modalRecuperarSenha_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/modalRecuperarSenha.vue */ "./src/views/auth/components/modalRecuperarSenha.vue"))),
    ModalCarrinho: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("src_components_currency_vue"), __webpack_require__.e("src_components_modalCarrinho_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/components/modalCarrinho.vue */ "./src/components/modalCarrinho.vue"))),
    ModalTermoUso: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("src_views_auth_components_modalTermoUso_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/modalTermoUso.vue */ "./src/views/auth/components/modalTermoUso.vue"))),
    btnAjuda: (0,vue__WEBPACK_IMPORTED_MODULE_3__.defineAsyncComponent)(() => __webpack_require__.e(/*! import() */ "src_components_btnAjuda_vue").then(__webpack_require__.bind(__webpack_require__, /*! @/components/btnAjuda */ "./src/components/btnAjuda.vue")))
  },
  setup() {
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_9__.useStore)();
    const carrinho = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const menu = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => store.state.menu);
    const user = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => store.getters['login/getUser']);
    const route = (0,vue_router__WEBPACK_IMPORTED_MODULE_10__.useRoute)();
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const loader = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const showCadastro = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const showLogin = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const showRecuperarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const showTermoUso = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const optionsLocation = {
      enableHighAccuracy: true,
      timeout: 10000 * 20,
      maximumAge: 0
    };
    const iframeCartelas = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => {
      const show = ['/cartelas', '/cartelas2'];
      return show.indexOf(route.path) !== -1;
    });
    const exiCertificado = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => {
      const show = ['/', '/home'];
      return show.indexOf(route.path) !== -1;
    });

    /* Raspadinha ativada tem que iniciar o canvas dela e deixar tudo desabilitado */
    // const showRaspadinha = computed(() => store.state.raspadinha.animacao)
    const vversion = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => store.getters['_getVersion']);
    const plataformaAtiva = (0,vue__WEBPACK_IMPORTED_MODULE_3__.computed)(() => store.getters['login/telefoneSuporte']);
    const showJogoResponsavel = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_3__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const watchPositionGPS = () => navigator.geolocation.watchPosition(successPosition, failurePosition, optionsLocation);
    const getCurrentPositionGPS = () => {
      navigator.geolocation.getCurrentPosition(successPosition, failurePosition, optionsLocation);
    };
    const successPosition = position => {
      if (!user.value.id) return;
      const {
        accuracy,
        altitude,
        altitudeAccuracy,
        heading,
        latitude,
        longitude,
        speed
      } = position.coords;
      const dados = {
        accuracy,
        altitude,
        altitudeAccuracy,
        heading,
        latitude,
        longitude,
        speed
      };
      // store.dispatch('login/addPositions', { accuracy, altitude, altitudeAccuracy, heading, latitude, longitude, speed })
      if (position.coords) _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].set('gps', dados);
    };
    const failurePosition = err => {
      console.log('err', err);
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_3__.onMounted)(async () => {
      _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].remove('gps'); // remover posicao de sessao

      setTimeout(() => {
        // certificado
        try {
          // eslint-disable-next-line
          anj_21f536a0_138f_4ad2_aa97_f06ce522506d.init();
        } catch (error) {
          console.log('error certificado', error);
        } /* link de verificacao de certificado  */
      }, 5000);

      /* controle div carriho */
      Events.on('open::modal::carrinho', e => {
        carrinho.value = e;
        document.body.classList.toggle('overflowhidden');
      });
      Events.on('open::modal::cadastro', e => {
        showCadastro.value = e;
      });
      Events.on('open::modal::login', e => {
        showLogin.value = e;
      });
      Events.on('open::modal::recuperarSenha', e => {
        showRecuperarSenha.value = e;
      });
      Events.on('open::modal::termoUso', e => {
        showTermoUso.value = e;
      });
      Events.on('modal::close', e => {
        carrinho.value = e;
        showLogin.value = e;
        showCadastro.value = e;
        showRecuperarSenha.value = e;
        showTermoUso.value = e;
      });
      (0,_core_service_firebase__WEBPACK_IMPORTED_MODULE_6__.init)();
      loader.value = true;
      store.dispatch('login/suporteWhatsapp').then(() => {
        loader.value = false;
        if (!plataformaAtiva.value.isEnable) {
          _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].remove('auth-token');
          // store.dispatch('login/logout')
        }
      });

      const token = _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].get('auth-token');
      if (token) {
        store.dispatch('login/getDadosUsuario').catch(e => {
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__._alert)('Faça login novamnete!');
          store.dispatch('login/logout');
        });
        store.dispatch('saldos/getSaldos');
      }
      if (!('geolocation' in navigator)) {
        // this.errorStr = 'Geolocation is not available.'
        console.log('erro geolocation');
        return;
      }
      if ('permissions' in navigator) {
        navigator.permissions.query({
          name: 'geolocation'
        }).then(result => {
          if (result.state === 'granted') {
            watchPositionGPS();
          }
          if (result.state === 'prompt') {
            getCurrentPositionGPS();
          }
        }).catch(e => {
          console.log(e);
        });
      }
      // abre modal jogo responsavel navbar
      Events.on('modal::produtos::jogoResponsavel', e => {
        showJogoResponsavel.value = e;
      });
      window.addEventListener('popstate', () => {
        // pegando o evento de voltar do navegador e se bater no produtos jogando na home para não buggar o apostas
        const currentPath = route.path;
        if (currentPath === '/produtos') router.replace({
          name: 'home'
        });
      });
    });
    return {
      menu,
      route,
      // showRaspadinha,
      vversion,
      plataformaAtiva,
      loader,
      showJogoResponsavel,
      iframeCartelas,
      carrinho,
      showCadastro,
      showLogin,
      showRecuperarSenha,
      showTermoUso,
      exiCertificado
    };
  }
});

//# sourceURL=webpack://plataforma/./src/App.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D