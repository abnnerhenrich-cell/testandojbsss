__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_service_firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/service/firebase */ "./src/core/service/firebase.js");
/* harmony import */ var register_service_worker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! register-service-worker */ "./node_modules/register-service-worker/index.js");
/* eslint-disable */


(0,register_service_worker__WEBPACK_IMPORTED_MODULE_1__.register)('service-worker.js', {
  ready(registration) {
    console.info('Service worker registration is ready.');
    const isIOS = () => {
      let isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      let isAppleDevice = navigator.userAgent.includes('Macintosh');
      let isTouchScreen = navigator.maxTouchPoints >= 1;
      return isIOS || isAppleDevice && isTouchScreen;
    };
    if (isIOS()) return;

    // if (Notification.permission !== 'granted') {
    //   Notification.requestPermission((permission) => {
    //     if (permission === 'granted') init(registration)
    //   })
    // } else {
    //   if (isIOS()) return
    //   // init(registration)
    // }
  },

  registered() {
    console.log('Service worker has been registered.');
  },
  cached() {
    console.log('Content has been cached for offline use.');
  },
  updatefound() {
    console.log('New content is downloading.');
  },
  updated() {
    console.log('New content is available; please refresh.');
  },
  offline() {
    console.log('No internet connection found. App is running in offline mode.');
  },
  error(error) {
    console.error('Error during service worker registration:', error);
  }
});

//# sourceURL=webpack://plataforma/./src/registerServiceWorker.js?