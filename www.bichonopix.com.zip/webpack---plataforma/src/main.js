__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ "./node_modules/bootstrap/dist/css/bootstrap.min.css");
/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _App_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App.vue */ "./src/App.vue");
/* harmony import */ var _registerServiceWorker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registerServiceWorker */ "./src/registerServiceWorker.js");
/* harmony import */ var _core_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/router */ "./src/core/router/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./store */ "./src/store/index.js");
/* harmony import */ var mitt__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! mitt */ "./node_modules/mitt/dist/mitt.mjs");
/* harmony import */ var bootstrap_icons_font_bootstrap_icons_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! bootstrap-icons/font/bootstrap-icons.css */ "./node_modules/bootstrap-icons/font/bootstrap-icons.css");
/* harmony import */ var bootstrap_icons_font_bootstrap_icons_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bootstrap_icons_font_bootstrap_icons_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var maska__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! maska */ "./node_modules/maska/dist/maska.esm.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue-loading-overlay */ "./node_modules/vue-loading-overlay/dist/vue-loading.min.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue-loading-overlay/dist/vue-loading.css */ "./node_modules/vue-loading-overlay/dist/vue-loading.css");
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _core_filters_currency__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/core/filters/currency */ "./src/core/filters/currency.js");
/* harmony import */ var vue_dk_toast__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-dk-toast */ "./node_modules/vue-dk-toast/dist/dkToast.umd.min.js");
/* harmony import */ var vue_dk_toast__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(vue_dk_toast__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var vue_gtag__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vue-gtag */ "./node_modules/vue-gtag/dist/vue-gtag.esm.js");
/* harmony import */ var vuejs_paginate_next__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vuejs-paginate-next */ "./node_modules/vuejs-paginate-next/dist/vuejs-paginate-next.es.js");
/* harmony import */ var bootstrap_dist_js_bootstrap_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! bootstrap/dist/js/bootstrap.js */ "./node_modules/bootstrap/dist/js/bootstrap.js");
/* harmony import */ var bootstrap_dist_js_bootstrap_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_js_bootstrap_js__WEBPACK_IMPORTED_MODULE_15__);















// import createjs from '@/core/plugins/installCreatejs'
// store.subscribe((action, state) => {
//   console.log(action.type)
//   const stateNow = Object.keys(state).map(v => {
//     const itens = Object.assign({}, state[v])
//     return itens
//   })
//   console.log(stateNow)
// })

// console.log(store._modules.root._children)

const Events = (0,mitt__WEBPACK_IMPORTED_MODULE_6__["default"])();
// window.createjs.$store = store

const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.createApp)({
  render: () => (0,vue__WEBPACK_IMPORTED_MODULE_1__.h)(_App_vue__WEBPACK_IMPORTED_MODULE_2__["default"])
});
app.config.globalProperties.Events = Events;
app.config.globalProperties._Currency = _core_filters_currency__WEBPACK_IMPORTED_MODULE_11__["default"];

// colors para cada produto no javascript
app.config.globalProperties.$COLORS = {
  BT: '#079CD2',
  SUP25: '#43a047',
  SUP5: '#FF5454',
  QB: '#3949ab',
  QUINZAO: '#2195F2',
  SURPRESINHA: '#8811bc',
  SENINHA: '#ff9200',
  DEFAULT: '#FFF'
};
app.use((vue_dk_toast__WEBPACK_IMPORTED_MODULE_12___default())).use(vue_gtag__WEBPACK_IMPORTED_MODULE_13__["default"], {
  config: {
    id: 'G-Y9B21QGEV7',
    params: {}
  }
}).use(_core_router__WEBPACK_IMPORTED_MODULE_4__["default"]).use(maska__WEBPACK_IMPORTED_MODULE_8__["default"]).use(vuejs_paginate_next__WEBPACK_IMPORTED_MODULE_14__["default"]).use((vue_loading_overlay__WEBPACK_IMPORTED_MODULE_9___default()), {
  loader: 'bars',
  color: '#007bff',
  with: 128,
  heigth: 128
}).use(_store__WEBPACK_IMPORTED_MODULE_5__["default"]).mount('#app');

// eslint-disable-next-line


//# sourceURL=webpack://plataforma/./src/main.js?