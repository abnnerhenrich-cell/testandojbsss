__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _hoisted_1 = {
  class: "bg"
};
const _hoisted_2 = {
  class: "VERSION bold f10 d-block text-center d-flex flex-nowrap align-items-end"
};
const _hoisted_3 = {
  key: 0
};
const _hoisted_4 = {
  key: 0,
  class: "info-certificado d-flex flex-column justify-content-center pt-2 mt-2"
};
const _hoisted_5 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "w-100 center mb-2"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  id: "anj-21f536a0-138f-4ad2-aa97-f06ce522506d",
  class: "ps-2",
  "data-anj-seal-id": "21f536a0-138f-4ad2-aa97-f06ce522506d",
  "data-anj-image-size": "30",
  "data-anj-image-type": "basic-small"
})], -1 /* HOISTED */);
const _hoisted_6 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "w-100 center f10 mb-2"
}, " bichonopix.com is operated by Vert Investments N.V., registered in the Commercial Register of Curaçao under number 163732 and License number ALSI-082309009-FI4 issued by the GAMING BOARD OF ANJOUAN at Union of Comoros in accordance with the Betting and Gaming act of 2005 of Anjouan. ", -1 /* HOISTED */);
const _hoisted_7 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "w-100 center f10 pb-2"
}, " © 2023 bichonopix.com Todos os direitos reservados. support@bichonopix.com ", -1 /* HOISTED */);
const _hoisted_8 = [_hoisted_5, _hoisted_6, _hoisted_7];
const _hoisted_9 = {
  key: 1
};
const _hoisted_10 = {
  class: "VERSION bold f10 d-block text-center"
};
const _hoisted_11 = {
  key: 2,
  class: "d-flex justify-content-center"
};
const _hoisted_12 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <modalJogoResponsavel :show=\"showJogoResponsavel\"/> ")], -1 /* HOISTED */);

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Menu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Menu");
  const _component_topMenu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("topMenu");
  const _component_router_view = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("router-view");
  const _component_btnAjuda = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("btnAjuda");
  const _component_MenuFooter = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("MenuFooter");
  const _component_ModalCarrinho = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalCarrinho");
  const _component_siteManutencao = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("siteManutencao");
  const _component_viewLoader = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("viewLoader");
  const _component_ModalLogin = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalLogin");
  const _component_ModalRecuperarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalRecuperarSenha");
  const _component_ModalCadastro = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalCadastro");
  const _component_ModalTermoUso = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalTermoUso");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" efeito quando abrir o menu bg fundo preto "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.menu]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("main", {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['h-100 mini-celulares', $setup.route.name === 'auth' || $setup.route.name === 'revenda' ? 'bg-print' : ''])
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */),  true ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_3, [$setup.plataformaAtiva && $setup.plataformaAtiva.isEnable && !$setup.loader ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
    key: 0,
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['d-flex d-column w-100', $setup.menu ? 'scroll' : ''])
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_Menu), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([$setup.menu ? 'open' : 'not'])
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_topMenu, {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([$setup.menu ? 'open-header' : 'not-header'])
  }, null, 8 /* PROPS */, ["class"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['p-2', $setup.menu ? 'open-content' : 'not-content'])
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_view), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" certificado "), $setup.exiCertificado ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_4, _hoisted_8)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.route.path !== '/apostas' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_btnAjuda, {
    key: 1
  })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(vue__WEBPACK_IMPORTED_MODULE_0__.Transition, {
    name: "fade"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [!$setup.menu && $setup.iframeCartelas === false ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_MenuFooter, {
      key: 0
    })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]),
    _: 1 /* STABLE */
  })], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalCarrinho, {
    showCarrinho: $setup.carrinho
  }, null, 8 /* PROPS */, ["showCarrinho"])], 2 /* CLASS */)], 2 /* CLASS */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Site em manutencao "), !$setup.plataformaAtiva || $setup.plataformaAtiva && $setup.plataformaAtiva.isEnable === false && !$setup.loader ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_10, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_Menu), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_siteManutencao), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([$setup.menu ? 'open' : 'not'])
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_topMenu, {
    class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([$setup.menu ? 'open-header' : 'not-header'])
  }, null, 8 /* PROPS */, ["class"])], 2 /* CLASS */)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" loader "), $setup.loader ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_11, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_viewLoader)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)])) : 0, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-if=\"showRaspadinha\" class=\"raspadinha-tela\">\r\n      <Raspadinha />\r\n    </div> "), _hoisted_12, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalLogin, {
    visible: $setup.showLogin
  }, null, 8 /* PROPS */, ["visible"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalRecuperarSenha, {
    visible: $setup.showRecuperarSenha
  }, null, 8 /* PROPS */, ["visible"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalCadastro, {
    visible: $setup.showCadastro
  }, null, 8 /* PROPS */, ["visible"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalTermoUso, {
    visible: $setup.showTermoUso
  }, null, 8 /* PROPS */, ["visible"])])], 2 /* CLASS */)], 64 /* STABLE_FRAGMENT */);
}

//# sourceURL=webpack://plataforma/./src/App.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D