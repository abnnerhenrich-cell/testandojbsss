__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BtnAjuda',
  props: {
    msg: {
      type: String,
      default: ''
    }
  },
  setup(props) {
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_2__.useStore)();
    const atual = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)('');
    const telefoneSuporte = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/telefoneSuporte']);
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(() => {
      atual.value = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.sample)(telefoneSuporte.value.whatsappSuport);
    });

    // const link = computed(() => {
    //   const tel = sample(telefoneSuporte.value.whatsappSuport)
    //   return `https://api.whatsapp.com/send?phone=${tel}&text=${props.msg}`
    // })

    const link = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const tel = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.sample)(telefoneSuporte.value.whatsappSuport);
      return tel;
    });
    return {
      telefoneSuporte,
      link
    };
  }
});

//# sourceURL=webpack://plataforma/./src/components/btnAjuda.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D