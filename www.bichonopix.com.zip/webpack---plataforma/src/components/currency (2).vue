__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_currency_input__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-currency-input */ "./node_modules/vue-currency-input/dist/index.esm.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'DebouncedCurrencyInput',
  emit: ['update:modelValue'],
  props: {
    qtdPalpites: {
      type: Number,
      default: () => 1
    },
    limitValue: {
      type: [Number, Boolean],
      default: () => false
    },
    validMaxValue: {
      type: [Number, Boolean, Object],
      default: () => false
    },
    id: {
      type: [String, Number],
      default: () => '0'
    },
    value: {
      type: [String, Number]
    },
    modelValue: [String, Number],
    // Vue 2: value
    idEvent: {
      type: String,
      default: 'undefined-valor-input'
    },
    options: {
      type: Object,
      default: () => ({
        locale: 'PT-BR',
        currency: 'BRL',
        currencyDisplay: 'symbol',
        valueRange: {
          min: 0,
          max: 100000000
        },
        precision: {
          min: 2,
          max: 2
        },
        hideCurrencySymbolOnFocus: false,
        hideGroupingSeparatorOnFocus: true,
        hideNegligibleDecimalDigitsOnFocus: false,
        autoDecimalDigits: true,
        valueScaling: 'precision',
        useGrouping: true,
        accountingSign: true
      })
    }
  },
  setup(props, {
    emit
  }) {
    const {
      inputRef,
      numberValue,
      setValue
    } = (0,vue_currency_input__WEBPACK_IMPORTED_MODULE_0__.useCurrencyInput)(props.options, false);
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_3__.useStore)();
    const changeValue = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(props.value);
    // eslint-disable-next-line
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const produtos = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['listagemProdutos/listProdutos']);
    const valorMaxProduto = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      if (!props.validMaxValue) return false;
      const itens = produtos.value.find(v => +v.config.ID_PROD === +props.id);
      if (!(0,lodash__WEBPACK_IMPORTED_MODULE_2__.size)(itens)) return false;
      return itens.config.MAX_VAL_PROD;
    });
    const verifyMaxValueProduto = (value, deleted = false) => {
      if (deleted) {
        const max = parseFloat(props.qtdPalpites * 100);
        if (max > value) return false;
        return props.qtdPalpites * 100 * 100;
      }
      if (value / props.qtdPalpites > valorMaxProduto.value) return props.qtdPalpites * 100 * 100;
      return false;
    };
    const verifyDigitValueMax = value => {
      if (props.validMaxValue === false) return false;
      if (value / props.qtdPalpites > valorMaxProduto.value * 100) return props.qtdPalpites * 100 * 100;
      return false;
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.onMounted)(() => {
      /* Gambiarra para nao deixar o imput valor zerado */
      setTimeout(() => {
        const itens = document.querySelectorAll('#currency-premios-modalidade-0');
        itens.forEach(v => {
          v.focus();
          v.value = 0;
        });
      }, 100);
      Events.on('add::currency::value', val => {
        const el = document.getElementById('currency-value');
        el.value = `R$ ${String(val).replace('.', ',')}`;
        el.focus();
        setValue(val);
        numberValue.value = val;
      });

      /* evento ouve quando delete palpite e atualiza dados do valor do input currency */
      Events.on('update::value::max::delete::palpite', ({
        total,
        indice,
        produt
      }) => {
        const validadeValueMax = verifyMaxValueProduto(total, true);
        if (!validadeValueMax) return;
        const idEvent = `event-${indice}`;
        Events.emit(`add::currency::value::${idEvent}`, validadeValueMax);
      });
      Events.on(`add::currency::value::${props.idEvent}`, val => {
        const el = document.getElementById(props.idEvent);
        if (!el) return;
        el.value = `R$ ${String(val).replace('.', ',')}`;
        setTimeout(() => el.focus(), 300);
        setValue(val);
        numberValue.value = val;
      });
      Events.on('valor::input::reset', () => {
        setValue(0);
        const el = document.getElementById('currency-value');
        el.value = 'R$ 0,00';
      });
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.watch)(numberValue, (value, old) => {
      if (value === old) return;
      const valid = verifyDigitValueMax(value);
      if (valid) {
        (0,vue__WEBPACK_IMPORTED_MODULE_1__.nextTick)(() => {
          setTimeout(() => {
            Events.emit(`add::currency::value::${props.idEvent}`, valid);
            emit('update:modelValue', valid);
            emit('itenChange', valid);
          }, 100);
        });
        return;
      }
      emit('update:modelValue', value);
      emit('itenChange', value);
    });
    // feito isso para fazer update do currency quando mudar o typo do campo

    return {
      inputRef,
      changeValue
    };
  }
});

//# sourceURL=webpack://plataforma/./src/components/currency.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D