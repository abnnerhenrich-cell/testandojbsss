__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue3_datepicker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue3-datepicker */ "./node_modules/vue3-datepicker/dist/vue3-datepicker.esm.js");
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! date-fns/locale */ "./node_modules/date-fns/esm/locale/pt-BR/index.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'DefaultDataComponent',
  emits: ['update:modelValue'],
  props: {
    modelValue: [String, Date],
    format: {
      type: String,
      default: () => 'dd/mm/yyyy'
    },
    visible: {
      type: Boolean,
      default: () => true
    },
    label: {
      type: String,
      default: () => 'Data Inícial'
    },
    icon: {
      type: Boolean,
      default: () => true
    },
    dataMinima: {
      type: Date,
      default: () => moment__WEBPACK_IMPORTED_MODULE_2___default()('1970-01-01 00:00:00').toDate()
    },
    dataMaxima: {
      type: Date,
      default: () => null
    }
  },
  components: {
    Data: vue3_datepicker__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  setup() {
    const initDate = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(new Date());
    const example2From = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(new Date('2023-05-20T00:00:00.000Z'));
    return {
      ptBR: date_fns_locale__WEBPACK_IMPORTED_MODULE_3__["default"],
      initDate,
      example2From
    };
  },
  watch: {
    initDate(val) {
      this.$emit('update:modelValue', val);
    }
  }
});

//# sourceURL=webpack://plataforma/./src/components/datas/index.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D