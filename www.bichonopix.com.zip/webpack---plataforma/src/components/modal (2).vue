__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap */ "./node_modules/bootstrap/dist/js/bootstrap.esm.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store */ "./src/store/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AppModal',
  props: {
    autoClose: {
      type: Boolean,
      default: true
    },
    visible: {
      type: Boolean,
      default: false
    },
    title: {
      type: Boolean,
      default: true
    },
    showButtons: {
      type: Boolean,
      default: true
    },
    close: {
      type: String,
      default: 'modal::close'
    },
    bilhete: {
      type: Boolean,
      default: false
    },
    video: {
      type: Boolean,
      default: false
    },
    isTransparent: {
      type: Boolean,
      default: false
    },
    geolocation: {
      type: Boolean,
      default: false
    },
    infoAposta: {
      type: Boolean,
      default: false
    },
    type: {
      type: [String],
      default: ''
    },
    modifyClassModal: {
      default: false
    },
    outclickClose: {
      type: Boolean,
      default: false
    }
  },
  data: () => ({
    modal: null
  }),
  mounted() {
    const vm = this;
    vm.modal = new bootstrap__WEBPACK_IMPORTED_MODULE_0__.Modal(vm.$refs.exampleModal);
    const modalElement = document.getElementById('modal-component');
    modalElement.addEventListener('hidden.bs.modal', () => {
      this.Events.emit(this.close, false);
    });
  },
  beforeUnmount() {
    this.Events.emit(this.close, false);
  },
  methods: {
    modalClose() {
      this.Events.emit(this.close, false);
      this.modal.hide();
    }
  },
  watch: {
    visible(val) {
      if (val === true) {
        _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('setMenu', false);
        return this.modal.show();
      }
      this.modal.hide();
    }
  }
});

//# sourceURL=webpack://plataforma/./src/components/modal.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D