__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/store */ "./src/store/index.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _core_mixins__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/core/mixins */ "./src/core/mixins/index.js");
/* harmony import */ var _components_currency_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/currency.vue */ "./src/components/currency.vue");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_loader_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/loader.vue */ "./src/components/loader.vue");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_filters_currency__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/core/filters/currency */ "./src/core/filters/currency.js");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalCarrinho',
  mixins: [_core_mixins__WEBPACK_IMPORTED_MODULE_2__.filterMixins],
  components: {
    inputCurrency: _components_currency_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    loader: _components_loader_vue__WEBPACK_IMPORTED_MODULE_6__["default"]
  },
  props: {
    showCarrinho: {
      type: Boolean,
      default: false
    }
  },
  setup() {
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const closeCarrinho = event => {
      if (['carrinho', 'shop-close', 'img-close', 'btn-mais-apostas'].includes(event.target.className)) {
        Events.emit('open::modal::carrinho', false);
      }
    };
    const value = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(0);
    const loaderFinalizar = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const listCarrinho = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      return _store__WEBPACK_IMPORTED_MODULE_0__["default"].getters["carrinho/listCarrinho"];
    });

    // eslint-disable-next-line
    const produtos = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => _store__WEBPACK_IMPORTED_MODULE_0__["default"].getters["listagemProdutos/listProdutos"]);
    const listSaldos = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => _store__WEBPACK_IMPORTED_MODULE_0__["default"].getters["saldos/listSaldos"]);
    const deleteShop = indice => {
      _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/deleteShop', indice);
    };
    const deletePalpiteCarrinho = (indice, deleted, total) => {
      if (!listCarrinho.value.list[indice] && !listCarrinho.value.list[indice].palpites[deleted]) return;
      const sizePalpites = listCarrinho.value.list[indice].palpites.filter((v, k) => k !== deleted).length;
      if (sizePalpites < 1) return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Não é possivel deletar todos palpites');
      (0,vue__WEBPACK_IMPORTED_MODULE_1__.nextTick)(() => {
        _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/deletePalpiteShop', {
          indice,
          deleted
        }).then(() => {
          (0,vue__WEBPACK_IMPORTED_MODULE_1__.nextTick)(() => {
            Events.emit('update::value::max::delete::palpite', {
              indice,
              total
            });
            _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/finalizarAposta', {
              ...listCarrinho.value,
              saveHistory: true
            });
          });
        });
      });
    };
    const formatValorPalpite = val => val < 0.1 ? 'insuficente' : val;
    const changeValueShop = async (indice, value) => {
      _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/updateValue', {
        indice,
        value: value / 100
      });
      limitRequest();
    };
    const limitRequest = (0,lodash__WEBPACK_IMPORTED_MODULE_7__.debounce)((...args) => {
      _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/finalizarAposta', {
        ...listCarrinho.value,
        saveHistory: true
      });
    }, 500, {
      leading: true,
      trailing: true
    });
    const formatPremios = (premio, modalidade, palpites = []) => {
      if (!palpites && !palpites[0]) return 'Não encontrado prêmio';
      const text = (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__.formatPremioModalidade)(premio, modalidade);
      if (text.dezena) return palpites[0].val.split('-').length;
      return text.text;
    };
    const possivelGanho = game => {
      let premio = formatPremios(game.formatPremios.id, game.modalidade, game.palpites);
      const {
        dezena
      } = (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__.formatPremioModalidade)(premio, game.modalidade);
      if (!dezena) premio = parseInt(game.formatPremios.id);
      const cotacoes = (0,lodash__WEBPACK_IMPORTED_MODULE_7__.map)(game.modalidade.AR_COTACAO, item => ({
        ...item,
        VL_PREMIO: parseFloat(item.VL_PREMIO)
      }));
      const arrCotacoes = cotacoes.filter(it => it.IN_PREMIO === parseInt(premio));
      const cotacao = arrCotacoes.length ? (0,lodash__WEBPACK_IMPORTED_MODULE_7__.maxBy)(arrCotacoes, 'VL_PREMIO') : (0,lodash__WEBPACK_IMPORTED_MODULE_7__.maxBy)(cotacoes, 'VL_PREMIO');
      const premios = game.modalidade.CD_PREM;
      const qtdPalpites = game.palpites.length;
      const isDividir = premios.some(item => (0,lodash__WEBPACK_IMPORTED_MODULE_7__.size)(String(item)) === 1);
      let qtdPremios = 1;
      if (!dezena) {
        const [num1, num2] = game.formatPremios.id.split('');
        const qtd = String(game.formatPremios.id).length >= 2 ? (0,lodash__WEBPACK_IMPORTED_MODULE_7__.range)(parseInt(num1), parseInt(num2) + 1).length : 1;
        qtdPremios = isDividir ? qtd : 1;
      }
      const valor = game.palpiteValue / qtdPalpites / qtdPremios * (cotacao ? cotacao.VL_PREMIO : game.modalidade.COTACAO) / 100;
      game.ganho = valor;
      return Math.floor(valor * 100) / 100;
    };
    const submitCarrinho = async () => {
      const isValorInvalido = listCarrinho.value.list.some(it => it.ganho < 0.01);
      if (isValorInvalido) {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Valor total do carrinho inválido!', 'error');
        return;
      }

      /* Verificar saldo */
      loaderFinalizar.value = true;

      /* caso tenha bonus */
      if (listSaldos.value.bonus > 0) {
        new (sweetalert2__WEBPACK_IMPORTED_MODULE_5___default())({
          title: 'Atenção?',
          text: `Utilizar saldo de Bonus ${(0,_core_filters_currency__WEBPACK_IMPORTED_MODULE_9__["default"])(listSaldos.value.bonus)} para realizar jogo! \n Valor aposta: ${(0,_core_filters_currency__WEBPACK_IMPORTED_MODULE_9__["default"])(getTotal.value)}`,
          customClass: 'animated fadeInUp',
          icon: 'warning',
          showConfirmButton: true,
          showDenyButton: true,
          confirmButtonText: 'Sim',
          confirmButtonColor: '#005f07',
          denyButtonText: 'Não',
          reverseButtons: true,
          showCloseButton: true,
          preDeny: () => console.log('veio aqui nessa merda')
        }).then(async res => {
          /* Confirmou bonus */
          if (res.isConfirmed) {
            if (listSaldos.value.bonus < getTotal.value) {
              loaderFinalizar.value = false;
              return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Saldo de bonus muito baixo', 'warning');
            }
            return await registrarAposta(true);
          }
          /* fechou modal */
          if (res.isDismissed) {
            loaderFinalizar.value = false;
            return;
          }
          /* credito normal */
          await registrarAposta();
        });
        return;
      }
      await registrarAposta();
    };
    const registrarAposta = (isBonus = false) => {
      const params = _core_service_session__WEBPACK_IMPORTED_MODULE_8__["default"].get('gps');
      _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('login/addPositions', params);
      loaderFinalizar.value = true;
      if (listSaldos.value.saldo < getTotal.value && isBonus === false) {
        new (sweetalert2__WEBPACK_IMPORTED_MODULE_5___default())({
          title: 'Créditos muito baixo !',
          text: `Para realizar sua aposta de ${(0,_core_filters_currency__WEBPACK_IMPORTED_MODULE_9__["default"])(getTotal.value)} faça um PIX !`,
          customClass: 'animated fadeInUp',
          icon: 'warning',
          showConfirmButton: true,
          showDenyButton: false,
          confirmButtonText: 'Realizar PIX!',
          confirmButtonColor: '#005f07',
          reverseButtons: true,
          showCloseButton: true
        }).then(async res => {
          if (res.isConfirmed) {
            router.push({
              name: 'creditos'
            });
          }
          loaderFinalizar.value = false;
        }).finally(() => {
          loaderFinalizar.value = false;
          Events.emit('open::modal::carrinho', false);
        });
        return;
      }
      _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/finalizarAposta', {
        ...listCarrinho.value.list,
        isBonus
      }).then(() => {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Jogo Realizado Com sucesso!');
        Events.emit('open::modal::carrinho', false);
        _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('saldos/getSaldos').then(() => {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('carrinho/clearCarrinho');
          router.push({
            name: 'home'
          });
          loaderFinalizar.value = false;
        });
      }).catch(e => {
        loaderFinalizar.value = false;
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)(e.message, 'error', 5000);
      }).finally(() => {
        loaderFinalizar.value = false;
      });
    };
    const fazerAposta = () => {
      Events.emit('open::modal::carrinho', false);
      router.push({
        name: 'produtos'
      });
    };
    const getTotal = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      return listCarrinho.value.list.reduce((acc, item) => item.total + acc, 0);
    });
    return {
      closeCarrinho,
      listCarrinho,
      deleteShop,
      value,
      changeValueShop,
      submitCarrinho,
      loaderFinalizar,
      getTotal,
      fazerAposta,
      formatPremios,
      possivelGanho,
      deletePalpiteCarrinho,
      formatValorPalpite
    };
  }
});

//# sourceURL=webpack://plataforma/./src/components/modalCarrinho.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D