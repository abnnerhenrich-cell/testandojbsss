__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/produtos',
  name: 'produtos',
  component: () => __webpack_require__.e(/*! import() | produtos */ "produtos").then(__webpack_require__.bind(__webpack_require__, /*! ./index.vue */ "./src/views/produtos/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/produtos/router.js?