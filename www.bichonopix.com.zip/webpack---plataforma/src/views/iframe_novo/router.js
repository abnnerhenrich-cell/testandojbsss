__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/cartelas2',
  name: 'iframe.cartelas2',
  component: () => __webpack_require__.e(/*! import() | iframeCartelas */ "iframeCartelas").then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/iframe_novo/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/iframe_novo/router.js?