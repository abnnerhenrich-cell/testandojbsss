__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/cartelas',
  name: 'iframe.cartelas',
  component: () => __webpack_require__.e(/*! import() | iframeCartelas */ "iframeCartelas").then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/iframe/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/iframe/router.js?