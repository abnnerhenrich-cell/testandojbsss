__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/indexar-bilhetes',
  name: 'indexar.bilhetes',
  component: () => Promise.all(/*! import() | indexar.bilhetes */[__webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("node_modules_vue3-qr-reader_dist_vue3-qr-reader_common_js"), __webpack_require__.e("indexar.bilhetes")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index.vue */ "./src/views/indexarBilhetes/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/indexarBilhetes/router.js?