__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/cadastrar-revendedor',
  name: 'cadastrar-revendedor',
  component: () => Promise.all(/*! import() | home */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("home")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/revenda/cadastro/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/revenda/cadastro/router.js?