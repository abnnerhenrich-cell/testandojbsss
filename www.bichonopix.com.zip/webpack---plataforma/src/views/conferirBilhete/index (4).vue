__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/noSourceMaps.js */ "./node_modules/css-loader/dist/runtime/noSourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* Modal BackGround */\n/* Home */\n/* home buttons */\n/* cadastrar */\n/* recuperar senha / Cadastrar / Login */\n/* recuperar senha / Cadastrar */\n/* Cartelas BT */\n/* FFE7A4 */\n/* 975821 */\n/* 572515 */\n/* SUP25 */\n/* SUP5 */\n/* HOME */\n/* novas */\n/* login */\n/* listagem produtos  icon white svg */\n/* auth home */\n/* RESULTADO */\n/* CARRINHO */\n/* MODO DARK HOME */\n.conferir input[data-v-2915a932] {\n  height: 50px;\n  outline: none;\n  border: 1px solid #7986cb;\n  border-radius: 10px;\n  box-shadow: 0 3px 10px 0 #7986cb1f;\n  color: #0F2BA1;\n  text-transform: uppercase;\n}\n.qr-stream-wrapper[data-v-2915a932] {\n  border: 1px solid #7986cb;\n  border-radius: 10px;\n  margin-top: 10px;\n}\n.content[data-v-2915a932] {\n  position: relative;\n}\n.content-loader[data-v-2915a932] {\n  position: absolute !important;\n  z-index: 999999 !important;\n  top: 35%;\n  left: 50%;\n  transform: translate(-50%, 50%);\n}", ""]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


//# sourceURL=webpack://plataforma/./src/views/conferirBilhete/index.vue?./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use%5B1%5D!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use%5B2%5D!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D