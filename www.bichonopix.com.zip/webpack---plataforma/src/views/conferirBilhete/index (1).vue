__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue3_qr_reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue3-qr-reader */ "./node_modules/vue3-qr-reader/dist/vue3-qr-reader.common.js");
/* harmony import */ var vue3_qr_reader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue3_qr_reader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var _components_loader_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/loader.vue */ "./src/components/loader.vue");






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ConferirBilhetes',
  components: {
    QrStream: vue3_qr_reader__WEBPACK_IMPORTED_MODULE_0__.QrStream,
    Loader: _components_loader_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  setup() {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      $loading,
      _Currency
    } = app.appContext.config.globalProperties;
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_5__.useStore)();
    const codigo = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('');
    const revenda = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('');
    const destroyed = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('off');
    const errorCamera = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const loaderComponent = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const verificarBilhete = (dados = false) => {
      let cod = dados;
      const isValidCod = String(revenda.value).replace(/\D/g, '');
      if (!dados && ((0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(isValidCod) !== (0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(revenda.value) || !(0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(isValidCod))) {
        return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)('Codigo Revenda inválido', 'error');
      }
      if (!dados && !isNaN(codigo.value.replace('GYN.', ''))) {
        return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)('Bilhete web, por favor conferir seu bilhete em minhas apostas', 'error');
      }
      if (!dados) cod = {
        bilhete: String(codigo.value).toUpperCase(),
        entityId: revenda.value
      };
      const loader = $loading.show();
      store.dispatch('conferirBilhete/getWinnerGames', cod).then(res => {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)(`Bilhete Prêmiado!
          Valor: ${_Currency(parseFloat(res.data.data.pending.value))}`, 'success');
      }).catch(e => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)(e.message, 'error');
      }).finally(() => {
        loader.hide();
        destroyed.value = 'off';
      });
    };
    const reloadQrCode = async () => {
      // restart camera
      destroyed.value = 'off';
      await (0,vue__WEBPACK_IMPORTED_MODULE_1__.nextTick)();
      setTimeout(() => {
        destroyed.value = 'auto';
      });
    };
    const onInit = async promise => {
      // inicializacao da camera
      loaderComponent.value = true;
      try {
        await promise;
      } catch (error) {
        errorCamera.value = true;
        console.log('error', error);
        if (error.name === 'NotAllowedError') (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)('Acesso a camera negado', 'warning');
        if (error.name === 'NotFoundError') console.log('nao tem camera instalada');
        if (error.name === 'NotSupportedError') console.log('nao tem suporte a https');
        if (error.name === 'NotReadableError') console.log('camera ja esta em uso');
        if (error.name === 'OverconstrainedError') console.log('camera frontal nao existe');
        if (error.name === 'OverconstrainedError') console.log('navegador sem recuro');
      } finally {
        loaderComponent.value = false;
      }
    };
    const qrCodeStart = () => {
      destroyed.value = destroyed.value === 'off' ? 'auto' : 'off';
    }; // start camera

    const onDecode = string => {
      // leitura da camera
      if (!(0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(string)) return;
      const url = string;
      const parametrosDaUrl = url.split('?')[1];
      const listaDeParametros = parametrosDaUrl.split('&');
      const hash = {};
      for (let i = 0; i < listaDeParametros.length; i++) {
        const parametro = listaDeParametros[i].split('=');
        const chave = parametro[0];
        const valor = parametro[1];
        hash[chave] = valor;
      }
      const dados = {
        cod: hash.cod.toUpperCase(),
        // numero do bilhete
        entityId: hash.ag // agencia de compra no caso revenda
      };

      if (!dados.entityId) {
        reloadQrCode();
        return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)('Revenda inexistente!', 'error');
      }
      if (!dados.cod) {
        reloadQrCode();
        return (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_2__._alert)('Código inexistente!', 'error');
      }
      // passa dados do qrcode
      verificarBilhete(dados);
    };
    return {
      codigo,
      verificarBilhete,
      qrCodeStart,
      destroyed,
      errorCamera,
      onDecode,
      onInit,
      loaderComponent,
      revenda
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/conferirBilhete/index.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D