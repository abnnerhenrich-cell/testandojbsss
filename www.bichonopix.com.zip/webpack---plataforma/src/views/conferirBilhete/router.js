__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/conferir-bilhetes',
  name: 'conferir.bilhetes',
  component: () => Promise.all(/*! import() | conferir-bilhete */[__webpack_require__.e("node_modules_vue3-qr-reader_dist_vue3-qr-reader_common_js"), __webpack_require__.e("conferir-bilhete")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index.vue */ "./src/views/conferirBilhete/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/conferirBilhete/router.js?