__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/meus-bonus',
  name: 'meusBonus',
  component: () => __webpack_require__.e(/*! import() | minhasApostas */ "minhasApostas").then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/meusBonus/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/meusBonus/router.js?