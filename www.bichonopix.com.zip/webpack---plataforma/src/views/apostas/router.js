__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/apostas',
  name: 'apostas',
  component: () => Promise.all(/*! import() | apostas */[__webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("apostas")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/apostas/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/apostas/router.js?