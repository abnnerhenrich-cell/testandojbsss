__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _listagemLoterias_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./listagemLoterias.vue */ "./src/views/resultados/components/listagemLoterias.vue");
/* harmony import */ var _resultadoListaProdutos_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./resultadoListaProdutos.vue */ "./src/views/resultados/components/resultadoListaProdutos.vue");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var _components_datas_index_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/datas/index.vue */ "./src/components/datas/index.vue");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! date-fns/locale */ "./node_modules/date-fns/esm/locale/pt-BR/index.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @vuelidate/core */ "./node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_loader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/loader */ "./src/components/loader.vue");







// eslint-disable-next-line




const storeListProduto = 'listagemProdutos/';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'resultado|ModalFiltroResultado',
  props: {
    instantanea: {
      type: [Boolean],
      default: () => true
    }
  },
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    listProdutos: _resultadoListaProdutos_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    listaLoterias: _listagemLoterias_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    SelectDate: _components_datas_index_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    Loader: _components_loader__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  setup() {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_4__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_9__.useStore)();
    const prodAtual = (0,vue__WEBPACK_IMPORTED_MODULE_4__.computed)(() => store.getters[`${storeListProduto}getSelect`]);
    const loader = (0,vue__WEBPACK_IMPORTED_MODULE_4__.computed)(() => store.getters['resultados/getLoader']);
    const state = (0,vue__WEBPACK_IMPORTED_MODULE_4__.reactive)({
      initDate: new Date(),
      selectLoteria: false,
      show: false
    });
    return {
      store,
      loader,
      v$: (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_6__["default"])(),
      state,
      prodAtual,
      ptBR: date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"],
      buscaLoterias: () => {
        // lista de produtos
        store.dispatch(`${storeListProduto}getLoteriasProdutos`, prodAtual.value);
      },
      getResultado: () => {
        // busca resultado
        let loteria = state.selectLoteria.value;
        if (loteria === 'Federal') loteria = 'FD';
        if (loteria === 'Todas') loteria = null;
        if (loteria === 'QB') loteria = 'QUINA BRASIL';
        if (loteria === 'QB') loteria = 'SUPER QUINA';
        if (loteria === 'SUP5') loteria = 'SUPER QUINA';
        const data = moment__WEBPACK_IMPORTED_MODULE_7___default()(state.initDate);
        const params = {
          dtEnd: data.format('YYYY-MM-DD'),
          loteria
        };

        // bug para super5 se nao traz somente LK
        // if (prodAtual.value === 'SUP5') {
        //   // delete params.loteria
        //   params.produto = prodAtual.value
        // }
        params.produto = prodAtual.value;
        // start loader
        store.dispatch('resultados/setLoader', true);

        // set Filtro data
        store.dispatch('resultados/setFiltros', {
          data: state.initDate,
          dataFormat: data.format('DD/MM/YYYY')
        });
        store.dispatch('resultados/getResultados', params).then(() => {
          state.show = false;
        }).catch(e => {
          if (e.message === 'Token não fornecido') {
            console.log('abriu modal');
            Events.emit('modal::cadastro', true);
          }
        }).finally(() => {
          // state.show = false
          store.dispatch('resultados/setLoader', false);
        });
      }
    };
  },
  mounted() {
    this.Events.on('modal::resultado::filtro', e => {
      this.state.show = e;
    });
    this.Events.on('modal::close', e => {
      this.state.show = e;
    });
    const data = moment__WEBPACK_IMPORTED_MODULE_7___default()();
    this.store.dispatch('resultados/setFiltros', {
      data: data.format('YYYY-MM-DD'),
      dataFormat: data.format('DD/MM/YYYY')
    });
  },
  watch: {
    'state.show'(v) {
      if (v === true && this.prodAtual) this.buscaLoterias();
    },
    'state.iniDate'(v) {
      this.store.dispatch('resultados/setFiltros', {
        data: v,
        dataFormat: moment__WEBPACK_IMPORTED_MODULE_7___default()(v).format('DD/MM/YYYY')
      });
    }
  }
});

//# sourceURL=webpack://plataforma/./src/views/resultados/components/modalFiltro.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D