__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/vue */ "./node_modules/swiper/vue/swiper-vue.js");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! swiper/css */ "./node_modules/swiper/swiper.min.css");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css/pagination */ "./node_modules/swiper/modules/pagination/pagination.min.css");
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/navigation */ "./node_modules/swiper/modules/navigation/navigation.min.css");
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swiper */ "./node_modules/swiper/swiper.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/loader.vue */ "./src/components/loader.vue");
// Import Swiper Vue.js components


// Import Swiper styles




// import required modules




// eslint-disable-next-line


moment__WEBPACK_IMPORTED_MODULE_6___default().locale('pt-br');
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ResultadoLitagemLoterias',
  emits: ['update:modelValue'],
  components: {
    Swiper: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.Swiper,
    SwiperSlide: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide,
    loader: _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  props: {
    classeAtual: {
      type: String,
      default: ''
    },
    visible: {
      type: Boolean,
      default: () => false
    },
    showHorarios: {
      type: Boolean,
      default: () => false
    },
    instantanea: {
      type: Boolean,
      default: () => true
    }
  },
  setup(props) {
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_9__.useStore)();
    const selectLoteria = (0,vue__WEBPACK_IMPORTED_MODULE_5__.ref)(false);
    const loading = (0,vue__WEBPACK_IMPORTED_MODULE_5__.ref)(false);
    // produto atual selecionado
    const produtoAtual = (0,vue__WEBPACK_IMPORTED_MODULE_5__.computed)(() => store.getters['listagemProdutos/getSelect']);

    // Lista de loterias baseado na modalidade atual
    const listLoterias = (0,vue__WEBPACK_IMPORTED_MODULE_5__.computed)(() => store.getters['listagemProdutos/listLoterias']);
    const formatLoterias = (0,vue__WEBPACK_IMPORTED_MODULE_5__.computed)(() => {
      const dados = listLoterias;
      if ((0,lodash__WEBPACK_IMPORTED_MODULE_7__.size)(dados)) {
        return (0,lodash__WEBPACK_IMPORTED_MODULE_7__.map)(dados.value, (v, k) => {
          const name = String(v[0].DS_LOT).replace(/\d/g, '').replace(':', '').replace('-', '').trim();
          if (name === 'Todas') return null;
          if (name === 'INSTANTÂNEA' && !props.instantanea) return null;
          return String(v[0].DS_LOT).replace(/\d/g, '').replace(':', '').replace('-', '').trim();
        }).filter(v => v);
      }
      return dados;
    });
    const updatedProdutoAtualLoterias = async v => {
      _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__["default"].value = true;
      return store.dispatch('listagemProdutos/getLoteriasProdutos', v).finally(() => {
        _components_loader_vue__WEBPACK_IMPORTED_MODULE_8__["default"].value = false;
      });
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_5__.watch)(produtoAtual, v => {
      if ((0,lodash__WEBPACK_IMPORTED_MODULE_7__.size)(v)) updatedProdutoAtualLoterias(v);
    });
    return {
      loading,
      selectLoteria,
      produtoAtual,
      modules: [swiper__WEBPACK_IMPORTED_MODULE_4__.Pagination, swiper__WEBPACK_IMPORTED_MODULE_4__.Navigation],
      listLoterias,
      store,
      formatLoterias,
      activeLoteria: event => {
        selectLoteria.value = formatLoterias.value[event.clickedIndex];
      }
    };
  },
  watch: {
    selectLoteria(v) {
      this.$emit('update:modelValue', {
        value: v,
        visible: true
      });
    }
  }
});

//# sourceURL=webpack://plataforma/./src/views/resultados/components/listagemLoterias.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D