__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/vue */ "./node_modules/swiper/vue/swiper-vue.js");
/* harmony import */ var _components_loader_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/loader.vue */ "./src/components/loader.vue");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css */ "./node_modules/swiper/swiper.min.css");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/navigation */ "./node_modules/swiper/modules/navigation/navigation.min.css");
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swiper/css/pagination */ "./node_modules/swiper/modules/pagination/pagination.min.css");
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! swiper */ "./node_modules/swiper/swiper.esm.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
// Import Swiper Vue.js components

// import { size } from 'lodash'

// Import Swiper styles





// import required modules



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ResultadoListagemProdutos',
  components: {
    Swiper: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.Swiper,
    SwiperSlide: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide,
    loader: _components_loader_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    navegation: {
      type: Boolean,
      default: () => true
    },
    filtros: {
      type: [Object, Boolean],
      default: () => false
    },
    noresult: {
      type: Boolean,
      default: () => false
    },
    pagination: {
      type: Boolean,
      default: () => true
    },
    init: {
      type: Boolean,
      default: () => false
    }
  },
  emits: ['openDate'],
  setup(props, {
    emit
  }) {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_6__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;

    // variables
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_7__.useStore)();
    const prodActive = (0,vue__WEBPACK_IMPORTED_MODULE_6__.computed)(() => store.getters['listagemProdutos/getSelect']);
    const listProd = (0,vue__WEBPACK_IMPORTED_MODULE_6__.computed)(() => store.getters['listagemProdutos/listProdutosResultado']);
    const filtroResultados = (0,vue__WEBPACK_IMPORTED_MODULE_6__.computed)(() => store.getters['resultados/getFiltro']);
    const configBonusWeb = (0,vue__WEBPACK_IMPORTED_MODULE_6__.computed)(() => store.getters['login/configBonusWeb']);
    const request = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(false);
    const modules = [];
    if (props.pagination) modules.push(swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination);
    if (props.navegation) modules.push(swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation);
    const buscarResultados = async params => {
      if (props.noresult) return;
      store.dispatch('resultados/setLoader', true);
      store.dispatch('resultados/getResultados', {
        ...params
      }).catch(e => {
        if (e.message === 'Token não fornecido') {
          console.log('abriu modal');
          Events.emit('modal::cadastro', true);
        }
      }).finally(() => {
        store.dispatch('resultados/setLoader', false);
      });
    };
    const activeProd = async event => {
      if (!listProd.value[event.clickedIndex]) return;
      store.dispatch('listagemProdutos/setSelectProdutoAtual', listProd.value[event.clickedIndex].id);
      // buscarResultados({ dtEnd: filtroResultados.value.data, produto: prodActive.value })
    };

    const activeProdMarca = async event => {
      emit('openDate', true);
      if (listProd[event]) return;
      store.dispatch('listagemProdutos/setSelectProdutoAtual', listProd.value[event].id);
      // buscarResultados({ dtEnd: filtroResultados.value.data, produto: prodActive.value })
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_6__.onMounted)(() => {
      store.dispatch('listagemProdutos/getProdutos').then(() => {
        activeProd({
          clickedIndex: 0
        });
      });
      if (props.init) activeProd({
        clickedIndex: 0
      });
    });
    return {
      request,
      store,
      modules,
      prodActive,
      listProd,
      filtroResultados,
      buscarResultados,
      activeProd,
      activeProdMarca,
      configBonusWeb
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/resultados/components/resultadoListaProdutos.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D