__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_resultadoListaProdutos_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/resultadoListaProdutos.vue */ "./src/views/resultados/components/resultadoListaProdutos.vue");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _vuepic_vue_datepicker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @vuepic/vue-datepicker */ "./node_modules/@vuepic/vue-datepicker/dist/vue-datepicker.js");
/* harmony import */ var _vuepic_vue_datepicker_dist_main_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @vuepic/vue-datepicker/dist/main.css */ "./node_modules/@vuepic/vue-datepicker/dist/main.css");
/* harmony import */ var _vuepic_vue_datepicker_dist_main_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_vuepic_vue_datepicker_dist_main_css__WEBPACK_IMPORTED_MODULE_5__);

// import SelectDate from '@/components/datas/index.vue'
// eslint-disable-next-line

// eslint-disable-next-line






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Resultado',
  components: {
    listProdutos: _components_resultadoListaProdutos_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    Datepicker: _vuepic_vue_datepicker__WEBPACK_IMPORTED_MODULE_4__["default"],
    ModalResultado: (0,vue__WEBPACK_IMPORTED_MODULE_1__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_date-fns_esm_locale_pt-BR_index_js-node_modules_vue3-datepicker_dist_vue3-datepi-155d6d"), __webpack_require__.e("src_views_resultados_components_modalFiltro_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/modalFiltro.vue */ "./src/views/resultados/components/modalFiltro.vue"))),
    Loader: (0,vue__WEBPACK_IMPORTED_MODULE_1__.defineAsyncComponent)(() => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! @/components/loader */ "./src/components/loader.vue"))),
    ModalCadastro: (0,vue__WEBPACK_IMPORTED_MODULE_1__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("src_views_auth_components_modalCadastro_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/modalCadastro.vue */ "./src/views/auth/components/modalCadastro.vue")))
  },
  props: {
    loginHome: {
      // se for na pagina home aplicar coisas diferentes
      type: Boolean,
      default: () => true
    },
    instantanea: {
      type: [Boolean],
      default: () => true
    }
  },
  setup(props) {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;

    /* Variveis */
    const produto = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(0);
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_6__.useStore)();
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_7__.useRoute)();
    /* computeds */
    const filtros = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['resultados/getFiltro']);
    const loader = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['resultados/getLoader']);
    const listResult = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['resultados/listResultados']);
    const initDate = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(new Date());
    const openDate = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(true);
    // const init = ref(0)
    const datepicker = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(null);
    const instantaneaResultadoDisabled = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      const desativar = props.instantanea;
      const desativaPorRota = router.name === 'resultados' ? !!0 : !!1;
      const res = [desativar, desativaPorRota];
      return res.includes(false) ? !!0 : !!1;
    });
    const prodAtual = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['listagemProdutos/getSelect']);
    const formatResult = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      const dados = store.getters['resultados/listResultados'];
      if (!dados[0]) return [];
      return (0,lodash__WEBPACK_IMPORTED_MODULE_3__.map)(dados, v => {
        return (0,lodash__WEBPACK_IMPORTED_MODULE_3__.compact)((0,lodash__WEBPACK_IMPORTED_MODULE_3__.map)(v.prizes, it => {
          if (it.max) {
            const iten = String(it.max).split('- ');
            it.cod = iten[0] || {};
            it.lottery = v.cod;
            if (iten[1]) {
              it.numberFormat = String(iten[1]).trim().split('-') || {};
            } else {
              const resultado = iten[0].split(' ');
              it.cod = resultado.length > 2 ? resultado[0] + ' ' + resultado[1] : resultado[0];
              it.numberFormat = String(resultado.length > 2 ? resultado[2] : resultado[1]).trim().split('-') || {};
            }
            it.maxResult = true;
            return it;
          }
          it.maxResult = false;
          it.lottery = v.cod;
          it.numberFormat = String(it.number).trim().split('');
          it.groupFormat = String(it.group).trim().split(' ');
          return it.cod === 'SOMA' ? null : it;
        }));
      });
    });
    const lastResult = async () => {
      initDate.value = moment__WEBPACK_IMPORTED_MODULE_2___default()().subtract(1, 'day');
      getResultado();
      openDate.value = false;
    };
    const todayResult = async () => {
      initDate.value = moment__WEBPACK_IMPORTED_MODULE_2___default()();
      console.log('object', initDate.value);
      getResultado();
      openDate.value = false;
    };
    const getEntity = (draw, results) => {
      if (results) {
        const winner = results.winners.find(it => parseInt(it.prizeRange) === draw.prize.number);
        return winner.entity.entityTypeId === 6 ? winner.entity.cod.substr(-4) : winner.entity.cod;
      }
    };
    const getResultado = () => {
      // busca resultado
      // start loader
      store.dispatch('resultados/setLoader', true);
      store.dispatch('resultados/getResultados', {
        produto: prodAtual.value,
        dtEnd: moment__WEBPACK_IMPORTED_MODULE_2___default()(initDate.value).format('YYYY-MM-DD')
      }).then(() => {
        // state.show = false
      }).catch(e => {
        if (e.message === 'Token não fornecido') {
          console.log('abriu modal');
          Events.emit('modal::cadastro', true);
        }
      }).finally(() => {
        // state.show = false
        store.dispatch('resultados/setLoader', false);
      });
    };
    const openDateFN = () => {
      // busca resultado
      openDate.value = true;
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.watch)(initDate, val => {
      store.dispatch('resultados/setFiltros', {
        data: moment__WEBPACK_IMPORTED_MODULE_2___default()(val).format('YYYY-MM-DD'),
        dataFormat: moment__WEBPACK_IMPORTED_MODULE_2___default()(val).format('DD/MM/YYYY')
      });
      getResultado();
      openDate.value = false;
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.watch)(prodAtual, val => {
      store.dispatch('resultados/resetarResultados');
      openDate.value = true;
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.onMounted)(() => {
      store.dispatch('listagemProdutos/getProdutos');
      getResultado();
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.onBeforeUnmount)(() => {
      const bugModal = document.querySelector('.modal-backdrop');
      if (bugModal) bugModal.remove();
    });
    return {
      loader,
      produto,
      listResult,
      formatResult,
      filtros,
      prodAtual,
      instantaneaResultadoDisabled,
      getEntity,
      initDate,
      openDate,
      datepicker,
      openDateFN,
      lastResult,
      todayResult
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/resultados/index.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D