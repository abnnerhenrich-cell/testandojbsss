__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/resgate',
  name: 'resgate',
  component: () => Promise.all(/*! import() | resultado */[__webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("node_modules_swiper_swiper_esm_js"), __webpack_require__.e("node_modules_swiper_modules_navigation_navigation_min_css-node_modules_swiper_modules_paginat-a247a3"), __webpack_require__.e("node_modules_css-loader_dist_cjs_js_clonedRuleSet-22_use_1_node_modules_vue-loader_dist_style-9c477f"), __webpack_require__.e("src_views_resultados_index_vue"), __webpack_require__.e("node_modules_vueform_multiselect_dist_multiselect_js-node_modules_vue-recaptcha_dist_vue-reca-9c5a64"), __webpack_require__.e("resultado")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/resgate/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/resgate/router.js?