__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/bonus',
  name: 'bonus',
  component: () => Promise.all(/*! import() | bonus */[__webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("bonus")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/bnpBonus/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/bnpBonus/router.js?