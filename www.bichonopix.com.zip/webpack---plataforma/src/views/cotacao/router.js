__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/cotacoes',
  name: 'cotacoes',
  component: () => __webpack_require__.e(/*! import() */ "src_views_cotacao_index_vue").then(__webpack_require__.bind(__webpack_require__, /*! ./index.vue */ "./src/views/cotacao/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/cotacao/router.js?