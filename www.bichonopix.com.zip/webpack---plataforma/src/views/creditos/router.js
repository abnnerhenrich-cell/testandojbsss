__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/credito-pix',
  name: 'creditos',
  component: () => __webpack_require__.e(/*! import() | credito-pix */ "credito-pix").then(__webpack_require__.bind(__webpack_require__, /*! ./index.vue */ "./src/views/creditos/index.vue"))
});

//# sourceURL=webpack://plataforma/./src/views/creditos/router.js?