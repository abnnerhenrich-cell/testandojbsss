__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  path: '/:pathMatch(.*)*',
  name: 'auth',
  component: () => Promise.all(/*! import() | auth */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("node_modules_vue3-qr-reader_dist_vue3-qr-reader_common_js"), __webpack_require__.e("src_views_auth_components_modalCadastro_vue"), __webpack_require__.e("src_views_auth_components_modalLogin_vue"), __webpack_require__.e("src_views_auth_components_modalRecuperarSenha_vue"), __webpack_require__.e("conferir-bilhete"), __webpack_require__.e("auth")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/auth/index.vue")),
  children: [{
    path: '/home',
    name: 'home',
    component: () => Promise.all(/*! import() | auth */[__webpack_require__.e("node_modules_bootstrap_dist_js_bootstrap_esm_js"), __webpack_require__.e("src_assets_bilhete_direita_svg-src_assets_bilhete_esquerda_svg-src_assets_bilhete_bottom_png--dbc76b"), __webpack_require__.e("src_components_modal_vue"), __webpack_require__.e("node_modules_vuelidate_core_dist_index_esm_js-node_modules_vuelidate_validators_dist_index_esm_js"), __webpack_require__.e("node_modules_vue3-qr-reader_dist_vue3-qr-reader_common_js"), __webpack_require__.e("src_views_auth_components_modalCadastro_vue"), __webpack_require__.e("src_views_auth_components_modalLogin_vue"), __webpack_require__.e("src_views_auth_components_modalRecuperarSenha_vue"), __webpack_require__.e("conferir-bilhete"), __webpack_require__.e("auth")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index */ "./src/views/auth/index.vue"))
  }]
});

//# sourceURL=webpack://plataforma/./src/views/auth/router.js?