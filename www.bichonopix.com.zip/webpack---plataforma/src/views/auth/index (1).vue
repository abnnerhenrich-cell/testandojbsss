__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_modalLoginWhatsapp_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/modalLoginWhatsapp.vue */ "./src/views/auth/components/modalLoginWhatsapp.vue");
/* harmony import */ var _components_modalConferirBilhete_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/modalConferirBilhete.vue */ "./src/views/auth/components/modalConferirBilhete.vue");
/* harmony import */ var _components_modalLogin_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/modalLogin.vue */ "./src/views/auth/components/modalLogin.vue");
/* harmony import */ var _components_modalCadastro_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/modalCadastro.vue */ "./src/views/auth/components/modalCadastro.vue");
/* harmony import */ var _components_modalRecuperarSenha__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/modalRecuperarSenha */ "./src/views/auth/components/modalRecuperarSenha.vue");
/* harmony import */ var _components_modalResetarSenha__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/modalResetarSenha */ "./src/views/auth/components/modalResetarSenha.vue");
/* harmony import */ var _components_modalSolicitarLocalizacao__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/modalSolicitarLocalizacao */ "./src/views/auth/components/modalSolicitarLocalizacao.vue");
/* harmony import */ var _views_layout_menuFooter_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/views/layout/menuFooter.vue */ "./src/views/layout/menuFooter.vue");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");








// import ResultadoAnimado from './components/animationResultado.vue'





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Home',
  components: {
    ModalWhatsapp: _components_modalLoginWhatsapp_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    modalBilhete: _components_modalConferirBilhete_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    modalLogin: _components_modalLogin_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    modalCadastro: _components_modalCadastro_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    modalRecuperarSenha: _components_modalRecuperarSenha__WEBPACK_IMPORTED_MODULE_4__["default"],
    modalResetarSenha: _components_modalResetarSenha__WEBPACK_IMPORTED_MODULE_5__["default"],
    modalSolicitarLocalizacao: _components_modalSolicitarLocalizacao__WEBPACK_IMPORTED_MODULE_6__["default"],
    MenuFooter: _views_layout_menuFooter_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    // BtnAjuda: defineAsyncComponent(() => import('@/components/btnAjuda')),
    modalTermoUso: (0,vue__WEBPACK_IMPORTED_MODULE_9__.defineAsyncComponent)(() => __webpack_require__.e(/*! import() */ "src_views_auth_components_modalTermoUso_vue").then(__webpack_require__.bind(__webpack_require__, /*! ./components/modalTermoUso.vue */ "./src/views/auth/components/modalTermoUso.vue"))),
    // ResultadoAnimado,
    popupCookie: (0,vue__WEBPACK_IMPORTED_MODULE_9__.defineAsyncComponent)(() => __webpack_require__.e(/*! import() */ "src_views_auth_components_popupCookie_vue").then(__webpack_require__.bind(__webpack_require__, /*! ./components/popupCookie */ "./src/views/auth/components/popupCookie.vue"))),
    Banner: (0,vue__WEBPACK_IMPORTED_MODULE_9__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_swiper_swiper_esm_js"), __webpack_require__.e("node_modules_swiper_modules_navigation_navigation_min_css-node_modules_swiper_modules_paginat-a247a3"), __webpack_require__.e("src_views_auth_components_banner_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/banner.vue */ "./src/views/auth/components/banner.vue"))),
    BannerGanhadores: (0,vue__WEBPACK_IMPORTED_MODULE_9__.defineAsyncComponent)(() => Promise.all(/*! import() */[__webpack_require__.e("node_modules_swiper_swiper_esm_js"), __webpack_require__.e("node_modules_swiper_modules_navigation_navigation_min_css-node_modules_swiper_modules_paginat-a247a3"), __webpack_require__.e("src_views_auth_components_bannerGanhadores_vue")]).then(__webpack_require__.bind(__webpack_require__, /*! @/views/auth/components/bannerGanhadores.vue */ "./src/views/auth/components/bannerGanhadores.vue")))
  },
  mounted() {
    const vm = this;
    if (_core_service_session__WEBPACK_IMPORTED_MODULE_8__["default"].get('auth-token')) {
      const load = vm.$loading.show();
      // eslint-disable-next-line
      // anj_21f536a0_138f_4ad2_aa97_f06ce522506d.init() /* link de verificacao de certificado  */

      vm.getDadosUsuario().then(() => {
        load.hide();
        vm.closeModalResetarSenha();
        vm.closeModalRecuperarSenha();
        setTimeout(() => {
          vm.$router.push({
            name: 'home'
          });
        }, 1000);
      }).catch(e => {
        console.log(e);
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_10__._alert)('Sessão expirada !!', 'error');
        _core_service_session__WEBPACK_IMPORTED_MODULE_8__["default"].remove('auth-token');
      });
    } else {
      // this.verificarLocalizacao()
      this.verificarPopupCookie();
    }
  },
  methods: {
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_11__.mapActions)('login', ['getDadosUsuario']),
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_11__.mapActions)('saldos', ['getSaldos'])
  },
  computed: {
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_11__.mapGetters)(['auth'])
  },
  setup() {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_9__.getCurrentInstance)();
    const {
      $loading,
      Events
    } = app.appContext.config.globalProperties;
    const route = (0,vue_router__WEBPACK_IMPORTED_MODULE_12__.useRoute)();
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_11__.useStore)();
    const dadosFormLogin = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const exibirPopupCookie = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const produtos = (0,vue__WEBPACK_IMPORTED_MODULE_9__.computed)(() => store.getters['listagemProdutos/listProdutos']);
    const setMenu = () => store.dispatch('setMenu', false);
    const isAuth = (0,vue__WEBPACK_IMPORTED_MODULE_9__.computed)(() => store.getters['login/auth']);
    const eventOpenModal = v => {
      setMenu(false);
      Events.emit(v, true);
    };
    // se alterar valor tem que abrir modais
    const openModal = (0,vue__WEBPACK_IMPORTED_MODULE_9__.computed)(() => store.getters['login/loginOpenModal']);
    const selectProduct = productId => {
      if (!isAuth.value) return Events.emit('open::modal::login::produto::selecionado', productId);
      if (productId === 'RASPADINHA') return router.push({
        name: 'raspadinha'
      });
      const load = $loading.show();
      store.dispatch('listagemProdutos/setSelectProdutoAtual', productId);
      store.dispatch('listagemProdutos/getModalitiesCategories', {
        id: productId
      }).then(() => {
        store.dispatch('listagemProdutos/getLoteriasProdutos', productId).then(() => {
          router.push({
            name: 'apostas'
          }).then(() => {
            load.hide();
          });
        });
      }).catch(e => {
        load.hide();
        if (e === 'Token não fornecido') {
          Events.emit('open::modal::login', true);
        } else {
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_10__._alert)(e, 'error');
        }
      });
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_9__.watch)(openModal, v => {
      if (v === 'resultado') {
        eventOpenModal('modal::cadastro');
      }
    });
    const showModalRecuperarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const showModalResetarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const showModalSolicitarLocalizacao = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const modalTermo = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)(false);
    const token = (0,vue__WEBPACK_IMPORTED_MODULE_9__.ref)('');

    // eslint-disable-next-line
    const verificacaoNotification = () => {
      // abrir modal de notificação mensagem firebase
      if ('Notification' in window && Notification.permission === 'default') {
        Events.emit('open::modal::notification', true);
      }
    };
    const verificarLocalizacao = () => {
      // abrir modal de notificação mensagem firebase
      navigator.permissions.query({
        name: 'geolocation'
      }).then(result => {
        if (result.state === 'prompt') {
          showModalSolicitarLocalizacao.value = true;
        }
        // Don't do anything if the permission was denied.
      });
    };

    const opemModalRecuperarSenha = v => {
      showModalRecuperarSenha.value = true;
    };
    const closeModalRecuperarSenha = () => {
      showModalRecuperarSenha.value = false;
    };
    const closeModalResetarSenha = () => {
      showModalResetarSenha.value = false;
      router.push({
        name: 'home'
      });
    };
    const success = () => {
      console.log('Localização aceito');
    };
    const closeModelSolicitarLocalizacao = val => {
      if (val) {
        navigator.geolocation.getCurrentPosition(success);
        showModalSolicitarLocalizacao.value = false;
      }
      showModalSolicitarLocalizacao.value = false;
    };
    const closePopup = val => {
      exibirPopupCookie.value = false;
    };
    const openPopupCookies = val => {
      exibirPopupCookie.value = true;
    };
    const verificarPopupCookie = val => {
      const aceitoCookies = _core_service_session__WEBPACK_IMPORTED_MODULE_8__["default"].get('aceito-cookies', true);
      if (!aceitoCookies) {
        setTimeout(() => {
          exibirPopupCookie.value = true;
        }, 1000);
      }
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_9__.onMounted)(async () => {
      store.dispatch('carrinho/setSessionCart');
      store.dispatch('listagemProdutos/getProdutos');
      Events.on('open::modal::termoUso', e => {
        modalTermo.value = e;
      });
      Events.on('event::modal::cadastro', e => {
        console.log('modal::cadastro', e);
        eventOpenModal('modal::cadastro', e);
      });
      Events.on('event::modal::login', e => {
        console.log('modal::login', e);
        eventOpenModal('modal::login', e);
      });
      Events.on('modal::close', e => {
        showModalRecuperarSenha.value = false;
        store.dispatch('login/openModal', null);
      });
      const {
        codauth,
        resetPassword
      } = route.query;
      if (codauth) {
        const load = $loading.show();
        const [name, password] = window.atob(codauth).split(':');
        store.dispatch('login/userLogin', {
          name,
          password
        }).then(() => {
          store.dispatch('login/getDadosUsuario', {
            name,
            password
          }).then(res => {
            if (res.data.user.jsonFlags.resetPassword) {
              router.push({
                name: 'perfil'
              });
              return;
            }
            (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_10__._alert)('Login Realizado', 'success');
            router.push({
              name: 'home'
            });
          }).finally(() => load.hide());
        }).catch(() => {
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_10__._alert)('Dados de acesso inválidos', 'error');
          load.hide();
        });
        return;
      }
      if (resetPassword) {
        showModalResetarSenha.value = true;
        token.value = resetPassword;
        return false;
      }

      // verificacaoNotification()
    });

    return {
      opemModalRecuperarSenha,
      showModalRecuperarSenha,
      closeModalRecuperarSenha,
      showModalResetarSenha,
      closeModalResetarSenha,
      token,
      showModalSolicitarLocalizacao,
      closeModelSolicitarLocalizacao,
      openModal,
      eventOpenModal,
      router,
      verificarLocalizacao,
      dadosFormLogin,
      modalTermo,
      exibirPopupCookie,
      closePopup,
      verificarPopupCookie,
      openPopupCookies,
      isAuth,
      produtos,
      selectProduct
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/index.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D