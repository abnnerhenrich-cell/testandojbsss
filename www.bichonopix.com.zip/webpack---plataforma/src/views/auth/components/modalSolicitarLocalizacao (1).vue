__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @vuelidate/core */ "./node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _vuelidate_validators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @vuelidate/validators */ "./node_modules/@vuelidate/validators/dist/index.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
// import { getCurrentInstance, onMounted, reactive, ref } from 'vue'


// import IconSetaDiagonal from './iconSetaDiagonal'




// import { useRoute } from 'vue-router'
// import { size } from 'lodash'
// import moment from 'moment'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalCadastro',
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
    // IconSetaDiagonal
  },

  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(_, {
    emit
  }) {
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_4__.useStore)();
    const v$ = (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_2__["default"])();

    // variaveis
    const pixConfirmation = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)('');
    const dadosPix = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const dadosUsuario = store.getters['perfil/listUser'];
      return dadosUsuario.pix ? dadosUsuario.pix : {
        keyCode: ''
      };
    });
    const dadosUsuario = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['perfil/listUser']);

    /* METHODS */
    const confirmarPix = async () => {
      const valid = await v$.value.$validate();
      if (!valid) return;
      const data = {
        pixData: {
          ...dadosPix.value,
          name: (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__.convertToSlug)(dadosUsuario.value.fullName).toUpperCase(),
          city: (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__.convertToSlug)(dadosPix.value.city).toUpperCase()
        }
        // pendingOperationId: this.premioSolicitarPagamento ? this.premioSolicitarPagamento.id : null
      };

      emit('chavePixConfirmado', data.pixData);
    };
    return {
      v$,
      confirmarPix,
      dadosPix,
      pixConfirmation,
      emit
    };
  },
  validations() {
    return {
      pixConfirmation: {
        required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_5__.required,
        $autoDirty: true,
        validatePix(param, vm) {
          return param === vm.dadosPix.keyCode;
        }
      }
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalSolicitarLocalizacao.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D