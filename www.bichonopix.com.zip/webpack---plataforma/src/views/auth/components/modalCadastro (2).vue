__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @vuelidate/core */ "./node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @vuelidate/validators */ "./node_modules/@vuelidate/validators/dist/index.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var maska__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! maska */ "./node_modules/maska/dist/maska.esm.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var vue_recaptcha__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue-recaptcha */ "./node_modules/vue-recaptcha/dist/vue-recaptcha.es.js");













/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalCadastro',
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    VueRecaptcha: vue_recaptcha__WEBPACK_IMPORTED_MODULE_9__.VueRecaptcha
  },
  setup() {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_0__.getCurrentInstance)();
    const {
      Events,
      $loading
    } = app.appContext.config.globalProperties;
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_10__.useStore)();
    const show = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const titulo = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)('Cadastre-se');
    const showButtonLogin = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const mostrarInput = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const disableInputCPF = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const v$ = (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_2__["default"])();
    // eslint-disable-next-line
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const currentStep = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(1);
    const openModalTermo = () => {
      Events.emit('open::modal::termoUso', true);
    };
    const resetValidation = () => {
      v$.value.form.cpf.$reset();
      v$.value.form.formatPhone.$reset();
      v$.value.form.email.$reset();
      v$.value.form.password.$reset();
      v$.value.form.password_confirmation.$reset();
      v$.value.form.termo.$reset();
    };
    const form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.reactive)({
      firstName: '',
      lastName: '',
      cpf: '',
      fullName: '',
      birthFormat: '',
      birthDay: '',
      birthMonth: '',
      birthYear: '',
      email: '',
      formatPhone: null,
      password: null,
      password_confirmation: null,
      termo: false,
      receberInfos: false,
      ddiPhone: null,
      dddPhone: null
    });
    const clearForm = () => {
      form.firstName = '';
      form.lastName = '';
      form.cpf = '';
      form.birthFormat = '';
      form.fullName = '';
      form.birthDay = '';
      form.birthMonth = '';
      form.birthYear = '';
      form.email = '';
      form.formatPhone = null;
      form.password = null;
      form.password_confirmation = null;
      form.termo = false;
      form.receberInfos = false;
      form.ddiPhone = null;
      form.dddPhone = null;
    };
    const recaptcha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)('');
    const keyRecaptchaSite = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => (_core_config__WEBPACK_IMPORTED_MODULE_8___default().KEY_RECAPTCHA_SITE));
    const checkMethod = value => {
      // when you need a reCAPTCHA challenge
      recaptcha.value = value;
    };
    const expiredMethod = () => {
      recaptcha.value = '';
    };
    const renderMethod = value => {
      recaptcha.value = '';
    };
    const errorMethod = value => {
      recaptcha.value = '';
    };
    const recaptchaReset = () => {
      recaptcha.value = '';
      // Events.emit('add::currency::value', 0)
    };

    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(() => {
      // Events.on('modal::cadastro', e => {
      //   show.value = e
      //   showButtonLogin.value = false
      // })
      Events.on('modal::close', e => {
        show.value = e;
        mostrarInput.value = false;
        currentStep.value = 1;
        clearForm();
        resetValidation();
        store.dispatch('login/openModal', false);
      });
      Events.on('modal::cadastro::resultado', e => {
        show.value = e;
        _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].set('redirect-result', true);
        titulo.value = 'Cadastre-se e veja os resultados !';
        showButtonLogin.value = true;
      });
    });
    const validaCPF = async () => {
      const loader = $loading.show();
      disableInputCPF.value = true;
      const {
        cpf
      } = Object.assign({}, form);
      store.dispatch('cadastroUsuario/verificaCPF', {
        params: {
          cpf: cpf.replace(/\D/g, '')
        }
      }).then(result => {
        if (result.Result) {
          mostrarInput.value = true;
          const formatBirthDate = new Date(result.Result.DataNascimento);
          form.birth = moment__WEBPACK_IMPORTED_MODULE_5___default()(result.Result.DataNascimento).format('YYYY-MM-DD');
          form.birthDay = formatBirthDate.getDate();
          form.birthMonth = (formatBirthDate.getMonth() + 1).toString().padStart(2, '0');
          form.birthYear = formatBirthDate.getFullYear();
          form.fullName = result.Result.NomePessoaFisica;
          formatFullName();
        } else {
          form.cpf = null;
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(result.Message, 'error');
        }
      }).catch(err => {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(err.message, 'error');
      }).finally(() => {
        loader.hide();
        disableInputCPF.value = false;
      });
    };
    const formatFullName = () => {
      const nome = form.fullName.split(' ');
      form.firstName = nome[0];
      form.lastName = nome.slice(1).join(' ');
    };

    // remove uppercase do email no cadastro
    const lowerEmail = () => {
      form.email = (0,lodash__WEBPACK_IMPORTED_MODULE_4__.toLower)(form.email);
    };
    const ativarValidaCPFMethods = () => {
      if (parseInt(form.cpf.length) === 14 && !mostrarInput.value) {
        validaCPF();
      }
      if (parseInt(form.cpf.length) === 13 || !parseInt(form.cpf.length)) {
        mostrarInput.value = false;
        form.birthDay = null;
        form.birthMonth = null;
        form.birthYear = null;
        form.firstName = null;
      }
    };
    const limitDayInput = () => {
      if (parseInt(form.birthDay) > 31) {
        form.birthDay = 31;
      }
    };
    const limitMonthInput = () => {
      if (parseInt(form.birthMonth) > 12) {
        form.birthMonth = 12;
      }
    };
    const avancar = () => {
      if (currentStep.value < 2) {
        currentStep.value += 1;
      }
    };
    // const dadosCPF = store.getters['cadastroUsuario/getDadosCPF']

    // const formatFullName = computed(() => `${form.firstName} ${form.lastName}`)

    /* METHODS */
    const finishCadastro = async () => {
      const valid = await v$.value.$validate();
      if (!valid) return;
      if (!recaptcha.value) {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Marcar o Recaptcha', 'error');
        return;
      }
      const loader = $loading.show();
      const dados = Object.assign({}, form);

      // // formata full name
      // dados.fullName = formatFullName

      // formata dados do telefone
      const phone = form.formatPhone.replace(/\D/g, '');
      dados.ddiPhone = '55';
      dados.dddPhone = String(phone).substring(0, 2).trim();
      dados.phone = phone.substring(2, (0,lodash__WEBPACK_IMPORTED_MODULE_4__.size)(phone));
      // dados.birth = dados.birth !== 'Invalid date' ? dados.birth : moment().subtract(18, 'years').format('YYYY-MM-DD')
      dados.acceptTermsUse = form.termo;
      dados.whatsappActive = form.receberInfos;
      dados.cpf = form.cpf.replace(/\D/g, '');
      dados.recaptcha = recaptcha.value;

      /* influencer */
      const btag = _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].get('btag');
      if (btag) {
        dados.btag = btag;
      }
      store.dispatch('cadastroUsuario/cadastrar', dados).then(async () => {
        await efetuarLogin(dados.cpf, form.password);
        show.value = false;
      }).catch(err => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(err.message, 'error');
      }).finally(() => {
        loader.hide();
        show.value = false;
        _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].remove('btag');
      });
    };
    const efetuarLogin = async (phone, password) => {
      const load = $loading.show();
      store.dispatch('login/userLogin', {
        name: phone,
        password: password
      }).then(() => {
        store.dispatch('login/getDadosUsuario').then(res => {
          router.push({
            name: 'home'
          });
          Events.emit('modal::close');
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Cadastro criado com Sucesso!', 'success');
        }).finally(() => load.hide());
      });
    };

    // fechar modal atual e abrir de login
    const loginModal = () => {
      show.value = false;
      Events.emit('modal::login', true);
    };
    return {
      form,
      show,
      v$,
      finishCadastro,
      titulo,
      loginModal,
      showButtonLogin,
      openModalTermo,
      validaCPF,
      limitDayInput,
      limitMonthInput,
      mostrarInput,
      ativarValidaCPFMethods,
      resetValidation,
      disableInputCPF,
      currentStep,
      avancar,
      clearForm,
      efetuarLogin,
      lowerEmail,
      keyRecaptchaSite,
      recaptchaReset,
      checkMethod,
      expiredMethod,
      renderMethod,
      errorMethod
    };
  },
  watch: {
    'form.fullName'(v, old) {
      if (v === old) return;
      const format = String(v).replace(/[^\w\s]|\d/g, '').replace('_', '').trim();
      this.form.fullName = format.replace('  ', ' ');
    },
    'form.birthFormat'(v, old) {
      if (v === old) return;
      const format = (0,maska__WEBPACK_IMPORTED_MODULE_7__.mask)(v === 'Invalid date' ? moment__WEBPACK_IMPORTED_MODULE_5___default()().subtract(18, 'years').format('DDMMYYYY') : v, '##/##/####');
      this.form.birthFormat = (0,lodash__WEBPACK_IMPORTED_MODULE_4__.last)(format) === '/' ? format.substring(0, (0,lodash__WEBPACK_IMPORTED_MODULE_4__.size)(format) - 1) : format;
      this.form.birth = moment__WEBPACK_IMPORTED_MODULE_5___default()(format, 'DD/MM/YYYY').format('YYYY-MM-DD');
    }
  },
  validations() {
    return {
      form: {
        formatPhone: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(16),
          $autoDirty: true
        },
        fullName: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(4),
          $autoDirty: true
        },
        email: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          email: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.email,
          $autoDirty: true
        },
        firstName: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(4),
          $autoDirty: true
        },
        lastName: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(4),
          $autoDirty: true
        },
        cpf: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(4),
          $autoDirty: true
        },
        password: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(8),
          $autoDirty: true
        },
        password_confirmation: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          sameAsPassword: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.sameAs)(this.form.password),
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.minLength)(4),
          $autoDirty: true
        },
        // birthFormat: {
        //   maiorIdade (param, it) {
        //     if (!size(it.birthFormat)) return false
        //     const date = moment(it.birthFormat, 'DD/MM/YYYY')
        //     const limit = moment().subtract(150, 'years').format() // limite de idade
        //     const min = moment().subtract(18, 'years').format() // limite de idade
        //     if (!date.isValid()) return false
        //     if (!date.isBetween(limit, min)) return false
        //     return true
        //   },
        //   minLength: minLength(10),
        //   required,
        //   $autoDirty: true,
        // },

        termo: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_12__.required,
          $autoDirty: true,
          validateTermo(param, obj) {
            if (obj.termo === true) return true;
            return false;
          }
        }
        // password: { required, minLength: minLength(4), $autoDirty: true },
        // password_confirmation: {
        //   required,
        //   $autoDirty: true,
        //   validateConfirmPassword (param, obj) {
        //     if (obj.password === obj.password_confirmation) return true
        //     return false
        //   }
        // }
      }
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalCadastro.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D