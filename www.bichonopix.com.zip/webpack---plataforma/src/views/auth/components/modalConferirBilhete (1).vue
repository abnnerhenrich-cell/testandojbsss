__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var _views_conferirBilhete_index_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/views/conferirBilhete/index.vue */ "./src/views/conferirBilhete/index.vue");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalConferirBilhete',
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    ConferirBilhete: _views_conferirBilhete_index_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  setup() {
    const phone = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(null);
    const show = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    return {
      phone,
      show
    };
  },
  mounted() {
    const vm = this;
    vm.Events.on('modal::conferir::bilhete', e => {
      vm.show = e;
    });
    vm.Events.on('modal::close', e => {
      vm.show = e;
    });
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalConferirBilhete.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D