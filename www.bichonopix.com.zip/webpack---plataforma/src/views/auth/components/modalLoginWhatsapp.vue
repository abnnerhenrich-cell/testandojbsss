__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-478be10c"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = ["src"];
const _hoisted_2 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "d-flex flex-row justify-content-center w-100"
}, null, -1 /* HOISTED */));
const _hoisted_3 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h6", {
  class: "text"
}, " Acesse com o seu WhatsApp ", -1 /* HOISTED */));

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Modal");
  const _directive_maska = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveDirective)("maska");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_Modal, {
    ref: "thisModal",
    visible: $setup.show,
    showButtons: false
  }, {
    title: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/logo.svg */ "./src/assets/logo.svg"),
      alt: "VerticalLoto loterias",
      class: "img-fluid w-25 mb-3"
    }, null, 8 /* PROPS */, _hoisted_1)]),
    body: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_2, _hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "tel",
      class: "text-center input w-100",
      "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => $setup.phone = $event),
      placeholder: "Ex: (62) 9000-0000"
    }, null, 512 /* NEED_PATCH */), [[_directive_maska, '(##) #####-####'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.phone]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      onClick: _cache[1] || (_cache[1] = (...args) => $setup.closeModal && $setup.closeModal(...args)),
      id: "login-whatsapp",
      class: "green w-100 mt-3"
    }, " Acessar ")]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["visible"]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalLoginWhatsapp.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D