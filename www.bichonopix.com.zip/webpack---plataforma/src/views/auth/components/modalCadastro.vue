__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-a916c8ac"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = ["src"];
const _hoisted_2 = {
  class: "stepper"
};
const _hoisted_3 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "circle"
}, "1", -1 /* HOISTED */));
const _hoisted_4 = [_hoisted_3];
const _hoisted_5 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "hr line"
}, null, -1 /* HOISTED */));
const _hoisted_6 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "circle"
}, "2", -1 /* HOISTED */));
const _hoisted_7 = [_hoisted_6];
const _hoisted_8 = {
  class: "text d-flex justify-content-center"
};
const _hoisted_9 = {
  key: 0
};
const _hoisted_10 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Informe o seu CPF ", -1 /* HOISTED */));
const _hoisted_11 = {
  id: "input-group"
};
const _hoisted_12 = ["disabled"];
const _hoisted_13 = {
  key: 0
};
const _hoisted_14 = {
  key: 0,
  class: "hr divider"
};
const _hoisted_15 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Primeiro nome ", -1 /* HOISTED */));
const _hoisted_16 = {
  key: 0
};
const _hoisted_17 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Sobrenome ", -1 /* HOISTED */));
const _hoisted_18 = {
  key: 0
};
const _hoisted_19 = {
  key: 3,
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2'])
};
const _hoisted_20 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Data de nascimento ", -1 /* HOISTED */));
const _hoisted_21 = {
  id: "input-group"
};
const _hoisted_22 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2 mb-5'])
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <span v-if=\"v$.form.birthFormat.$invalid && v$.form.birthFormat.$dirty\"> Data Nascimento deve ser maior ou igual a 18 anos </span> ")], -1 /* HOISTED */));
const _hoisted_23 = {
  key: 4,
  class: "d-flex justify-content-center"
};
const _hoisted_24 = ["disabled"];
const _hoisted_25 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("Avançar ");
const _hoisted_26 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("i", {
  class: "bi bi-arrow-right m-2 mb-1"
}, null, -1 /* HOISTED */));
const _hoisted_27 = [_hoisted_25, _hoisted_26];
const _hoisted_28 = {
  key: 1
};
const _hoisted_29 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Seu melhor número de WhatsApp ", -1 /* HOISTED */));
const _hoisted_30 = {
  key: 0
};
const _hoisted_31 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Seu melhor email ", -1 /* HOISTED */));
const _hoisted_32 = {
  key: 0
};
const _hoisted_33 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Senha ", -1 /* HOISTED */));
const _hoisted_34 = {
  key: 0
};
const _hoisted_35 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "labe-input"
}, " Confirmar senha ", -1 /* HOISTED */));
const _hoisted_36 = {
  key: 0,
  class: ""
};
const _hoisted_37 = {
  class: "mt-2 form-valid form-check checkbox-finish my-3"
};
const _hoisted_38 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "form-check-label",
  for: "flexSwitchCheckDefault"
}, " Quero receber notícias, promoções e ofertas. ", -1 /* HOISTED */));
const _hoisted_39 = {
  class: "form-check-label",
  for: "flexCheckDefault"
};
const _hoisted_40 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" Tenho mais de 18 anos e concordo com os ");
const _hoisted_41 = {
  key: 0,
  style: {
    "color": "brown"
  }
};
const _hoisted_42 = {
  class: "d-flex justify-content-center"
};
const _hoisted_43 = {
  class: "d-flex justify-content-center pt-4"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_VueRecaptcha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("VueRecaptcha");
  const _component_Modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Modal");
  const _directive_maska = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveDirective)("maska");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_Modal, {
    ref: "thisModal",
    visible: $setup.show,
    showButtons: false,
    modifyClassModal: 'default-home'
  }, {
    title: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/logo.png */ "./src/assets/logo.png"),
      alt: "VerticalLoto loterias",
      class: "img-fluid mb-3 img-logo"
    }, null, 8 /* PROPS */, _hoisted_1)]),
    body: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['step', $setup.currentStep === 1 ? 'active' : 'finish'])
    }, _hoisted_4, 2 /* CLASS */), _hoisted_5, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['step', $setup.currentStep === 2 ? 'active' : ''])
    }, _hoisted_7, 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Não remover vai voltar "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"hr line\" /> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"step active\">\r\n              <i class=\"bi bi-cash icon-stepper\"></i>\r\n            </div> ")])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h6", _hoisted_8, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.currentStep === 1 ? $setup.titulo : 'Falta pouco'), 1 /* TEXT */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['form-valid', v$.form.formatPhone.$invalid && v$.form.formatPhone.$dirty ? 'error' : '']\">\r\n        <label class=\"labe-input\"> Seu melhor número de WhatsApp </label>\r\n        <input type=\"tel\" class=\"input w-100\"  v-maska=\"'(##) # ####-####'\" v-model=\"form.formatPhone\" placeholder=\"Ex: (00) 9 0000-0000\">\r\n        <span v-if=\"v$.form.formatPhone.$invalid && v$.form.formatPhone.$dirty\"> Campo inválido </span>\r\n      </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("---------------------------------- STEP 1 ----------------------------------"), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [$setup.currentStep === 1 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.cpf.$invalid && $setup.v$.form.cpf.$dirty ? 'error' : ''])
    }, [_hoisted_10, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_11, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      disabled: $setup.disableInputCPF,
      type: "tel",
      class: "input input-cpf w-100",
      "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => $setup.form.cpf = $event),
      onInput: _cache[1] || (_cache[1] = (...args) => $setup.ativarValidaCPFMethods && $setup.ativarValidaCPFMethods(...args)),
      placeholder: "Ex: 000.000.000-00"
    }, null, 40 /* PROPS, HYDRATE_EVENTS */, _hoisted_12), [[_directive_maska, '###.###.###-##'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.cpf]]), $setup.v$.form.cpf.$invalid && $setup.v$.form.cpf.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_13, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Não apagar o button Provavelmente vai voltar! "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <button @click=\"validaCPF()\" class=\"btn-enviar\" id=\"b-recuperar\"> <i class=\"bi bi-arrow-right m-2 mb-1\"></i></button> ")])], 2 /* CLASS */), $setup.mostrarInput ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_14)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-if=\"mostrarInput\" :class=\"['form-valid mt-2', v$.form.fullName.$invalid && v$.form.fullName.$dirty ? 'error' : '']\">\r\n              <label class=\"labe-input\"> Nome </label>\r\n              <input readonly type=\"text\" class=\"input w-100 \"  v-model.trim=\"form.firstName\" placeholder=\"...\">\r\n              <span v-if=\"v$.form.fullName.$invalid && v$.form.fullName.$dirty\"> Campo inválido </span>\r\n            </div> "), $setup.mostrarInput ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: 1,
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.firstName.$invalid && $setup.v$.form.firstName.$dirty ? 'error' : ''])
    }, [_hoisted_15, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      readonly: "",
      type: "text",
      class: "input w-100",
      "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => $setup.form.firstName = $event),
      placeholder: "..."
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.firstName, void 0, {
      trim: true
    }]]), $setup.v$.form.firstName.$invalid && $setup.v$.form.firstName.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_16, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.mostrarInput ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: 2,
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.lastName.$invalid && $setup.v$.form.lastName.$dirty ? 'error' : ''])
    }, [_hoisted_17, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      readonly: "",
      type: "text",
      class: "input w-100",
      "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => $setup.form.lastName = $event),
      placeholder: "..."
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.lastName, void 0, {
      trim: true
    }]]), $setup.v$.form.lastName.$invalid && $setup.v$.form.lastName.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_18, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.mostrarInput ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_19, [_hoisted_20, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_21, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      readonly: "",
      type: "text",
      class: "input day",
      "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => $setup.form.birthDay = $event),
      placeholder: "Dia",
      onInput: _cache[5] || (_cache[5] = (...args) => $setup.limitDayInput && $setup.limitDayInput(...args))
    }, null, 544 /* HYDRATE_EVENTS, NEED_PATCH */), [[_directive_maska, '##'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.birthDay, void 0, {
      trim: true
    }]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      readonly: "",
      type: "text",
      class: "input month",
      "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => $setup.form.birthMonth = $event),
      placeholder: "Mês",
      onInput: _cache[7] || (_cache[7] = (...args) => $setup.limitMonthInput && $setup.limitMonthInput(...args))
    }, null, 544 /* HYDRATE_EVENTS, NEED_PATCH */), [[_directive_maska, '##'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.birthMonth, void 0, {
      trim: true
    }]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      readonly: "",
      type: "text",
      class: "input year",
      "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => $setup.form.birthYear = $event),
      placeholder: "Ano"
    }, null, 512 /* NEED_PATCH */), [[_directive_maska, '####'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.birthYear, void 0, {
      trim: true
    }]])])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), _hoisted_22, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['form-valid mt-2', v$.form.password.$invalid && v$.form.password.$dirty ? 'error' : '']\">\r\n              <label> Senha: </label>\r\n              <input type=\"password\" class=\"input w-100 \" v-model.trim=\"form.password\" placeholder=\"Ex: ******* \">\r\n              <span v-if=\"v$.form.password.$invalid && v$.form.password.$dirty\"> Campo inválido </span>\r\n            </div>\r\n\r\n            <div :class=\"['form-valid mt-2', v$.form.password_confirmation.$invalid && v$.form.password_confirmation.$dirty ? 'error' : '']\">\r\n              <label> Confirmar Senha: </label>\r\n              <input type=\"password\" class=\"input w-100 \" v-model.trim=\"form.password_confirmation\" placeholder=\"Ex: ******* \">\r\n              <span v-if=\"v$.form.password_confirmation.$invalid && v$.form.password_confirmation.$dirty\"> Senhas diferentes </span>\r\n            </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['mt-2 form-valid form-check form-switch', v$.form.termo.$invalid && v$.form.termo.$dirty ? 'error' : '']\" class=\"\">\r\n              <input class=\"termo form-check-input\" v-model=\"form.termo\" type=\"checkbox\" id=\"flexSwitchCheckDefault\">\r\n              <label class=\"form-check-label\" for=\"flexSwitchCheckDefault\" >\r\n                Li, concordo com os  <b class=\"itens\" @click.prevent=\"openModalTermo\" > termos e condições </b> de uso e aceito\r\n                receber notificações da VerticalLoto Loterias. (PERMITIR\r\n                LOCALIZAÇÃO)\r\n              </label>\r\n            </div> "), $setup.mostrarInput ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_23, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      disabled: !$setup.mostrarInput,
      class: "btn-avancar",
      onClick: _cache[9] || (_cache[9] = (...args) => $setup.avancar && $setup.avancar(...args)),
      id: "b-recuperar"
    }, _hoisted_27, 8 /* PROPS */, _hoisted_24)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("---------------------------------- STEP 2 ----------------------------------"), $setup.currentStep === 2 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_28, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.formatPhone.$invalid && $setup.v$.form.formatPhone.$dirty ? 'error' : ''])
    }, [_hoisted_29, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "tel",
      class: "input w-100",
      "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => $setup.form.formatPhone = $event),
      placeholder: "Ex: (00) 9 0000-0000"
    }, null, 512 /* NEED_PATCH */), [[_directive_maska, '(##) # ####-####'], [vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.formatPhone]]), $setup.v$.form.formatPhone.$invalid && $setup.v$.form.formatPhone.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_30, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-if=\"mostrarInput\" :class=\"['form-valid mt-2', v$.form.fullName.$invalid && v$.form.fullName.$dirty ? 'error' : '']\">\r\n              <label class=\"labe-input\"> Nome </label>\r\n              <input readonly type=\"text\" class=\"input w-100 \"  v-model.trim=\"form.firstName\" placeholder=\"...\">\r\n              <span v-if=\"v$.form.fullName.$invalid && v$.form.fullName.$dirty\"> Campo inválido </span>\r\n            </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.email.$invalid && $setup.v$.form.email.$dirty ? 'error' : ''])
    }, [_hoisted_31, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "text",
      class: "input w-100",
      onChange: _cache[11] || (_cache[11] = $event => $setup.lowerEmail()),
      "onUpdate:modelValue": _cache[12] || (_cache[12] = $event => $setup.form.email = $event),
      placeholder: "Ex: example@email.com"
    }, null, 544 /* HYDRATE_EVENTS, NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.email, void 0, {
      trim: true
    }]]), $setup.v$.form.email.$invalid && $setup.v$.form.email.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_32, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.password.$invalid && $setup.v$.form.password.$dirty ? 'error' : ''])
    }, [_hoisted_33, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "password",
      class: "input w-100",
      "onUpdate:modelValue": _cache[13] || (_cache[13] = $event => $setup.form.password = $event),
      placeholder: ""
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.password, void 0, {
      trim: true
    }]]), $setup.v$.form.password.$invalid && $setup.v$.form.password.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_34, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['px-2 f12', $setup.v$.form.password.minLength.$invalid ? 'password-validation-error' : ''])
    }, "( Senha deve conter no mínimo 8 caracteres )", 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid mt-2', $setup.v$.form.password_confirmation.$invalid && $setup.v$.form.password_confirmation.$dirty ? 'error' : ''])
    }, [_hoisted_35, (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "password",
      class: "input w-100",
      "onUpdate:modelValue": _cache[14] || (_cache[14] = $event => $setup.form.password_confirmation = $event),
      placeholder: ""
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.form.password_confirmation, void 0, {
      trim: true
    }]]), $setup.v$.form.password_confirmation.$invalid && $setup.v$.form.password_confirmation.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_36, " Senhas diferentes ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_37, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      class: "termo form-check-input",
      "onUpdate:modelValue": _cache[15] || (_cache[15] = $event => $setup.form.receberInfos = $event),
      type: "checkbox",
      id: "flexSwitchCheckDefault"
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelCheckbox, $setup.form.receberInfos]]), _hoisted_38]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([['form-valid form-check checkbox-finish', $setup.v$.form.termo.$invalid && $setup.v$.form.termo.$dirty ? 'error-termo' : ''], ""])
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      class: "termo form-check-input",
      "onUpdate:modelValue": _cache[16] || (_cache[16] = $event => $setup.form.termo = $event),
      type: "checkbox",
      id: "flexSwitchCheckDefault"
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelCheckbox, $setup.form.termo]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", _hoisted_39, [_hoisted_40, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
      onClick: _cache[17] || (_cache[17] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)((...args) => $setup.openModalTermo && $setup.openModalTermo(...args), ["prevent"])),
      class: "pointer-link",
      style: {
        "color": "#EF8229"
      }
    }, "termos, condições e políticas de privacidade do Bicho no PIX.")]), $setup.v$.form.termo.$invalid && $setup.v$.form.termo.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_41, " Campo inválido ")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_42, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_VueRecaptcha, {
      ref: "recaptcha",
      sitekey: $setup.keyRecaptchaSite,
      onVerify: $setup.checkMethod,
      onExpired: $setup.expiredMethod,
      onRender: $setup.renderMethod,
      onError: $setup.errorMethod,
      class: "mt-3 pb-3"
    }, null, 8 /* PROPS */, ["sitekey", "onVerify", "onExpired", "onRender", "onError"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"\">\r\n              <input class=\"form-check-input\" type=\"checkbox\" id=\"flexCheckDefault\">\r\n              <label class=\"form-check-label\" for=\"flexCheckDefault\">\r\n                Quero receber notícias, promoções e ofertas.\r\n              </label>\r\n              <div class=\"mt-2\">\r\n                <input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"flexCheckDefault\">\r\n                <label class=\"form-check-label\" for=\"flexCheckDefault\">\r\n                  Tenho mais de 18 anos e concordo com os termos, condições e políticas de privacidade do Bicho no PIX.\r\n                </label>\r\n              </div>\r\n            </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_43, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      class: "btn-avancar",
      onClick: _cache[18] || (_cache[18] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)((...args) => $setup.finishCadastro && $setup.finishCadastro(...args), ["prevent"])),
      id: "b-recuperar"
    }, "Cadastrar")])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <button @click.prevent=\"finishCadastro\" class=\"green w-100 mt-2\"> Finalizar </button> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <button v-if=\"showButtonLogin\" @click.prevent=\"loginModal\" class=\"default w-100 mt-4\"> Já tenho cadastro </button> ")])]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["visible"]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalCadastro.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D