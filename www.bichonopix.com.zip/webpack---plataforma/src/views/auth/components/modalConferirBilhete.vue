__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-52804790"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = ["src"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ConferirBilhete = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ConferirBilhete");
  const _component_Modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Modal");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_Modal, {
    ref: "thisModal",
    visible: $setup.show,
    showButtons: false
  }, {
    title: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/logo.svg */ "./src/assets/logo.svg"),
      alt: "VerticalLoto loterias",
      class: "img-fluid w-25 mb-3"
    }, null, 8 /* PROPS */, _hoisted_1)]),
    body: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ConferirBilhete)]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["visible"]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalConferirBilhete.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D