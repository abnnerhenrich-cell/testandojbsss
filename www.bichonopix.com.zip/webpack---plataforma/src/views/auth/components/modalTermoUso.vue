__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-69488402"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = ["src"];
const _hoisted_2 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "row mainRow divPrincipal"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  id: "column790",
  class: "column col-sm-12",
  "datacolumn-id": "790",
  style: {}
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "column-container vertical-top",
  style: {
    "margin-top": "2.6809651474531vh"
  },
  "aria-label": "column container",
  role: "contentinfo"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "module-container only-mobile align-center ModuleParagraph first last",
  "aria-label": "module container",
  role: "contentinfo",
  id: "m927"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "module ModuleParagraph",
  "datamodule-id": "927"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "uc-content"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "center"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("strong", null, "TERMS AND CONDITIONS")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "BNP may update, amend, edit and supplement the BNP Rules at any time. Any substantial amendment to the BNP Rules shall be notified in advance by BNP to the Account Holder, before coming into effect and will require your consent. If you do not agree with the amendment(s) to the BNP rules, you will not be permitted to continue using the Services. All references in the BNP Rules to the singular shall include the plural and vice versa. All references to “the” shall include “a/an” and vice versa.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "General Introduction, definitions and stipulations")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.1 An “Account Holder” is an individual having a contractual relationship with BNP by creating a BNP Account on the Website.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.2 A “BNP Account” is an account held by an Account Holder, for bona fide transactions, with a strict aim to establish a normal commercial relationship with BNP and with the strict purpose of conducting betting and other gaming and gambling transactions.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.3 The “Contract” is the contractual relationship between BNP and an Account Holder and shall be constituted under and governed by the BNP Rules, i.e. the “Terms and Conditions”.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.4 The “Website” is the internet gateway accessible through the internet address pbis.verticalloto.com where all current and relevant information regarding BNP operations is published, and through which the Services are provided to the Account Holders.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.5 The “Services” are the gaming and betting offers provided by BNP to the Account Holder through the Website.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.6 A “Card” refers to all types of cards with a function of “payment”, “charge”, “debit”, “credit”, “virtual” and/or similar.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.7 A “Payment Solution Provider” is an intermediary acting as a payment agent for various different payment methods.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.8 A “Financial Institution” is a bank and/or other institution regulated by an applicable domestic financial services Act or similar.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.9 “Force Majeure” refers to any occurrence or condition beyond one’s reasonable control which leads to a delay or default in the performance of the affected party’s contractual obligation and shall, for the purposes of the BNP Rules, include Acts of God, government restrictions (including the denial or cancellation of any necessary license where such denial or cancellation is made through no fault of the affected party), wars, outbreak of hostilities, riots, civil disturbances, insurrections, acts of terrorism, fire, explosions, floods, theft, malicious damage, strikes, lockouts, and/or any other cause beyond the reasonable control of the party whose performance is affected.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.10 “Client Application” shall mean the web browser application opened by the Account Holder in order to use the Services.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.11 “Software” shall mean all software used by BNP to offer and/or operate the Services and/or run the Client Application.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.12 A “Prize” is an amount, a bonus or a reward that can be won by the Account Holder.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.13 An “Inactive Account” is a BNP Account which has not recorded any log-in and/or log-out for")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "a period exceeding 12 consecutive months.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.14 Bets are cancelled if there is an inaccuracy in the names of players or teams, if the wrong odds are offered, if a wrong total is quoted, if a wrong handicap is quoted, etc. In these instances the bets are void.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.15 All trademarks, service marks and trade names as well as images, graphics, text, concepts or methodologies (collectively the “Intellectual Assets”) found on the Website, the Client Application and the material contained therein are the exclusive property of BNP and/or BNP's suppliers and partners. The Account Holder is not entitled to exploit or otherwise use any Intellectual Asset for whatever purpose, except for what is allowed by law.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Account Rules")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.1 Creation of a BNP Bet Account")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.1.1 An individual cannot participate in a game for money unless that individual is an Account Holder. To be registered as a player, an individual must register personally and submit an application for registration. The following information must be provided:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- date of birth and provide valid identification showing that the player is over eighteen (18) years of age or the applicable legal age of majority as stipulated in the jurisdiction of your residence (identification documents which must be submitted include: copy of a valid identity card, passport or driving license);")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- player’s first and last name;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- player’s full residential address;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- player’s valid email address;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- a username and a password.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.1.2 An individual applying to become an Account Holder warrants and represents not to be under the age of eighteen (18) years. Minors cannot register as a player and cannot hold a BNP Account. BNP reserves the right to request additional proof of age and perform additional checks in order to verify the information provided. A BNP Account may be suspended until satisfactory proof of age is provided.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.1.3 An individual applying to become an Account Holder furthermore warrants and represents:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- to be a physical person (a legal entity will not be accepted as an Account Holder);")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be a resident of Uganda, Iraq, South Africa, Croatia, Slovenia, Greece, Sweden, Romania, Belarus, Switzerland, Lithuania, Monaco, Estonia, Latvia, Isle of Man, Afghanistan, Antigua and Barbuda, Australia, Belgium, Bulgaria, Cayman Islands, Cuba, Cyprus, Czech Republic, Denmark, France, French Guyana, French Polynesia, French Southern Territories, Guadeloupe, Germany, Hong Kong, Hungary, Iran, Ireland, Israel, Italy, Japan, Kahnawake, Libya, Macau, Malta, Martinique, Mayotte, Myanmar, Netherlands, Netherlands Antilles, North Korea, Philippines, Poland, Portugal, Réunion, Russia, Saudi, Arabia, Serbia, Singapore, Spain, Sudan, Syria, Turkey, United Kingdom, United States, Vatican City, Yemen (please be aware of particular country exclusions for Casino – Games – Live Casino, Poker and Bingo); BNP reserves the right to block the access to pbis.verticalloto.com and not to pay the winning to the players from the mentioned countries;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be a professional player in any sport, competition or league where BNP offers betting;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be restricted by limited legal capacity;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be acting on behalf of another party;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be classified as a compulsive problem gambler, and/or be included (whether voluntarily or")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "involuntarily) on any register or database of excluded players;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be depositing monies originating from criminal and/or other illegal activities;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be depositing monies through a Card which the Account Holder is not authorized to use and/or utilizing a Card in a jurisdiction in which betting and gaming are prohibited;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to be conducting criminal activities whereby a BNP Account is directly or indirectly involved;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to use the Services if it is illegal in his/her country of residence or otherwise restricted for him/her to open a gaming account, purchase or use services from BNP and/or otherwise participate in the games offered. It is the Account Holder’s responsibility to ensure his/her use of BNP's Website and Services is legal;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- not to find the Website or the Services offensive, objectionable, unfair, nor indecent; and to maintain his/her BNP Account details up-to-date in terms of the following: first and last name,")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "country of residence, valid email address and phone number.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.1.4 An individual applying for a BNP Account acknowledges and accepts:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- all definitions and stipulations as stated under the BNP Rules;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- the BNP Rules as currently published on the Website, as well as any possible future changes to the BNP Rules;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- that the Contract is governed by:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "(i) the BNP Rules as published in English;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "(ii) any regulatory provisions or other decisions made from time to time by the Governing Authorities; and")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "(iii) the Governing Law of the Place of the Contract.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Rules of acceptance of bets on sports events")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.2 The Organizer has a right to cancel any bonus, jackpot and/or any prize if the Organizer is confident the Player has implemented a system usage fraud. In this case the Organizer freezes the Player's special gaming account, and if there are any funds, makes a refund to the payment system that was used by the Player to replenish the gaming account.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.3. Arranged game")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "If the Organizer has sufficient facts to suspect the case of an arranged game, they can terminate the prize remunerations and make a re-payment of the already carried out payments to the Player's special gaming accounts. The mentioned suspicions can include data referring to sums and characteristics, as well as amounts")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "of all entry payments made via all the possible methods.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Betting rules")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "3.1 The betting company accepts bets on the outcome of sporting and other events with a deliberately unknown result, including the use of telecommunication networks.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "3.2 Every time downloading the client’s application, regardless of the use of the media resource (via Internet or mobile services), by opening an account and using an existing account, betting or participating in any games, taking any prize, the client confirms his agreement with the current version of the Rules and the obligation to act in accordance with these Rules.Anytime a user downloads the client, registers an account, uses an existing account, bets on any games, takes any winnings, etc., this signifies the User’s agreement and obligation to act in accordance with the current rules.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "3.3 BNP has the right to make any changes and additions to the rules set forth herein, the provisions and procedures of payments without an individual prior written notice. Users are notified about this with appropriate announcements. The conditions of previously staked (placed) bets remain unchanged, and bets which are accepted are subject to the posted rules at the time of acceptance.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "3.4 BNP reserves the right to refuse service to any person without disclosing the reason(s).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Policy of site use")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "4.1 BNP does not bear any responsibility for any losses or damages claimed as resulting from the use of this site or from its content. This provision equally applies to the use or misuse of the content of the site by any person, inability to access the site or use it, to delay in functioning or transmission of data, failures in communication lines, any errors, misprints or omissions in the content of the site.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "4.2 Loading photos and video from the website or its sub-sites is permitted only for private use. Publication, transmission or reproduction of this data for any other purpose is strictly prohibited.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "4.3 BNP monitors traffic of its website actively, and reserves the right to block access in cases of suspected automated betting (bots).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Glossary")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "5.1 Basic terms accepted in this edition of the rules:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“Single” – a bet on a single event;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“Express” – this is a bet on the outcome of several different events simultaneously. When you place a bet on the outcome of two or more events (for example, two different football matches), you can unite them in “Express”. To win an express bet it is necessary for you to not have any failed predictions (losses) on any of the outcomes which are included in the Express. Loss on one of the outcomes of an express bet means loss throughout the entire bet. Winnings of the express bets is equal the product of the bet amount at the coefficients of played outcomes included in the express (if on one of the bets included in the express occurs a return, then the coefficient on it equals to 1).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“System” – a set of “express bets” of a particular set of events. Each combination of the system is calculated as a separate express bet. To win in the system it is sufficient that the indicated number of predictions of the total number be correct (it is defined by name, that is, for example, in the system “3 of 4′′ it is necessary that 3 of the 4 predictions prove correct, for “5 of 7′′ it is necessary properly to predict the outcome of the five events of 7 options, etc.). It must be taken into account that because of the fact that only a part of the total bet amount is specified on each of the express of the system bet (proportional to the number of options) then the winnings by such a system bet will be less than the possible general winnings by the express bet. In some cases, when not all outcomes are predicted, the amount of winnings may be less than the amount of the bet, but in contrast to express bets, a part of the amount will be offset on account of correctly predicted outcomes.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“Chain” – bet which is a combination of “single” bets including events independent from each other. The sum of single bet of chain‘s each event is equal to the sum of chain. The client is given a chance to determine independently the order of the bets included in the chain and stake only on the first event of the chain. Thus the concept of “chain account” is imported. After the tournament of each single bet included in the chain the sum of that account is calculated. Initially it is equal to the sum of the first bet. If the sum on the chain account is less than its initial sum, the chain’s next event’s single bet is calculated by the account balance. The procedure of chain’s calculation depends on the order of bets mentioned in the given ticket but not on time. The sum which remains on the account after calculation of all bets in the chain is a subject to payment.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "If the sum on the chain account reaches zero – the chain breaks and is considered to be lost.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“Handicap” – the advantage or the leeway of the entrant of competition, expressed in goals (points/) sets, etc., which is provided by the bookmaker office to the entrant with bets on it. The result of the event subject to the handicap is determined in this way: the handicap given to the entrant is added to the corresponding result shown by the entrant in the competition. If the results thus obtained are in favor of the elected entrant, he is considered as a winner, and the bets on his win subject to the handicap win. Payments are carried out with the coefficient of winnings indicated in the description of bets. If the result is in favor of the opponent – the bets are lost. If the result subject to the handicap is a draw, then the coefficient of winnings under such a result will be equal to 1 (return of the bet);")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "For example:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Team 1")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Team 2")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Handicap 1")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Handicap 2")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Coefficient 1")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Coefficient 2")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Inter")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Cagliari")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "-1.5")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.25")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "+1.5")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.9")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1) Suppose you want to bet upon the win of Cagliari subject to handicap. The handicap betting on Cagliari (Handicap 2) is equal to “+1.5′′. To win with the bet on the handicap “+1.5′′ it is necessary that Cagliari will not lose by more than 1 goal, as handicap +1.5 will be added to goals from Cagliari. Let us analyze all the options:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Cagliari won or the teams drew or Cagliari lost by the difference of 1 goal. For example, the final score is 2-1. Taking into account the handicap (+1.5) the result 2:2.5 in favor of Cagliari (the handicap of Inter when determining the result on the rates at Cagliari is not taken into account). The bets win.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Cagliari lost by more than 1 goal difference. For example, the final score is 2-0. Taking into account the handicap (+1.5) the result is 2:1.5 in favor of Inter. In this case, the rates on winning of Cagliari taking into account the handicap (+1.5) lose.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2) Similarly, the following variants are possible when betting on a win for Inter taking into account the handicap “-1.5′′:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Inter won having the advantage of two or more goals. For example, the final score is 3-0. Taking into account the handicap (- 1.5) the result is 1.5:0 in favor of Inter. The bets win.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Inter won having the advantage of 1 goal, teams drew or Cagliari won. For example, the final score is 2-1. Taking into account the handicap -1.5, the result of the bets on Inter at handicap (-1.5) gives 0.5:1, in favor of Cagliari. In this case, the bets on Inter with the handicap -1.5 lose.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Double bet of handicap is offered (Asian handicap). Bet on victory or total taking into account the handicap, which is the multiple of 0.25 (but not of 0.5). Such bets are calculated as 2 bets with the half of sum: with the same odd and “common handicaps” and “common totals” multiple of 0.5’s near- by common value. In case when the Asian handicap is included in parlay or system, it is calculated with that odd which would be in case of single bet. In case of winning of two common bets, the bet’s odd “O” is taken into account in the calculations. If one common bet is won and the other is a subject to refund, during the calculation is taken the odd (“O”+1)/2. If both common bets are lost, the whole bet considered lost.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Event’s participant")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Handicap’s double bet (Asian handicap)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Odd")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Real")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "-0.25 (0,-0.5)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "2.0")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Barcelona")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "+0.25 (0,+0.5)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.8")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "In case 200 euro stake is made on “Real” and “Real” won: two common bets with the half of sum won and the winning is equal to 100*2.0 + 100*2.0 = 400 euros.The match was over in drawn: one common bet with the half of sum lost, and the other won with the odd “1′′ and the winning is equal to 100*0.0 + 100*1.0 = 100 euros. “Real” lost: two common bets with the half of sum lost and the winning is equal to 100*0.0 + 100*0.0 = 0 euro. In case 200 euros stake is made on “Barcelona” and ”Barcelona” won: two common bets with the half of sum won and the winning is equal to 100*1.8 + 100*1.8 = 360 euros. The match was over in draw: one common bet with the half of sum lost, and the other won with the odd “1′′ and the winning is equal to 100*1.8 + 100*1.0 = 280 euros. “Barcelona” lost: two common bets with the half of sum lost and the winning is equal to 100*0.0 + 100*0.0 = 0 euro.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "“Total” – the number of goals, pucks, points or the games, scored (thrown, gained or played) by an entrant or entrants of events.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "For example:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Suppose the total of the soccer game is set (the amount of goals scored) equal to “4′′, and a wagering is offered on the total at two outcomes: more or less of the given total.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "If the match is scored with a total of less than 4 goals (0-0, 1-0, 0-1, 1-1, etc.), bets lower than “4′′ win.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "If the match is scored with a total of more than 4 goals (4-1, 4-2, 3-2, etc.), bets lower than “4′′ lose and bets more than “4′′ win.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "If the match is scored with a total of exactly 4 goals (3-1, 4-0, 2-2, 1-3, 0-4), all bets on more than “4′′ and less than “4′′ will be refunded.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Policy of Bets")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.1 The values of the parameters (including handicaps, totals) and coefficients of the events specified in the line of the current day may change after any bet, but conditions before bets are the same, except in cases of technical and obvious mistakes in the line.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.2 As an amount of bet only the amount confirmed and registered by the company is accepted.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.3 The User is the only person who is responsible for the bet. Once a bet is made and its acceptance is confirmed, it cannot be changed or canceled by the User. BNP does not provide any guarantees with respect to the “lost” or “double” bets made by customers. Please carefully check all the bets you have made.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.4 Loss of your password cannot be a reason for the withdrawal rates or cancellation of the request for payment of winnings.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.5 A bet is accepted as soon as it is confirmed by the company. All accepted bets are displayed in the “Bet History”. In some cases there may be a delay until a bet is listed in your history. In case of any dispute the time when the bet was registered in the system of the company is considered to be its true submission time. If the User did not receive any notification about the acceptance of bet, the rate is still considered to be accepted if it is displayed in the “Bet History.”")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "6.6 Failures of communication or other technical failures in customer communications are not a reason for the cancellation of a bet if the bet has been registered in the server.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Displaying Data")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.1 The Company is not responsible for the accuracy, completeness and timeliness of the proposed information services, including data on the events of Live and mailing services.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.2 BNP makes every effort to make the information on Live events (such as results, the time of a game and the statistics of teams /players) be correct. However, this information is displayed only for informational purposes. BNP is not responsible in case of any errors in this data.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.3 BNP is not responsible and does not accept any claims regarding the accuracy of the translation from foreign languages of team names and the names of the players.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.4 If in the indicated event/match more than one member with the same surname is present and during bet acceptance the full name of the athlete or other features identifying them uniquely have not been indicated, all bets are refundable.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.5 If in the name of the match or in the name of the position one or more entrants are indicated in the line incorrectly (except for errors in translation), that is if the other team/entrant of represented tournament is indicated instead of the necessary one, all the bets on that event are recognized as invalid and a return is made. Only BNP has the right to determine the events belonging to this category.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.6 In cases when the specific details of the team such as a particular age group (for example 18 years/to 21 years/youth teams), gender (women) or the status of the team (reserve) are not indicated in the line resulting in the marking of the other team in the line instead of the declared one, all bets on this match are refundable. In other cases when incomplete name or possible grammar errors are indicated in the line, all bets remain in force. If the gender of teams is not indicated in the line, it is considered that the gender of teams is male. In case women’s teams are participating in a match it is necessary to have a detailed indication about it in the line otherwise bets on this match are a subject to return.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.7 Date and time indicated in the line are the date and time of discontinuation of betsˈ acceptance on the event (except for Live events) and do not necessarily coincide with the date and time of the actual start of the event. The actual time of the event while counting the bets is considered as the time of the start of the event, which is determined based on the official documents of the organization conducting the competition, as well as the data of BNP .")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.8 If the place of conducting a meeting is not indicated in the line, in the list of events the host of the field is indicated firstly, except for competitions of American types of sports. All the information contained in the “cap” to a particular sport, carries an ancillary character. Possible errors in the given information are not a ground for the return of bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.9 On acceptance of bets for Live Events there is a set delay, the value of which may vary depending on the sport, market, and other features, and it is determined exclusively by BNP for security and protection from subsequent bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.10 For clients convenience, taking into account the specificity of Live Events in which coefficients change very often a client can choose one of the following options: to “Accept all changes in the coefficients”, “Accept only marked-up bets” or “Do not accept bets if the coefficients change,” which determines respectively whether the bet is accepted if during the time of its arrangement the coefficient changed, at any changes of it, or just in the case when the changed bet exceeds the estimated coefficient of the bet of the client.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.11 Incorrectly indicated date of the conducted match is not a ground for cancellation of the bet.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "7.12 If the match began from the moment at which it was previously interrupted, and in the line that was not stipulated, the bets are refundable.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Interlocking events and outcomes")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "8.1 In “express” and “system” bets it is forbidden to include different events that relate to the same match, not even the ones which are interdependent directly. If in such bets were included any events that relate to the given match, this bet is refundable, even if the computer program of accepting the bettings did not block this bet during its submission. BNP reserves the exclusive right to determine whether the events are connected.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "8.2 In the game on output-absence from the group in “express” and “system” bets it is allowed only to bet on one team from the given group. If in such bets qualify-not qualify of the teams from the same group were included then the given bets are refundable, even if the computer program accepting the bets did not block this bet during its submission. BNP reserves the unique right to decide whether to accept bets on the position of qualify or not qualify in “express”, “system” and in “single” bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Obvious and technical errors")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.1 The Company is not responsible for errors in typing, transfer or counting of bets. In particular, BNP reserves the right to correct obvious errors made while entering information on betting coefficients and/or calculation of the amounts at the bets (for example, errors in the coefficients indicated in teams incorrectly, incorrectly indicated events, etc.), or declare invalid the corresponding bets even after completion of the event. In the cases of correcting obvious errors bets are returned. The most common types of technical errors are the following:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.1.1 Errors of input of coefficients – when the coefficient (or the setting of the handicap/total, etc.) is displayed without a separator (dot) or with any additional number.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Example: instead of the coefficient 1.8, 18 is displayed, instead of 2, 23 is displayed, instead of 3, 30 is displayed etc.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.1.2 “Mirror Errors” – when the coefficients for players are displayed in a diametrically opposite manner. In this case, the favorite of the game (including current favorite of live event) is displayed by a coefficient exceeding the coefficient of the outsider of the given event.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Example: Basketball. Barcelona-Unicaja. The winner of the match. Instead of 1.2 and 4, 4and 1.2 is displayed.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.1.3 Writing errors – if all the coefficients are indicated correctly, however, teams are written in an incorrect order (usually occurs for events taking place on a neutral field).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Meaning for the previous example: record: Basketball. Unicaja-Barcelona. The winner of the match. 1.2 and 4 instead of Basketball. Barcelona-Unicaja. The winner of the match. 1,2 and 4")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Clear indicators of obvious errors are: very large difference in the coefficients of BNP and other bookmakers, the coefficients that are nearly impossible to give in the current situation of the match.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The right to determine whether or not an obvious or a technical error was made in any case belongs exclusively to BNP .")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.2 BNP reserves the right to abolish the bets made on deliberately incorrect coefficients and obvious errors. The customer will be informed about changes in the balance immediately.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.3 BNP reserves the right to cancel the bets even after the end of the event if these bets are won by the User as a result of a technical failure or an obvious error.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.4 In cases when due to technical reasons the User’s bets were not provided with the necessary amount of funds in the account, the bets are considered as invalid.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.5 In case of mistakenly having credited the means to the customer’s account the latter shall immediately notify BNP about the mistake. If due to an error a negative balance has been formed at the client, the betting company has the right to cancel the uncalculated bets despite the fact that they were made before the error occurred.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "9.6 The Company reserves the right to oblige the User to liability for any damage caused to it if the user used a technical or administrative error intentionally when making a deposit and/or during the receipt of money on the account.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Bets on credit")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "10.1 BNP does not accept any bets or provide services to customers on credit. All bets must be confirmed with funds existing in the account of the User.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Legal Aspects")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.1 BNP states explicitly that bet placement and betting organization, as well as participation in sports betting, multiplayer poker, game in casinos and games like lottery may be restricted by law or even prohibited in some countries. Such restrictions or prohibitions may be imposed even if the company obtained the necessary permission (license for betting or organizing gaming) to place bets and betting organizations.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The User should note that if the placement of bets or participation in sports betting, multiplayer poker and games such as lotteries is prohibited or permitted only under certain conditions, which are not followed, the responsibility for any damage caused by this rests solely with the User.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The client must also take note that the company is not required to provide clients with information, instructions and warnings in a wider range than in the present paragraph. In particular, the company is not liable for damages suffered by the User due to the violation of the relevant legislative prohibitions functioning in his/her country.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.2 You should register on one of the websites which belong to the group of BNP companies according to your country of residence. By rating or participating in the games, the User confirms that he has reached the lowest age of consent limited by law of his country, and confirms his/her capacity to enter into the agreement with the company. In case of non-fulfillment of these requirements the User’s account will be closed and necessary measures will be applied.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.3 The User agrees that his personal information provided to the company during the pool betting, games in multiplayer poker, casino games and games such as lotteries, as well as in any other game is stored and used by automatic means.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.4 You have registered on websites which belong to the group of BNP companies more than once and/or you have more than one account. In this case, the Company has the right to block all the accounts at its discretion and to leave only one account corresponding to the country of residence.By registering the User confirms the exclusive intellectual property of the company’s regulations, as well as the system controlled by them.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.5 The Company reserves the right to inform Users about special promotions and new products by telephone and e-mail.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.6 Legal relations between the User and the company are a subject to laws of Curacao and are regulated by it with the exception of the appropriate legal rules of international private law. The place of performance of all obligations at betting and gaming, as well as at the appropriate bets, is Curacao. All disputes arising over or regarding bets made by customers, are resolved if it does not contradict the law, by the court in Curacao, having the relevant territorial and subject matter jurisdiction.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.7 The Company expressly states that it does not provide users with any advice (consultation) on tax matters and/or legal matters.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.8 No disputes about the bets can lead to a lawsuit, legal action, as well as claims on bookmaker licenses if the company complies with the provisions of arbitration.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.9 In case of any claims and disputes from Users’ side and people representing their parties, the company’s liabilities are limited by the size of bets or its possible winnings.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.10 In case of any disputes or claims the database of BNP has priority over any other data.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.11 If there is discrepancy between the English version of these rules and the translation into another language, the English version is considered to be the correct one.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.12 Any matters of dispute including claims about the results of the event are accepted to be reviewed by the bookmaker office within 5 days from the end of the sporting event.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "11.13 BNP does not hold Users’ funds in segregated or separately protected bank accounts. It is important for the User to understand that deposits of BNP are not in banks and no interest is accrued upon them.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Restrictions on rates")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "12.1 Bookmaker company has the right not to accept bets from any person without giving any reason and reserves the right to close or temporarily block the accounts of individual Users without prior notice.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "12.2 Minimum and maximum size of bets for all sporting events is defined by the bookmaker office and is a subject to changes without prior written notice. In addition, BNP reserves the right to impose special restrictions on the accounts of individual Users.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "12.3 BNP does not recommend two or more Users to place bets from one IP-address (from the same computer or the same local area network) in order to avoid suspicion of collusion (cheating). In such cases it is necessary to reconcile the possibility of the game with BNP by explaining the circumstances. BNP has the right to block the account of such a User and ask them to send the documents verifying their registered identity.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "12.4 Winnings are paid only within the limits set with maximum limits of the company. If the User has made a bet and the winning exceeds the maximum, the company will not pay any amount of money exceeding the maximum limit.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "12.5 Results for sports statistics are published on the official website of BNP within 3 days after the end of a sporting event.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Late bets")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "13.1 Bets placed after the start of the event, except the bets for Live Events, in all cases, are invalid and are returnable, and are excluded from the “express” and “system” bets. Any bet (including bets for Live Events) made on an event, the result of which is already known by the time of betting, is considered invalid and will be refunded.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "13.2 If the User wishes to challenge the time of the start of the event, he must provide an official document (or a link to the website of regulatory bodies of the given event) which confirms the actual time of the start of the match on which the given bet was made.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "13.3 While arising disputes regarding the time of the start of the event, if the official regulatory bodies of the appropriate tournament/event do not provide (or lack) such information, the information of BNP about the start time of the event is considered the only correct one while calculating the bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Return")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "14.1 If a “return” is declared about the bet, such bet is considered as won with the coefficient of 1. In case of “Single” bets this means that the User will get back the amount of money placed to this bet. In the case of “express” or “system” bets the total coefficient will be changed accordingly (in the event, where a return occurred, the coefficient will get the value 1, the coefficients on the remaining events will remain unchanged, and the final coefficient will be counted according to similar scheme; only the coefficient of the outcome on the event, on which was given a return – one of the factors (multipliers) of the final coefficient of “express” or “system” – will get the value 1).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "EXAMPLE: Express")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Position")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Outcome")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Coefficient")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Finland - Moldova")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Win 1")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.55")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Malta-Croatia")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Croatia Handicap (-2)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.7")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Bulgaria-England")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Win 2")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "1.5")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Total coefficient of Express = 1.55 * 1.7 * 1.5 = 3.95")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "In case Finland and England won in the above mentioned games, and Croatia won by 2 goals advantage, and the given express plays, but when calculating the total coefficient there will be 1 instead of 1.7 (coefficient of winning) and the final coefficient of the given express will be equal to 1.55*1*1.5 = 2.325")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "14.2 If as a result of the match the total number of scored goals is equal to the total of the bet and among the proposed outcomes of the given total bets there has not been the option equal ... (the indicated number) of goals, a return is made. Similarly, for the individual totals, totals of the player, totals of cards/corners /removals, fouls and other parameters if the final value of the match and the proposed parameter of the total are equal a return is made.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Privacy of User’s data")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "15.1 The User is responsible for maintaining the confidentiality of any information related to their account, and shall take all measures to prevent the use of personal accounts by unauthorized persons. Any operations confirmed by the username and password of the account holder shall be valid and have legal force.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "15.2 If the User suspects that his username and password are known to a third person, at any time they have the right to send a request to BNP to block the account temporarily for all circumstances to be made clear.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "15.3 To ensure the security of personal data of Users, BNP communicates with Users via the e-mail indicated by the User during registration.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "15.4 The User is responsible for maintaining the confidentiality of any information related to their e- mail, and shall take all measures to prevent the use of e-mail address by third parties. BNP is not responsible for any loss or damage resulting from the connection between the bookmaker office and the User using a registered e-mail address.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Match-fixing")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "16.1 In case of possible interference in the match result and the formation of the coefficients for the match (including cases of suspicion in match-fixing), Vertical Loto reserves the right to suspend the payments on this event or to cancel the bets on this match, as well as hand over the information on relevant side to the appropriate authorities for further investigation and prevention of similar incidents.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "16.2 BNP reserves the right to suspend the payment of the rates and make a return on the rates to the event, if there are solid grounds to believe this match was negotiable. Such grounds may be based on the size, number and nature of the bets made by one or all of the possible methods of betting.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The decision of the governing bodies of relevant federations and regulatory bodies are also taken into account. In such cases BNP reserves the right to hand over the information on related party to the governing bodies for further investigation and preventing similar incidents.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Neutral field")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "17.1 In cases when the match is transferred to a neutral field (NF) rates persist. They are refundable in cases when the match is transferred to the opponent’s field. In case of the play when the teams are from the same city and are transferred to another field, bets are valid and are not refundable. In international matches, the refund of bets is made only when the match transfers to the field of an opponent state.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Interrupted events")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "18.1 An event is considered interrupted if there was no play for an indispensable amount of playing time specified according the rules of the company, even if the result at which the event was interrupted is later confirmed to be final.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "18.2 The matches consider to be taken place, if they have been interrupted, not finished in the time- frame specified in the points 6 and 7 and if the played time is the following:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Soccer - 90 min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Futsal (duration 2 x 20 minutes.) - 35 minutes")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Futsal (duration 2 x 25 minutes.) - 45 minutes")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Basketball NBA (National Basketball Association and PBA, CBA) - 43 min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Eurobasketball - 35min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Hockey NHL (National Hockey League) - 55 min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Bandy - 60 min")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Eurohockey - 50 min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- American football - 55 min.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Baseball - 5 periods (innings)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "- Handball - 50 min")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "18.3 For interrupted events recognized as cancelled, if not otherwise stipulated in the rules on sports, all bets are refundable, except for ones for which the result is exactly defined at the time of the stop of the event. For interrupted events bets on the relative performance time (periods, etc.) are a subject to unconditional return.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Events transfer")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "19.1 If the start time of the event has been changed and otherwise is not stipulated in the rules of sports, all bets on the event are refundable.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "19.2 During a game on the passage to the next round, in cases of transferring the game period onto subsequent days, or changes of the field, the bets remain valid. If the “passage” of the team which goes to the next round later has been canceled because of any reason, the cancellation is disregarded, and the payment is made according the results of played matches. If the second match did not take place or was interrupted, then all bets on it, including the passage, are refundable.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Payments on the passage are made only at bets made before the first match. If none of the matches has taken place, the bets will be refunded.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Calculation of bets")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.1 BNP validates the results on the basis of official reports and alternative sources of information (including videos of the event) after finishing the event. Calculation of bets is based on the results published on the website pbis.verticalloto.com in the section “Results”. In case of discrepancy of results from different sources of information, as well as in the case of their obvious mistakes the final decision to determine the results belongs to BNP .")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.2 All inquiries of Users regarding to the correctness of the results of BNP site should be based only on the basis of official sources of information (websites of regulatory bodies for these championships). Information from other sources cannot be considered a basis for the reviewing/reappraisal of bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.3 Valid (factual) results considered to be the results, which are announced on the basis of official protocols or other sources of information, right after the end of the event.The organizer uses the following official sources:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.uefa.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.fifa.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.beto.gr")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.bundesliga.at")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.turkish-soccer.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.rfpl.org")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.premierleague.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.sportinglife.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.gazzetta.it")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.bundesliga.de")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.laliga.es")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.lfp.fr")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.mlssoccer.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.nfl.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.russiabasket.ru")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.nba.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.euroleague.net")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.nhl.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.fhr.ru")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.rusbandy.ru")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.atptennis.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.wtatour.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.itftennis.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.daviscup.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.fedcup.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.ausopen.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.rolandgarros.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.wimbledon.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.usopen.org")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.mlb.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.pgatour.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.iccworldtwenty20.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.fide.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.volley.ru")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.nyse.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "www.nasdaq.com")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The organizer can use other official sources when there is need. In exceptional cases, the organizer reserves the right to use video viewing to adjudge the true result.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.4 Live event bet results are calculated based on what is known immediately after the end of the event/competition. All following changes (for example, changes by decision of a jury after the game) are not taken into account while deciding the bets. The company itself calculates these bets based on its statistical data about the actual course of the game. If not otherwise indicated, all bets on non- participating athletes in the competition will be void.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.5 In cases when the company’s statistics (based on TV coverage) is different from the official statistics, the bets are calculated according to the company’s statistics.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.6 If more than one participant or team is declared as a winner of the competition, the coefficient of winnings is divided by the number of winners (the coefficient can’t be less than 1)")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.7 All operations on playing accounts are made in the currency chosen by the User during registration.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.8 All bets for which the outcomes are already known (in particular bets on who will score the next goal or win a certain segment of the match), are considered valid and are calculated even if the event or tournament was suspended.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.9 If a match is not completed and is considered as incomplete, then all bets on it are refundable, (except what is mentioned in point 16.1) even if the result, at which the event was suspended, later is confirmed as final.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20.10 If it does not contradict the special rules of individual sports, the result announced on the day of the match is taken for the result of the match. Any possible changes in the result, conditioned by the revision of the results of the event by governing bodies and disciplinary penalties of teams, for the purpose of betting, are not taken into account, and the initial results of the calculation of bets remain in force.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "20․11 In our system, the deposit limit logic works with fixed calendar day hours with (GMT+4) time zone. Meaning that the user will be able to deposit a maximum amount of his limit during 24 hours from 12 am (GMT+4) till 12 am (GMT+4) of the next day.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Betting groups/syndicates and Match/Event limit")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "21.1 Users are required to bet only on their own behalf. Recurring bets containing the same selections from one or more clients can be recognized as invalid and get canceled by the company. Even after the official outcome of such bets is known, in cases when the company is confident that Users have acted in collusion or as a syndicate, or suspicious bets have been made by one or more Users in a short period of time, such bets may be considered invalid and get canceled by the company.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "21.2 Bet limits by sport events are set accordingly to the player’s account status and individual bet/event. If the player makes an attempt to place a bet outside the limits specified for an event, a warning message ” Max. Stake – Limit Reached / Official limit exception” will be displayed in the bet slip as a notification. Multiple bets which combine same selection within the same bet event are not accepted. Avoiding the Warning Message and Non-compliance with this rule will result with cancelation of all placed bets and a refund of the initial stake.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Non-participation in the event")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "22.1 If it does not contradict the special rules of individual sports, when an event participant for whatever reason cannot take part in the event which was bet on, the bet is considered valid and lost by the client. The exceptions are the following cases:")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The event/tournament is canceled;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The event /tournament is considered invalid;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The location of the event was changed;")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The event/tournament is suspended.")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "22.2 In case of bets “Who is taller” meaning bets with two outcomes, if one of the participants refuses to take part before the event/tournament, the bet is refundable.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Rules on sports")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.1 Additional information about types of bets on different sports is indicated in the rules of sports.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.2 Sport rules take precedence over the general rules.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.3 Some types of bets")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.4 In case of betting on the “Odd number/Even number of Total”, regardless of the sports and the proposed position (including total goals/cards/fouls etc.) if the result is “0′′, the bets are calculated as “Even number”")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.5 All bets on the number of medals are calculated according to the official medal table at the end of the event. Any changes undertaken by the governing bodies later are not taken into account.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.6 Any medals won by the country team in any competitions shall be considered as one regardless of the number of participants in this team.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.7 In case if any market has the potential outcome “Any other”, this outcome includes all participants of the event, not listed in the options of that market separately.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "23.8 In case of game on any event in the “additional markets” of tours (total number of goals, wins, losses, draws, angular, yellow cards etc.), only those matches of the tour are taken into account which are included in the daily line.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Registration")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.1 Only registered Users can participate in bonus-programs of the company. To register, fill in the registration form by providing your first name, last name and email. After receiving a verification email, follow the instructions to verify your account to be able to make deposits and place bets.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.2 Registration and betting is allowed exclusively to people over 18 years old (or the allowed age range in the given country from which the user has opened a deposit and made bets). Users have complete responsibility as to dealing with the legality of Internet gambling in the region where they live and/or for providing the appropriate authorities of their country with information on winnings. The Company reserves the right to require proof of age and block the User’s account before receiving the appropriate documentation.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.3 All information provided during the registration must be accurate and complete. In particular, when using credit or debit cards, the cardholder’s name and surname must match the name and surname indicated in the registration form, otherwise the account will be blocked. All bets made before locking the account are recognized as valid.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.4 The Company reserves the right to block the accounts of Users who have reported false data, as well as to deny them the payment of any winnings, *withhold payment of any money held in the BNP Account, and pass on any necessary information to the relevant authorities.* At the request of the Company the User must present an official document with a photograph, identifying his identity (a passport copy), and also proof of authenticity of the indicated address data and telephone.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.5 Each User can have only one account. Registered Users cannot re-register as a new client with a new name or a new email address. In case of violation of this rule, the company has the right to void all bets made by the User.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.6 The User has no right to permit any third party use their game account.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.7 Please note that you should not send us the details about your credit card account or other sensitive financial information via an unencrypted e-mail.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.8 BNP allows all its Users to choose their own combination of username and password. Users should keep such information in secret. If your username and password are entered correctly while accessing the site, all bets remain in force and cannot be canceled or changed by the User. If you suspect that someone other than you knows your password, change it immediately on our website. If you have forgotten the password or a part of it, please send a request to Live Support for a new password.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.9 Users who place their bets in BNP via a cell phone should remember that BNP is not responsible for any loss of data in the mobile phone of the client, and is not responsible for any commission of mobile and internet operators. By registering, the client confirms that he accepts and agrees to these Terms.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "24.10 BNP reserves the right to request additional proofs and perform additional checks in order to verify the identification of the player. Upon request, the player may also be required to send in valid identification documents proving his/her identity and address in order that BNP may carry out identification, perform identification checks through photo and video selfie methods, credit and other verification checks that BNP may require and/or are required by applicable laws and regulations and/or by the relevant regulatory authorities for use of the Services. The player agrees to provide all such information as BNP reasonably requires in connection with such verification checks. Until such time as BNP has received the requested documents and satisfied the verification checks to the operator's reasonable satisfaction, BNP is entitled to restrict the player's Account in any manner that Vertical Loto reasonably deems appropriate, including by suspending the Account, preventing the player from placing any bets or wagers, or from withdrawing his/hers funds.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Currency")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "25.1 Currently Users have the right to place bets in the following currencies: EUR and USD. BNP reserves the right to block the reception of bets and operating activities in any of the indicated currencies. In this case, all the necessary payments on the accounts of blocked currency would be held in another currency equivalent at the interbank exchange rate for that day.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "The bonus program")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "26.1 All bonuses of Users are limited individually to one person, home address, telephone number and e-mail address, one bill of payments (such as by card number or Skrill account), as well as the computer being used (including the institute, Internet club and other public institutions). The company has the right to refuse the bonus to any User or group of User. Bonus programs are available only to Users who have made a deposit in real currency to their account in BNP .")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "26.2 In case of violation of any requirement of the bonus programs, and also if there is any evidence of recurrent bets at one and the same event from a group of customers, or conspiracy, regardless of the result of the given bets, BNP reserves the right to deprive these Users from a bonus and to consider the corresponding bets as invalid. For the purposes of protection against fraud the company has the right to demand a document from the client proving identity before transferring a bonus.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Deposits")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "27.1 Available methods of payments are determined by the country and the currency selected during registration. A complete list of fees, limits on them and other items is displayed on the Deposits and Withdrawals page. Vertical Loto reserves the right to change these terms and details.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "27.2 When conducting any financial transactions it is necessary that the name of the owner of the debit/credit card or bank account exactly match the name of the owner of the appropriate account of BNP . Otherwise BNP reserves the right to cancel all transactions and make a return on all bets made while using someone else’s account or credit/debit card.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Entry of money on account")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "28.1 If any funds have been transferred to the User erroneously, the User is obliged to notify the company immediately. Any winnings of the client arising from such an error shall be considered invalid, and such bets are refundable, regardless of the delay between the origin of the error and the time it was seen.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "28.2 If the deposits to the account were made for any other purpose than bets, poker, casino and financial betting, the company (particularly in case of suspected fraudulent money turnover) reserves the right to cancel a deposit and collect from the User all costs incurred as a result of processing the deposit.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "28.3 If the User’s deposit exceeds the bet’s amount, at the client’s request for withdrawal BNP")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "reserves the right to charge the User all costs incurred as a result of processing deposits and withdrawals.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Financial Limitations")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "29․1 The maximum winning of one ticket is 100 000 USD. If the bet comes with a bonus and thereby the winning sum exceeds 100 000 USD, the bonus is not paid. -The maximum coefficient of a bet is 1000. In case it exceeds 1000, the winning is calculated with 1000 coefficient.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "29.2 The minimum single bet on any event is €0.1 or equivalent amount in players account currency. The minimum bet in express or/and system bet is €0.1 or equivalent amount in players account currency. Unless otherwise stated, only one bet per sport event or match is allowed. Maximum stake per bet must be equal or smaller than the last deposit amount.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "29.3 The maximum coefficient of express bets is 1000. Express bets, in which the coefficient of winnings exceeds the maximum, are calculated with a coefficient of 1000. In these cases, the sum of winnings should not exceed the maximum payment for a single bet. The maximum coefficient of winnings for each version of the system is 1000. Variants of systems on which the coefficient of winnings exceeds the maximum, are calculated with coefficient 1000.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "29.4 The maximum amount of the bet on the event depends on the sport and the events and is defined by the bookmaker network specifically for each event and each type of bet and is subject to change without prior written notice. BNP reserves the right to limit the maximum bet on individual events, as well as the introduction and removal of specific restrictions on the accounts of individual Users without notice or explanation of reasons.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "29.5 All financial limits apply to any individual customer, or/and syndicates group of players acting as a collective unit, who have placed two or more bets containing the same match selections, including where placed in a series of bets, at a different range of odds markets, over a number of days using various players’ accounts and/or across different betting channels. Should we identify that two or more bets have been placed this way, all those bets will be considered as void and only first betting slip submitted will be considered as a legitimate bet.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Payments / Withdrawals")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.1 Payments are processed in a time not exceeding 72 hours starting from the moment that the request was made. Before the first payment will be made to the User by electronic payment methods (Skrill, credit or debit card, etc.), the client is obliged to attach an electronic copy of a passport to the Documents section to confirm their identity. Remember that forgery is severely punished by law, and in cases of suspicion of placing a counterfeit or an edited copy of the documents by electronic methods, BNP reserves the right to send such documents to the appropriate regulatory authorities.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.2 Before making the payment, the employees of the company will verify the correspondence of the name, surname, father’s name, birth dates of the client and also other data. If differences are found between the actual data and the data provided by the client, BNP reserves the right to make a refund for all bets by the User and refuse to pay out winnings to the User unless they prove the identity and accuracy of entered data.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.3 If it turns out that the User has opened several accounts in the company, BNP reserves the right to refuse to pay out for these accounts (except the User’s assets legitimately transferred to the account of Vertical Loto after his payment of a fine in the measure of 10% of the total amount of deposits).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.4 In the first order for a withdrawal in cash the User must enter valid passport details exactly as in the passport in the language of the country that issued the passport (or in the case of foreign passports – in English).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.5 Group and family members should regulate personal relationships with each other – payments are made ONLY in the name of the owner of the appropriate account.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.6 The User agrees to provide BNP with information about his bank account from which the bets will be made in particular, in order to transfer his winnings")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.7 BNP is not responsible for changes in the amount of payments related to fluctuations of currency (rate of exchange).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.8 If the User has requested a withdrawal in the amount of 1,000 Euros or more (or the equivalent in another currency at the interbank rate), BNP pays a commission on the transfer and subsequent operations of withdrawals in the given calendar month. Otherwise, the commission is paid to the bank by the User.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.9 The Company reserves the right of funds’ withdrawal using a priority for itself method of payment for winning players (including credit/debit card or to the player’s bank account).")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "30.10 Before withdrawing the first payment, the player should bet 50% of their deposit amount. Starting from the second withdrawal the player should bet 100% of their deposit amount before being able to withdraw their payment. *If the player refuses to comply with the mentioned requirements, the withdrawal amount is subject to a 6% fee. This requirement is for the purpose of reducing the risks of fraud and money laundering by players.*")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Self-Exclusion")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "31.1 If the User thinks that are spending too much time or money on gambling, whether online or in gambling premises, then the User can ask to be self-excluded. Self-exclusion is a tool used by those who have recognized that their gambling is harmful to them. It is for those who wish to be supported to stop gambling.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "31.2 The User can take active steps to remove yourself from gambling. The User enter into a formal agreement not to gamble, and it is up to the User to stick to your self-exclusion. If the User try to gamble during that time, the BNP must take reasonable steps to stop the User.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "31.3 The User can choose to self-exclude via a multi-operator self-exclusion scheme. These schemes allow you to make a single request to self-exclude from the same type of land-based gambling within your area. GAMSTOP allows you to self-exclude from online operators with one request.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "31.4 If the User are unsure whether or not may have developed a gambling problem, the User can use the following simple checklist for self-assessment. If the User answer positively to at least four of the following questions it is recommended to the User call either our customer service staff.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ol", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you find that you are becoming preoccupied with past gambling successes?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you find that you need to increase the amount of money you gamble to achieve the same enjoyment and excitement?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Have you recently tried to stop gambling but were unsuccessful?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you become moody or impatient when you are cutting down how much you gamble?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you ever use gambling as a way of ignoring stress in your in life or even pick you up when you feel down?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you ever try to win back the money you lost by increasing the size or frequency of your wagers?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Do you ever hide how much or how often you gamble from significant others?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Have you ever committed fraud or theft to get money to gamble with?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Has gambling ever ruined a personal relationship or an occupational or educational opportunity?")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Have you ever needed others to relieve a financial problem created by gambling?")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("31.5 "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("strong", null, "Self-Exclusion. "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("Enables the User to take a break from gambling, restricting the account from placing bets for 01 hour to 03 years. During the time selected, you will be unable to reverse this block, to access the account. Before use this tool the User must withdrawal the funds.")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("31.6 "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("strong", null, "Recess."), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" Enables the User to take a short break from gambling, restricting the account from placing bets for 01 day to 02 years. During the time selected, you will be unable to reverse this block but you can access the account to withdrawal the funds deposited in the account.")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("31.7 "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("strong", null, "Limits"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(". Enables the User to set the maximum values that may be lost by the User. The value can be chosen for daily, weekly, and monthly periods. The User can also restrict the amount of money to bet during a specific time period. The amount can be chosen for a daily, weekly or monthly period. This limit can only be changed again after a week has passed since the request.")])]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "31.8 The User can use the Self-exclusion and Recess tools for 02 (two) times. After the second use, BNP shall close the User account indefinitely.")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  style: {
    "color": "white"
  }
}, "Version 1.2, dated 07.11.2018")]), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
  style: {
    "text-align": "left"
  }
}, " ")])])])])])], -1 /* HOISTED */));

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Modal");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_Modal, {
    ref: "thisModal",
    visible: $props.show,
    showButtons: false,
    close: 'open::modal::termoUso',
    type: 'termo-uso',
    modifyClassModal: 'default-home'
  }, {
    title: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/header/header.svg */ "./src/assets/header/header.svg"),
      alt: "Logo bicho no px",
      class: "img-fluid bnp-header-img pointer pt-4"
    }, null, 8 /* PROPS */, _hoisted_1)]),
    body: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_2]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["visible"]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalTermoUso.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D