__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/vue */ "./node_modules/swiper/vue/swiper-vue.js");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! swiper/css */ "./node_modules/swiper/swiper.min.css");
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css/navigation */ "./node_modules/swiper/modules/navigation/navigation.min.css");
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/pagination */ "./node_modules/swiper/modules/pagination/pagination.min.css");
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swiper */ "./node_modules/swiper/swiper.esm.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");





// import required modules


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ResultadoListagemProdutos',
  components: {
    Swiper: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.Swiper,
    SwiperSlide: swiper_vue__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide
  },
  props: {
    navegation: {
      type: Boolean,
      default: () => true
    },
    filtros: {
      type: [Object, Boolean],
      default: () => false
    },
    noresult: {
      type: Boolean,
      default: () => false
    },
    pagination: {
      type: Boolean,
      default: () => true
    },
    init: {
      type: Boolean,
      default: () => false
    }
  },
  emits: ['openDate'],
  setup(props, {
    emit
  }) {
    // const app = getCurrentInstance()
    // const { Events } = app.appContext.config.globalProperties
    // variables
    const request = (0,vue__WEBPACK_IMPORTED_MODULE_5__.ref)(false);
    const modules = [];
    if (props.pagination) modules.push(swiper__WEBPACK_IMPORTED_MODULE_4__.Pagination);
    if (props.navegation) modules.push(swiper__WEBPACK_IMPORTED_MODULE_4__.Navigation);
    if (props.navegation) modules.push(swiper__WEBPACK_IMPORTED_MODULE_4__.Autoplay);
    return {
      request,
      modules
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/banner.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D