__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @vuelidate/core */ "./node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _vuelidate_validators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @vuelidate/validators */ "./node_modules/@vuelidate/validators/dist/index.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var _core_mixins__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/core/mixins */ "./src/core/mixins/index.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");








/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalSolicitarRecuperacaoSenha',
  mixins: [_core_mixins__WEBPACK_IMPORTED_MODULE_4__.filterMixins],
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    ResetarSenhaOtp: (0,vue__WEBPACK_IMPORTED_MODULE_1__.defineAsyncComponent)(() => __webpack_require__.e(/*! import() */ "src_views_auth_components_resetarSenhaOtp_vue").then(__webpack_require__.bind(__webpack_require__, /*! ./resetarSenhaOtp.vue */ "./src/views/auth/components/resetarSenhaOtp.vue")))
  },
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(props, {
    emit
  }) {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      $loading,
      Events
    } = app.appContext.config.globalProperties;
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_6__.useStore)();
    const phone = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('');
    const email = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('');
    const selectedMethod = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('email');
    const count = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(0);
    const show = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const v$ = (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_0__["default"])();
    const tab = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('email');
    const entityId = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(0);
    const cod = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => '55' + phone.value.replace(/\D/g, ''));
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.watch)(() => props.showModal, () => {
      clear();
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.onMounted)(() => {
      Events.on('modal::close', e => {
        show.value = e;
        // clear()
        v$.value.phone.$reset();
        v$.value.email.$reset();
        email.value = '';
        phone.value = '';
      });
      Events.on('login::form::value', v => {
        clear();
        phone.value = v.name;
      });
    });
    const verificarConta = async () => {
      _core_service_session__WEBPACK_IMPORTED_MODULE_5__["default"].remove('auth-token');
      // const valid = await v$.value.$validate()
      // if (!valid) return

      if (tab.value === 'whatsapp') {
        if (!v$.value.phone.$validate()) return;
      } else {
        if (!v$.value.email.$validate()) return;
      }
      const loader = $loading.show();
      // const result = await store.dispatch('perfil/hasActiveOTP', { entityCod: cod.value })
      //   .catch(err => {
      //     _alert(err)
      //   })
      loader.hide();
      // const otpActive = result.data?.data?.otpActive
      // if (!otpActive) {
      if (selectedMethod.value === 'whatsapp') {
        recuperarSenhaWpp();
      } else if (selectedMethod.value === 'email') {
        recuperarSenhaEmail();
      }
      // return
      // }
      // entityId.value = result.data?.data?.entityId
      // tab.value = 'metodos'
    };

    const recuperarSenhaEmail = async () => {
      if (count.value > 2) {
        count.value = 0;
      }
      count.value++;
      const loader = $loading.show();
      store.dispatch('login/recuperarSenha', {
        email: email.value,
        count
      }).then(() => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Email enviado!', 'success', 4000);
        close();
      }).catch(err => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(err.message, 'error');
      });
    };
    const recuperarSenhaWpp = async () => {
      if (count.value > 2) {
        count.value = 0;
      }
      count.value++;
      const loader = $loading.show();
      store.dispatch('login/recuperarSenha', {
        cod: cod.value,
        count
      }).then(() => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Mensagem enviada !', 'success', 4000);
        close();
      }).catch(err => {
        loader.hide();
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(err.message, 'error');
      });
    };
    const close = () => {
      // clear()
      emit('closeModal');
      Events.emit('modal::close');
    };
    const clear = () => {
      tab.value = 'email';
    };
    return {
      verificarConta,
      tab,
      show,
      cod,
      entityId,
      v$: (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_0__["default"])(),
      recuperarSenhaWpp,
      recuperarSenhaEmail,
      close,
      email,
      phone,
      selectedMethod
    };
  },
  validations() {
    return {
      phone: {
        minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_7__.minLength)(16),
        $autoDirty: true
      },
      email: {
        email: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_7__.email,
        $autoDirty: true
      }
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalRecuperarSenha.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D