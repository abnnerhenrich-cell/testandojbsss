__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-b571d086"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = ["src"];
const _hoisted_2 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h6", {
  class: "text mx-1"
}, " Recuperar senha ", -1 /* HOISTED */));
const _hoisted_3 = {
  class: "form-valid py-2"
};
const _hoisted_4 = {
  class: "d-flex justify-content-center align-items-center flex-nowrap form mb-3"
};
const _hoisted_5 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f12 wpp-label ps-2"
}, " Email ", -1 /* HOISTED */));
const _hoisted_6 = {
  key: 0,
  class: "px-2"
};
const _hoisted_7 = {
  class: "d-flex"
};
const _hoisted_8 = {
  class: "w-20 ps-2"
};
const _hoisted_9 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("i", {
  class: "bi bi-arrow-right m-2 mb-1"
}, null, -1 /* HOISTED */));
const _hoisted_10 = [_hoisted_9];
const _hoisted_11 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, " Metodos de recuperação ", -1 /* HOISTED */));

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ResetarSenhaOtp = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ResetarSenhaOtp");
  const _component_Modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Modal");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_Modal, {
    ref: "thisModal",
    visible: $props.showModal,
    showButtons: false,
    modifyClassModal: 'default-home'
  }, {
    title: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/logo.png */ "./src/assets/logo.png"),
      alt: "VerticalLoto loterias",
      class: "img-fluid mb-3 img-logo"
    }, null, 8 /* PROPS */, _hoisted_1)]),
    body: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [$setup.tab === 'email' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      key: 0
    }, [_hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div\r\n              :class=\"['card-rec d-flex w-100 justify-content-center align-items-center mx-1', selectedMethod === 'whatsapp'? 'active' : '']\" @click=\"selectedMethod = 'whatsapp'\">\r\n            WhatsApp\r\n            </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-rec d-flex w-100 justify-content-center align-items-center mx-1', $setup.selectedMethod === 'email' ? 'active' : '']),
      onClick: _cache[0] || (_cache[0] = $event => $setup.selectedMethod = 'email')
    }, " Email ", 2 /* CLASS */)])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-if=\"selectedMethod === 'whatsapp'\" :class=\"['form-valid py-3 mx-1', v$.phone.$invalid && v$.phone.$dirty ? 'error-rec-pass' : '']\">\r\n          <span class=\"f12 wpp-label ps-2\"> WhatsApp </span>\r\n          <span v-if=\"v$.phone.$invalid && v$.phone.$dirty\" class=\"px-2\"> Campo inválido</span>\r\n          <div class=\"d-flex\">\r\n            <input type=\"tel\" class=\"input flex-grow-1\" v-maska.trim=\"'(##) # ####-####'\" v-model=\"phone\" placeholder=\"Ex: (00) 9 0000-0000\">\r\n            <div class=\" w-20 ps-2\">\r\n              <button @click=\"verificarConta\" class=\"btn-enviar\" id=\"b-recuperar\"> <i class=\"bi bi-arrow-right m-2 mb-1\"></i></button>\r\n            </div>\r\n          </div>\r\n        </div> "), $setup.selectedMethod === 'email' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: 0,
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['form-valid py-3 mx-1', $setup.v$.email.$invalid && $setup.v$.email.$dirty ? 'error-rec-pass' : ''])
    }, [_hoisted_5, $setup.v$.email.$invalid && $setup.v$.email.$dirty ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_6, " Campo inválido")) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_7, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
      type: "text",
      class: "input flex-grow-1",
      "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => $setup.email = $event),
      placeholder: "Ex: example@email.com"
    }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.email]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_8, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      onClick: _cache[2] || (_cache[2] = (...args) => $setup.verificarConta && $setup.verificarConta(...args)),
      class: "btn-enviar",
      id: "b-recuperar"
    }, _hoisted_10)])])], 2 /* CLASS */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 64 /* STABLE_FRAGMENT */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.tab === 'metodos' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      key: 1
    }, [_hoisted_11, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      onClick: _cache[3] || (_cache[3] = (...args) => $setup.recuperarSenhaWpp && $setup.recuperarSenhaWpp(...args)),
      class: "green w-100 mt-2"
    }, " WhatsApp "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
      onClick: _cache[4] || (_cache[4] = $event => $setup.tab = 'otp'),
      class: "green w-100 mt-2"
    }, " Código de autenticação ")], 64 /* STABLE_FRAGMENT */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.tab === 'otp' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_ResetarSenhaOtp, {
      key: 2,
      entityCod: $setup.cod,
      entityId: $setup.entityId,
      onModalclose: $setup.close
    }, null, 8 /* PROPS */, ["entityCod", "entityId", "onModalclose"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["visible"]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalRecuperarSenha.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D