__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _hoisted_1 = {
  class: "d-flex flex-column flex-nowrap w-100 justify-content-center text-center"
};
const _hoisted_2 = {
  class: "box"
};
const _hoisted_3 = ["src"];
const _hoisted_4 = {
  class: "box",
  href: "https://acesse.one/telegranbnp",
  target: "_blank"
};
const _hoisted_5 = ["src"];
const _hoisted_6 = {
  class: "box",
  href: "https://l1nk.dev/whatsappbnp",
  target: "_blank"
};
const _hoisted_7 = ["src"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_swiper_slide = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("swiper-slide");
  const _component_swiper = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("swiper");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_swiper, {
    spaceBetween: 0,
    autoplay: {
      delay: 4850,
      disableOnInteraction: false
    },
    slidesPerGroup: 1,
    slidesPerView: 'auto',
    navigation: false,
    pagination: {
      clickable: true
    },
    modules: $setup.modules,
    class: "w-100"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <template v-for=\"v in (0, 4)\" :key=\"v\"> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_swiper_slide, null, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("a", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__(/*! @/assets/banner-home/bg_home.png */ "./src/assets/banner-home/bg_home.png"),
        class: "img-fluid box-img"
      }, null, 8 /* PROPS */, _hoisted_3)])]),
      _: 1 /* STABLE */
    }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_swiper_slide, null, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("a", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__(/*! @/assets/banner-home/bg-telegram.jpg */ "./src/assets/banner-home/bg-telegram.jpg"),
        class: "img-fluid box-img"
      }, null, 8 /* PROPS */, _hoisted_5)])]),
      _: 1 /* STABLE */
    }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_swiper_slide, null, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("a", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__(/*! @/assets/banner-home/bg-whatsapp.jpg */ "./src/assets/banner-home/bg-whatsapp.jpg"),
        class: "img-fluid box-img"
      }, null, 8 /* PROPS */, _hoisted_7)])]),
      _: 1 /* STABLE */
    }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" </template> ")]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modules"])]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/banner.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D