__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-530a70e0"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = {
  key: 0,
  class: "d-flex flex-column flex-nowrap w-100 justify-content-center text-center position-relative overflow-hidden"
};
const _hoisted_2 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "titulo f22 bold mt-4 mb-2"
}, " Últimos ganhadores ", -1 /* HOISTED */));
const _hoisted_3 = {
  class: "d-flex flex-column position-relative mb-2"
};
const _hoisted_4 = {
  class: "d-flex px3 box flex-column"
};
const _hoisted_5 = ["src"];
const _hoisted_6 = {
  class: "d-flex px3 box-info flex-column"
};
const _hoisted_7 = {
  class: "box-content d-flex flex-wrap px-5 pb-2"
};
const _hoisted_8 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "box-title w-50 pb-1 mt-4"
}, " Modalidade ", -1 /* HOISTED */));
const _hoisted_9 = {
  class: "box-text w-50 mt-4"
};
const _hoisted_10 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "box-title w-50 pb-1"
}, " Loteria ", -1 /* HOISTED */));
const _hoisted_11 = {
  class: "box-text w-50"
};
const _hoisted_12 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "box-title w-50 pb-1"
}, " Usuário ", -1 /* HOISTED */));
const _hoisted_13 = {
  class: "box-text w-50"
};
const _hoisted_14 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "box-title w-50 pb-2"
}, " Prêmio pago ", -1 /* HOISTED */));
const _hoisted_15 = {
  class: "box-text w-50 pb-2"
};
const _hoisted_16 = {
  key: 1,
  class: "d-flex justify-content-center"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_swiper_slide = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("swiper-slide");
  const _component_swiper = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("swiper");
  const _component_viewLoader = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("viewLoader");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [!$setup.loader && $setup.lastWinners[0] ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [_hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("\r\n     "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_swiper, {
    spaceBetween: 0,
    autoplay: {
      delay: 4850,
      disableOnInteraction: false
    },
    slidesPerGroup: 1,
    slidesPerView: 'auto',
    navigation: false,
    pagination: {
      clickable: true
    },
    modules: $setup.modules,
    class: "w-100"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.lastWinners, (winner, i) => {
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_swiper_slide, {
        key: i
      }, {
        default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
          class: "box-header d-flex justify-content-center align-items-start pt-2",
          style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)(`background-color: ${$setup.getColorCategory(winner)};`)
        }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
          src: __webpack_require__("./src/assets/produtos/svg sync recursive ^\\.\\/.*\\-white\\.svg$")(`./${$setup.getImgCategory(winner)}-white.svg`)
        }, null, 8 /* PROPS */, _hoisted_5)], 4 /* STYLE */)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_7, [_hoisted_8, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(winner.modality), 1 /* TEXT */), _hoisted_10, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_11, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(winner.sweepstake), 1 /* TEXT */), _hoisted_12, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_13, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(winner.user), 1 /* TEXT */), _hoisted_14, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_15, " R$ " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(winner.prizeValue), 1 /* TEXT */)])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <img v-else :src=\"require('@/assets/produtos/bonus.png')\" class=\"img-fluid box-img\"> ")]),
        _: 2 /* DYNAMIC */
      }, 1024 /* DYNAMIC_SLOTS */);
    }), 128 /* KEYED_FRAGMENT */))]),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modules"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.loader ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_16, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_viewLoader)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"marca d-flex justify-content-center flex-wrap\" v-if=\"listProd[0]\" :class=\"{ hasBonus: configBonusWeb && configBonusWeb.ativo }\">\r\n    <template v-for=\"(v, k) in listProd\" :key=\"k\">\r\n      <div\r\n        :class=\"{ [v.id === '15ZAO' ? 'QUINZAO' : v.id]: true, active: prodActive === v.id || ('15ZAO' === v.id && prodActive === 'QUINZAO') }\"\r\n        @click=\"activeProdMarca(k)\">\r\n        <a class=\"box\" v-if=\"v.config\">\r\n          <img v-if=\"v.config.ID_PROD\" :src=\"require(`@/assets/produtos/${v.config.ID_PROD}.png`)\"\r\n            class=\"img-fluid box-img\">\r\n          <img v-else :src=\"require('@/assets/produtos/bonus.png')\" class=\"img-fluid box-img\">\r\n        </a>\r\n        <span> </span>\r\n      </div>\r\n    </template>\r\n  </div> ")], 64 /* STABLE_FRAGMENT */);
}

//# sourceURL=webpack://plataforma/./src/views/auth/components/bannerGanhadores.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D