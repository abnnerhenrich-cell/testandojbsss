__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalCookie',
  props: {
    exibirPopup: {
      type: Boolean,
      default: false
    }
  },
  setup(_, {
    emit
  }) {
    /* METHODS */
    const aceitarCookies = async () => {
      _core_service_session__WEBPACK_IMPORTED_MODULE_0__["default"].set('aceito-cookies', true);
      emit('closePopup');
    };
    return {
      aceitarCookies,
      emit
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/popupCookie.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D