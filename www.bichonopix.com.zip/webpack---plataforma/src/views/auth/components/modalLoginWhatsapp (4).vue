__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/noSourceMaps.js */ "./node_modules/css-loader/dist/runtime/noSourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* Modal BackGround */\n/* Home */\n/* home buttons */\n/* cadastrar */\n/* recuperar senha / Cadastrar / Login */\n/* recuperar senha / Cadastrar */\n/* Cartelas BT */\n/* FFE7A4 */\n/* 975821 */\n/* 572515 */\n/* SUP25 */\n/* SUP5 */\n/* HOME */\n/* novas */\n/* login */\n/* listagem produtos  icon white svg */\n/* auth home */\n/* RESULTADO */\n/* CARRINHO */\n/* MODO DARK HOME */\n/* Modal BackGround */\n/* Home */\n/* home buttons */\n/* cadastrar */\n/* recuperar senha / Cadastrar / Login */\n/* recuperar senha / Cadastrar */\n/* Cartelas BT */\n/* FFE7A4 */\n/* 975821 */\n/* 572515 */\n/* SUP25 */\n/* SUP5 */\n/* HOME */\n/* novas */\n/* login */\n/* listagem produtos  icon white svg */\n/* auth home */\n/* RESULTADO */\n/* CARRINHO */\n/* MODO DARK HOME */\n.text[data-v-478be10c] {\n  color: #000;\n  font-size: 14px;\n  font-weight: bold;\n}\n.input[data-v-478be10c] {\n  color: #000;\n  font-size: 14px;\n  font-weight: bold;\n  box-shadow: 0 3px 10px 0 rgba(121, 134, 203, 0.12);\n  border-radius: 6px;\n  height: 43px;\n  border: none;\n}", ""]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


//# sourceURL=webpack://plataforma/./src/views/auth/components/modalLoginWhatsapp.vue?./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use%5B1%5D!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use%5B2%5D!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D