__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vuelidate_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @vuelidate/core */ "./node_modules/@vuelidate/core/dist/index.esm.js");
/* harmony import */ var _vuelidate_validators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @vuelidate/validators */ "./node_modules/@vuelidate/validators/dist/index.esm.js");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/modal.vue */ "./src/components/modal.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var _core_mixins__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/core/mixins */ "./src/core/mixins/index.js");
/* harmony import */ var vue_recaptcha__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-recaptcha */ "./node_modules/vue-recaptcha/dist/vue-recaptcha.es.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_7__);










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modalConferirBilhete',
  mixins: [_core_mixins__WEBPACK_IMPORTED_MODULE_4__.filterMixins],
  components: {
    Modal: _components_modal_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    FormOtpCode: (0,vue__WEBPACK_IMPORTED_MODULE_1__.defineAsyncComponent)(() => __webpack_require__.e(/*! import() */ "src_views_auth_components_formOtpCode_vue").then(__webpack_require__.bind(__webpack_require__, /*! ./formOtpCode.vue */ "./src/views/auth/components/formOtpCode.vue"))),
    VueRecaptcha: vue_recaptcha__WEBPACK_IMPORTED_MODULE_5__.VueRecaptcha
  },
  setup(_, {
    emit
  }) {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const v$ = (0,_vuelidate_core__WEBPACK_IMPORTED_MODULE_0__["default"])();
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_8__.useStore)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const form = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)({
      name: null,
      password: null,
      recaptcha: ''
    });
    const recaptcha = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(null);
    const showForm = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(true);
    const qtdTentativaLogin = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(0);
    const produtoSelecionado = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)('');
    const show = (0,vue__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const exibirRecaptcha = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => qtdTentativaLogin.value >= 3);
    const keyRecaptchaSite = (0,vue__WEBPACK_IMPORTED_MODULE_1__.computed)(() => (_core_config__WEBPACK_IMPORTED_MODULE_7___default().KEY_RECAPTCHA_SITE));
    const openModalRecuperarSenha = () => {
      show.value = false;
      Events.emit('open::modal::recuperarSenha', true);
    };
    const eventOpenModal = v => {
      Events.emit(v, true);
    };
    const recaptchaReset = () => {
      recaptcha.value.reset();
    };
    const checkMethod = value => {
      // when you need a reCAPTCHA challenge
      console.log('checkMethod');
      console.log(value);
      form.value.recaptcha = value;
    };
    const expiredMethod = () => {
      form.value.recaptcha = '';
    };
    const clearForm = () => {
      produtoSelecionado.value = '';
      form.value.name = '';
      form.value.password = '';
      v$.value.form.name.$reset();
      v$.value.form.password.$reset();
    };
    const renderMethod = value => {
      form.value.recaptcha = '';
    };
    const errorMethod = value => {
      form.value.recaptcha = '';
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_1__.watch)(form.value, v => {
      Events.emit('login::form::value', v);
    });
    return {
      form,
      show,
      v$,
      openModalRecuperarSenha,
      recaptchaReset,
      checkMethod,
      expiredMethod,
      renderMethod,
      errorMethod,
      exibirRecaptcha,
      qtdTentativaLogin,
      keyRecaptchaSite,
      showForm,
      recaptcha,
      eventOpenModal,
      produtoSelecionado,
      clearForm,
      store
    };
  },
  mounted() {
    const vm = this;
    // vm.Events.on('modal::login', e => {
    //   vm.show = e
    //   this.verificarPopupCookie()
    // })
    // vm.Events.on('modal::close', e => { vm.show = e; vm.showForm = true })
    vm.Events.on('open::modal::login::produto::selecionado', e => {
      vm.show = true;
      vm.showForm = true;
      vm.produtoSelecionado = e;
    });
    vm.Events.on('modal::login::close::produto::selecionado', () => {
      vm.show = false;
      vm.clearForm();
      vm.Events.emit('modal::close', false);
    });
  },
  methods: {
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_8__.mapActions)('login', ['userLogin', 'getDadosUsuario']),
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_8__.mapActions)('saldos', ['setSaldos', 'getSaldos']),
    async loginUsuario(token = null) {
      const vm = this;
      const aceitoCookies = _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].get('aceito-cookies', true);
      if (!aceitoCookies) {
        this.verificarPopupCookie();
        return false;
      }
      const load = this.$loading.show();
      try {
        if (!(await this.v$.$validate())) {
          try {
            load.hide();
          } catch {}
          return;
        }
        const dados = Object.assign({}, this.form);
        dados.name = String(dados.name).replace(/\D/g, '');
        if (token) dados.otptoken = token;
        if (this.qtdTentativaLogin < 3) {
          dados.recaptcha = undefined;
        }
        if (this.qtdTentativaLogin >= 3 && !dados.recaptcha) {
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Marcar o Recaptcha', 'error');
          try {
            load.hide();
          } catch {}
          return;
        }

        // realiza login do usuario
        this.userLogin(dados).then(() => {
          this.getDadosUsuario().then(res => {
            setTimeout(() => {
              const params = _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].get('gps');
              this.store.dispatch('login/addPositions', params);
            }, 10000);
            this.show = false;
            if (res.data.user.jsonFlags.resetPassword) {
              this.$router.push({
                name: 'perfil'
              });
              return;
            }
            vm.Events.emit('open::modal::login', false);
            // _alert('Login Realizado', 'success')
            this.$router.push({
              name: 'home'
            });
            if (this.produtoSelecionado) {
              this.$router.push({
                name: 'produtos'
              });
            }
          }).finally(() => {
            try {
              load.hide();
            } catch {}
          });
        }).catch(err => {
          try {
            load.hide();
          } catch {}
          if (err.message === 'Token é invalido ou usuário não existe') {
            if (token) (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Token invalido', 'error');
            this.qtdTentativaLogin = 0;
            this.showForm = false;
            return;
          }
          this.showForm = true;
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(err.message, 'error');
          this.recaptchaHandler();
        });
      } catch (e) {
        (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(e.message, 'error');
        try {
          load.hide();
        } catch {}
      }
    },
    recaptchaHandler() {
      this.qtdTentativaLogin++;
      if (this.qtdTentativaLogin > 3) {
        this.recaptchaReset();
      }
    },
    verificarPopupCookie() {
      const aceitoCookies = _core_service_session__WEBPACK_IMPORTED_MODULE_6__["default"].get('aceito-cookies', true);
      if (!aceitoCookies) {
        this.$emit('openPopupCookies');
      }
    }
  },
  validations() {
    return {
      form: {
        name: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_9__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_9__.minLength)(14),
          $autoDirty: true
        },
        password: {
          required: _vuelidate_validators__WEBPACK_IMPORTED_MODULE_9__.required,
          minLength: (0,_vuelidate_validators__WEBPACK_IMPORTED_MODULE_9__.minLength)(3),
          $autoDirty: true
        }
      }
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/auth/components/modalLogin.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D