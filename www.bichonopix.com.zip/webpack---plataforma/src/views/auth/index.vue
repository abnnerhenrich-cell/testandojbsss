__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");

const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-9040f476"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = {
  class: "home d-flex flex-column align-items-center px-1"
};
const _hoisted_2 = {
  class: "d-flex flex-wrap align-items-end produtos"
};
const _hoisted_3 = ["onClick"];
const _hoisted_4 = ["src"];
const _hoisted_5 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "d-flex flex-row mt-5"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "w-50 box"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <router-link :to=\"{ name : 'resultados'}\"  class=\"resultado px-3 py-2\">\r\n          <h6>RESULTADOS </h6>\r\n          <p> Confira os resultados da sua aposta </p>\r\n        </router-link> "), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <a @click.prevent=\"eventOpenModal('modal::cadastro::resultado')\"  class=\"resultado px-3 py-2\">\r\n          <h6>RESULTADOS </h6>\r\n          <p> Confira os resultados da sua aposta </p>\r\n        </a> ")])], -1 /* HOISTED */));

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Banner = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Banner");
  const _component_BannerGanhadores = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("BannerGanhadores");
  const _component_ModalWhatsapp = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("ModalWhatsapp");
  const _component_modalBilhete = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalBilhete");
  const _component_modalLogin = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalLogin");
  const _component_modalCadastro = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalCadastro");
  const _component_modalRecuperarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalRecuperarSenha");
  const _component_modalResetarSenha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalResetarSenha");
  const _component_modalSolicitarLocalizacao = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalSolicitarLocalizacao");
  const _component_modalTermoUso = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("modalTermoUso");
  const _component_MenuFooter = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("MenuFooter");
  const _component_popupCookie = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("popupCookie");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"d-flex flex-nowrap justify-content-center primary bold line mt-3 logo\">\r\n     <img src=\"@/assets/logo.svg\" class=\"img-fluid\" />\r\n    </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_Banner, {
    class: "mb-5"
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.produtos, (produto, i) => {
    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: produto,
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(["col-6 mb-4 produtos-img", [i % 2 === 0 ? 'pe-2' : 'ps-2']]),
      onClick: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)($event => $setup.selectProduct(produto.id), ["stop"])
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__("./src/assets/banner/produtos sync recursive ^\\.\\/.*\\.png$")(`./${produto.config.ID_PROD}.png`),
      class: "img-fluid"
    }, null, 8 /* PROPS */, _hoisted_4)], 10 /* CLASS, PROPS */, _hoisted_3);
  }), 128 /* KEYED_FRAGMENT */))]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_BannerGanhadores), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"titulo f22 bold mt-4 mb-2 mt-2\"> Como funciona o BICHO NO PIX </div>\r\n    <div class=\"produtos-img mb-3\"> <img :src=\"require('@/assets/bg_info_pix.png')\" class=\"img-fluid\"> </div>\r\n    <div class=\"produtos-img mb-3\"> <img :src=\"require('@/assets/bg_info_phone.png')\" class=\"img-fluid\"> </div>\r\n    <div class=\"produtos-img\"> <img :src=\"require('@/assets/bg_info_trofeu.png')\" class=\"img-fluid\"> </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Botoes "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"d-flex d-inline-flex mt-3 w-100\" v-if=\"!auth\">\r\n      <button class=\"v2 v2-default f16 w-50 mb-2 me-1\" @click=\"eventOpenModal('modal::cadastro')\"> Criar Conta </button>\r\n      <button @click=\"eventOpenModal('modal::login')\" class=\" ms-1 v2 v2-default w-50 f16 mb-2\"> Entrar </button>\r\n    </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Init resultado "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <ResultadoAnimado /> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"d-flex flex-nowrap justify-content-center primary bold line mt-3\">\r\n     <img src=\"@/assets/selo.png\" class=\"img-fluid selo\" />\r\n  </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <button @click=\"router.push({ name: 'revenda' })\" class=\"v2 v2-default f16 mt-4\"> Seja um revendedor </button> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <BtnAjuda /> "), _hoisted_5, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" modal whatsapp "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_ModalWhatsapp), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" modal bilhete "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalBilhete), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" modal LOGIN  "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalLogin, {
    onOpemModalRecuperarSenha: $setup.opemModalRecuperarSenha,
    onOpenPopupCookies: $setup.openPopupCookies
  }, null, 8 /* PROPS */, ["onOpemModalRecuperarSenha", "onOpenPopupCookies"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" modal Cadastro  "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalCadastro), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalRecuperarSenha, {
    showModal: $setup.showModalRecuperarSenha,
    onCloseModal: $setup.closeModalRecuperarSenha,
    formLogin: $setup.dadosFormLogin
  }, null, 8 /* PROPS */, ["showModal", "onCloseModal", "formLogin"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalResetarSenha, {
    showModal: $setup.showModalResetarSenha,
    token: $setup.token,
    onCloseModal: $setup.closeModalResetarSenha
  }, null, 8 /* PROPS */, ["showModal", "token", "onCloseModal"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalSolicitarLocalizacao, {
    showModal: $setup.showModalSolicitarLocalizacao,
    onCloseModel: $setup.closeModelSolicitarLocalizacao
  }, null, 8 /* PROPS */, ["showModal", "onCloseModel"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_modalTermoUso, {
    show: $setup.modalTermo
  }, null, 8 /* PROPS */, ["show"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_MenuFooter), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_popupCookie, {
    exibirPopup: $setup.exibirPopupCookie,
    onClosePopup: $setup.closePopup
  }, null, 8 /* PROPS */, ["exibirPopup", "onClosePopup"])]);
}

//# sourceURL=webpack://plataforma/./src/views/auth/index.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D