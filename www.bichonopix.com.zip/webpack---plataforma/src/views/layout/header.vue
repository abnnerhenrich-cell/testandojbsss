__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _assets_icons_sair_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/icons/sair.svg */ "./src/assets/icons/sair.svg");


const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-8b941730"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['container-fluid menu', 'bnp-header d-flex align-items-center flex-nowrap'])
};
const _hoisted_2 = {
  class: "w-100"
};
const _hoisted_3 = {
  class: "d-flex justify-content-star align-items-center w-100 h-100"
};
const _hoisted_4 = {
  class: "header-version bold f10 d-none"
};
const _hoisted_5 = ["src"];
const _hoisted_6 = {
  class: "d-flex h-100"
};
const _hoisted_7 = ["src"];
const _hoisted_8 = {
  class: "d-flex justify-content-center align-items-end w-100 bnp-header-text f12 w-100"
};
const _hoisted_9 = {
  class: "entrar"
};
const _hoisted_10 = ["src"];
const _hoisted_11 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" Entrar ");
const _hoisted_12 = {
  class: "center bnp-header-text bnp-header-button ms-3"
};
const _hoisted_13 = {
  class: "d-flex justify-content-center align-items-end bnp-header-text f12 ajuste-mobile-saldo w-100"
};
const _hoisted_14 = {
  class: "saldo white fw-bold"
};
const _hoisted_15 = {
  class: "d-flex flex-column jutify-content-start align-items-end"
};
const _hoisted_16 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "label-currency text-end"
}, " créditos ", -1 /* HOISTED */));
const _hoisted_17 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "spacer"
}, null, -1 /* HOISTED */));
const _hoisted_18 = {
  class: "d-flex flex-column jutify-content-start align-items-end"
};
const _hoisted_19 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("label", {
  class: "label-currency text-end"
}, " bonus ", -1 /* HOISTED */));
const _hoisted_20 = ["src"];
const _hoisted_21 = {
  class: "header-icons ms-1"
};
const _hoisted_22 = {
  class: "circle"
};
const _hoisted_23 = ["src"];
const _hoisted_24 = ["src"];
const _hoisted_25 = {
  key: 0,
  class: "dropdown-menu"
};
const _hoisted_26 = {
  class: "justify-content-center"
};
const _hoisted_27 = ["src"];
const _hoisted_28 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "px-2"
}, "Meu Perfil", -1 /* HOISTED */));
const _hoisted_29 = {
  class: "justify-content-center"
};
const _hoisted_30 = ["src"];
const _hoisted_31 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "px-2"
}, "Bônus", -1 /* HOISTED */));
const _hoisted_32 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "justify-content-center"
}, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_sair_svg__WEBPACK_IMPORTED_MODULE_1__,
  class: "img-fluid img-menu px-2",
  alt: "sair"
}), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "px-2"
}, "Sair")], -1 /* HOISTED */));
const _hoisted_33 = [_hoisted_32];
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" eslint-disable "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("button", {
    class: "btn bnp-header-menu",
    role: "button",
    onClick: _cache[0] || (_cache[0] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)((...args) => $setup.openMenu && $setup.openMenu(...args), ["stop"]))
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/menu.svg */ "./src/assets/icons/menu.svg"),
    alt: "menu Bicho no pix",
    class: "img-fluid"
  }, null, 8 /* PROPS */, _hoisted_5)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/logo.png */ "./src/assets/logo.png"),
    alt: "Logo bicho no px",
    class: "img-fluid bnp-header-img pointer",
    onClick: _cache[1] || (_cache[1] = (...args) => $setup.redirect && $setup.redirect(...args))
  }, null, 8 /* PROPS */, _hoisted_7)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Header user não logado "), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    key: 0
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_8, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    onClick: _cache[2] || (_cache[2] = $event => $setup.openModal('open::modal::login'))
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/header/perfil.svg */ "./src/assets/header/perfil.svg"),
    alt: "Bincho no pix Entrar",
    class: "pe-1 bold f12"
  }, null, 8 /* PROPS */, _hoisted_10), _hoisted_11])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_12, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    onClick: _cache[3] || (_cache[3] = $event => $setup.openModal('open::modal::cadastro')),
    class: "btn default f12"
  }, " Cadastre-se ")])], 64 /* STABLE_FRAGMENT */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Header user logado "), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    key: 1
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_13, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_14, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_15, [_hoisted_16, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(_ctx._currency($setup.listSaldos.saldo)), 1 /* TEXT */)]), _hoisted_17, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_18, [_hoisted_19, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(_ctx._currency($setup.listSaldos.bonus)), 1 /* TEXT */)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/add.svg */ "./src/assets/icons/add.svg"),
    onClick: _cache[4] || (_cache[4] = (...args) => $setup.addCredit && $setup.addCredit(...args)),
    alt: "add creditos",
    class: "img-add"
  }, null, 8 /* PROPS */, _hoisted_20)])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_21, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_22, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/person.svg */ "./src/assets/icons/person.svg"),
    class: "header-icon-person"
  }, null, 8 /* PROPS */, _hoisted_23)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "header-perfil",
    onClick: _cache[8] || (_cache[8] = (...args) => $setup.toggleMenuPerfil && $setup.toggleMenuPerfil(...args)),
    ref: "menu"
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/arrow_down.svg */ "./src/assets/icons/arrow_down.svg"),
    class: "header-icon-arrow"
  }, null, 8 /* PROPS */, _hoisted_24), $setup.isMenuOpenPerfil ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("ul", _hoisted_25, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", {
    onClick: _cache[5] || (_cache[5] = $event => $setup.openRouter('perfil'))
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_26, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/meu_perfil.svg */ "./src/assets/icons/meu_perfil.svg"),
    alt: "perfil",
    class: "img-fluid img-menu px-2"
  }, null, 8 /* PROPS */, _hoisted_27), _hoisted_28])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", {
    onClick: _cache[6] || (_cache[6] = $event => $setup.openRouter('bonus'))
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_29, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: __webpack_require__(/*! @/assets/icons/gift.svg */ "./src/assets/icons/gift.svg"),
    alt: "bonus",
    class: "img-fluid img-menu px-2"
  }, null, 8 /* PROPS */, _hoisted_30), _hoisted_31])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", {
    onClick: _cache[7] || (_cache[7] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)((...args) => $setup.logout && $setup.logout(...args), ["prevent"])),
    href: "javascript:void;"
  }, _hoisted_33)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 512 /* NEED_PATCH */)])], 64 /* STABLE_FRAGMENT */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <hr> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" eslint-enable ")], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */);
}

//# sourceURL=webpack://plataforma/./src/views/layout/header.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D