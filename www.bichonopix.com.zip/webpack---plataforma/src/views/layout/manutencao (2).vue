__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue_demi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-demi */ "./node_modules/vue-demi/lib/index.mjs");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Manutencao',
  setup() {
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const route = (0,vue_router__WEBPACK_IMPORTED_MODULE_1__.useRoute)();
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_2__.useStore)();
    const vversion = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['_getVersion']);
    (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.onMounted)(() => {});
    return {
      store,
      router,
      route,
      vversion
    };
  },
  computed: {
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_2__.mapGetters)('login', ['auth']),
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_2__.mapGetters)('saldos', ['listSaldos'])
  }
});

//# sourceURL=webpack://plataforma/./src/views/layout/manutencao.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D