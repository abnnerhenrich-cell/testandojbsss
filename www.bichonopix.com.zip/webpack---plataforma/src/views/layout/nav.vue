__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _assets_icons_cash_stack_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/icons/cash-stack.svg */ "./src/assets/icons/cash-stack.svg");
/* harmony import */ var _assets_icons_resultados_bnp_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/assets/icons/resultados-bnp.svg */ "./src/assets/icons/resultados-bnp.svg");
/* harmony import */ var _assets_icons_ic_promocoes_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/assets/icons/ic-promocoes.svg */ "./src/assets/icons/ic-promocoes.svg");
/* harmony import */ var _assets_icons_cotacao_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/assets/icons/cotacao.svg */ "./src/assets/icons/cotacao.svg");
/* harmony import */ var _assets_icons_sair_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/assets/icons/sair.svg */ "./src/assets/icons/sair.svg");
/* harmony import */ var _assets_icons_logar_nav_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/assets/icons/logar-nav.svg */ "./src/assets/icons/logar-nav.svg");
/* harmony import */ var _assets_icons_person_plus_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/assets/icons/person-plus.svg */ "./src/assets/icons/person-plus.svg");








const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-b0e39950"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = {
  class: "offcanvas-header gap-3 px-4"
};
const _hoisted_2 = {
  class: "d-flex align-items-center justify-content-between"
};
const _hoisted_3 = ["src"];
const _hoisted_4 = {
  key: 0,
  class: "w-100 d-flex justify-content-start gap-2 align-items-center ms-2 mt-2"
};
const _hoisted_5 = {
  class: "d-flex flex-column justify-content-start align-items-center h-100"
};
const _hoisted_6 = {
  class: "circle"
};
const _hoisted_7 = ["src"];
const _hoisted_8 = {
  class: "d-flex flex-column align-items-start justify-content-start gap-1"
};
const _hoisted_9 = {
  class: "d-flex flex-column justify-content-start align-items-end overflow-hidden"
};
const _hoisted_10 = {
  class: "w-100 d-flex justify-content-start gap-2 align-items-center ms-2"
};
const _hoisted_11 = ["src"];
const _hoisted_12 = {
  class: "currency"
};
const _hoisted_13 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "label-currency-field text-end"
}, "Saldo créditos", -1 /* HOISTED */));
const _hoisted_14 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "currency-separator"
}, null, -1 /* HOISTED */));
const _hoisted_15 = {
  class: "d-flex flex-column justify-content-start align-items-end overflow-hidden"
};
const _hoisted_16 = {
  class: "w-100 d-flex justify-content-start gap-2 align-items-center ms-2"
};
const _hoisted_17 = ["src"];
const _hoisted_18 = {
  class: "currency"
};
const _hoisted_19 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "label-currency-field text-end"
}, "Saldo bonus", -1 /* HOISTED */));
const _hoisted_20 = {
  class: "offcanvas-body px-4 menu"
};
const _hoisted_21 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_cash_stack_svg__WEBPACK_IMPORTED_MODULE_1__,
  class: "img-fluid img-cash"
}, null, -1 /* HOISTED */));
const _hoisted_22 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "text-depositar"
}, "Depositar", -1 /* HOISTED */));
const _hoisted_23 = {
  class: "version"
};
const _hoisted_24 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("hr", {
  class: "divider"
}, null, -1 /* HOISTED */));
const _hoisted_25 = {
  class: "nav flex-column align-items-start",
  id: "menu"
};
const _hoisted_26 = {
  class: "w-100 menu-itens"
};
const _hoisted_27 = ["src"];
const _hoisted_28 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "apostar-link"
}, "Apostar", -1 /* HOISTED */));
const _hoisted_29 = {
  key: 0,
  class: "bi bi-chevron-up"
};
const _hoisted_30 = {
  key: 1,
  class: "bi bi-chevron-down"
};
const _hoisted_31 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "menu-item-img"
}, null, -1 /* HOISTED */));
const _hoisted_32 = {
  key: 0
};
const _hoisted_33 = ["onClick"];
const _hoisted_34 = ["src"];
const _hoisted_35 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("hr", null, null, -1 /* HOISTED */));
const _hoisted_36 = {
  class: "w-100"
};
const _hoisted_37 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_resultados_bnp_svg__WEBPACK_IMPORTED_MODULE_2__,
  class: "img-fluid img-menu",
  alt: "resultados"
}, null, -1 /* HOISTED */));
const _hoisted_38 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Resultados", -1 /* HOISTED */));
const _hoisted_39 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("hr", null, null, -1 /* HOISTED */));
const _hoisted_40 = {
  class: "w-100"
};
const _hoisted_41 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_ic_promocoes_svg__WEBPACK_IMPORTED_MODULE_3__,
  class: "img-fluid img-menu",
  alt: "promoções"
}, null, -1 /* HOISTED */));
const _hoisted_42 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Promoções", -1 /* HOISTED */));
const _hoisted_43 = {
  key: 0
};
const _hoisted_44 = {
  key: 1,
  class: "w-100"
};
const _hoisted_45 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_cotacao_svg__WEBPACK_IMPORTED_MODULE_4__,
  class: "img-fluid img-menu",
  alt: "promoções"
}, null, -1 /* HOISTED */));
const _hoisted_46 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, " Cotacões ", -1 /* HOISTED */));
const _hoisted_47 = {
  key: 2
};
const _hoisted_48 = {
  class: "w-100 menu-itens"
};
const _hoisted_49 = ["src"];
const _hoisted_50 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "meuperfil-link"
}, "Minha Conta", -1 /* HOISTED */));
const _hoisted_51 = {
  key: 0,
  class: "bi bi-chevron-up"
};
const _hoisted_52 = {
  key: 1,
  class: "bi bi-chevron-down"
};
const _hoisted_53 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
  class: "menu-item-img"
}, null, -1 /* HOISTED */));
const _hoisted_54 = {
  key: 1
};
const _hoisted_55 = {
  class: "img-produtos"
};
const _hoisted_56 = ["src"];
const _hoisted_57 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Extratos", -1 /* HOISTED */));
const _hoisted_58 = {
  class: "img-produtos"
};
const _hoisted_59 = ["src"];
const _hoisted_60 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Saques", -1 /* HOISTED */));
const _hoisted_61 = {
  key: 3
};
const _hoisted_62 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_sair_svg__WEBPACK_IMPORTED_MODULE_5__,
  class: "img-fluid img-menu",
  alt: "Sair"
}, null, -1 /* HOISTED */));
const _hoisted_63 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Sair", -1 /* HOISTED */));
const _hoisted_64 = [_hoisted_62, _hoisted_63];
const _hoisted_65 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("hr", null, null, -1 /* HOISTED */));
const _hoisted_66 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_logar_nav_svg__WEBPACK_IMPORTED_MODULE_6__,
  class: "img-fluid img-menu",
  alt: "Login"
}, null, -1 /* HOISTED */));
const _hoisted_67 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Entrar", -1 /* HOISTED */));
const _hoisted_68 = [_hoisted_66, _hoisted_67];
const _hoisted_69 = {
  key: 6
};
const _hoisted_70 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_person_plus_svg__WEBPACK_IMPORTED_MODULE_7__,
  class: "img-fluid img-menu",
  alt: "Cadastrar"
}, null, -1 /* HOISTED */));
const _hoisted_71 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "Cadastre-se", -1 /* HOISTED */));
const _hoisted_72 = [_hoisted_70, _hoisted_71];
const _hoisted_73 = {
  key: 1
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_router_link = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("router-link");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" eslint-disable "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(vue__WEBPACK_IMPORTED_MODULE_0__.Transition, {
    name: "menu-animation"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [$setup.menu ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: 0,
      id: "menu",
      class: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)([!$setup.menu ? 'offcanvas' : 'offcanvas offcanvas-start show']),
      style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)({
        visibility: $setup.menu ? 'visible !important' : 'none !important'
      }),
      tabindex: "0",
      "data-bs-backdrop": "false"
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/logo.png */ "./src/assets/logo.png"),
      alt: "menu Bicho no pix",
      class: "img-fluid img-logo w-50",
      onClick: _cache[0] || (_cache[0] = $event => _ctx.$router.push({
        name: 'home'
      }))
    }, null, 8 /* PROPS */, _hoisted_3), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <button type=\"button\" @click=\"closeMenu\" class=\"btn-close\" data-bs-dismiss=\"offcanvas\" aria-label=\"Close\"></button> ")]), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/icons/person.svg */ "./src/assets/icons/person.svg"),
      class: "header-icon-person"
    }, null, 8 /* PROPS */, _hoisted_7)])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_8, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_10, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/icons/saldo_creditos.svg */ "./src/assets/icons/saldo_creditos.svg"),
      class: "currency-img"
    }, null, 8 /* PROPS */, _hoisted_11), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_12, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(_ctx._currency($setup.listSaldos.saldo)), 1 /* TEXT */)]), _hoisted_13]), _hoisted_14, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_15, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_16, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/icons/saldo_creditos.svg */ "./src/assets/icons/saldo_creditos.svg"),
      class: "currency-img"
    }, null, 8 /* PROPS */, _hoisted_17), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_18, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(_ctx._currency($setup.listSaldos.bonus)), 1 /* TEXT */)]), _hoisted_19])])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_20, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Card d saldos "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <cardSaldos v-if=\"isAuth\" /> "), $setup.isAuth && $setup.isPix ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_router_link, {
      key: 0,
      to: {
        name: 'creditos'
      },
      class: "d-flex align-items-center justify-content-center menu-credito"
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_21, _hoisted_22]),
      _: 1 /* STABLE */
    })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <router-link :to=\"{ name: 'resgate'}\" class=\"d-flex align-items-center justify-content-center menu-credito premio mt-1\" v-if=\"isAuth\">\r\n            Receber Prêmios\r\n          </router-link>\r\n          <span class=\"d-flex align-items-center justify-content-center menu-credito premio mt-1\">  </span> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_23, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */), _hoisted_24, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ul", _hoisted_25, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_26, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", {
      onClick: _cache[1] || (_cache[1] = (...args) => $setup.toggleApostar && $setup.toggleApostar(...args))
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/icons/ic-apostar.svg */ "./src/assets/icons/ic-apostar.svg"),
      alt: "apostar",
      class: "img-fluid img-menu"
    }, null, 8 /* PROPS */, _hoisted_27), _hoisted_28, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <img :src=\"require('@/assets/icons/arrow_down.svg')\" alt=\"super25\" class=\"img-fluid img-arrow\" /> "), $setup.showApostarSubmenu ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("i", _hoisted_29)) : ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("i", _hoisted_30))]), _hoisted_31, $setup.showApostarSubmenu ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("ul", _hoisted_32, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.produtos, produto => {
      return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
        key: produto,
        class: "img-produtos",
        onClick: $event => $setup.selectProduct(produto.id)
      }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__("./src/assets/produtos/svg sync recursive ^\\.\\/.*\\.svg$")(`./${produto.config.ID_PROD}.svg`),
        alt: "produtos",
        class: "img-fluid"
      }, null, 8 /* PROPS */, _hoisted_34)])], 8 /* PROPS */, _hoisted_33);
    }), 128 /* KEYED_FRAGMENT */))])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), _hoisted_35, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_36, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
      to: {
        name: 'resultados'
      },
      class: "d-block result"
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_37, _hoisted_38]),
      _: 1 /* STABLE */
    })]), _hoisted_39, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_40, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
      to: {
        name: ''
      },
      class: "d-block result",
      onClick: $setup.openPromocoes
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_41, _hoisted_42]),
      _: 1 /* STABLE */
    }, 8 /* PROPS */, ["onClick"])]), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_43)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", _hoisted_44, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <router-link :to=\"{ name: '' }\" class=\"d-block result\" @click=\"openPromocoes\">\r\n              <img src=\"@/assets/icons/ic-promocoes.svg\" class=\"img-fluid img-menu\" alt=\"promoções\"/>\r\n              <span>Promoções</span>\r\n            </router-link> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
      to: {
        name: 'cotacoes'
      },
      class: "d-block result"
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_45, _hoisted_46]),
      _: 1 /* STABLE */
    })])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_47)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_48, [$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
      key: 0,
      onClick: _cache[2] || (_cache[2] = (...args) => $setup.toggleMeuPerfil && $setup.toggleMeuPerfil(...args))
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
      src: __webpack_require__(/*! @/assets/icons/meu_perfil.svg */ "./src/assets/icons/meu_perfil.svg"),
      alt: "apostar",
      class: "img-fluid img-menu"
    }, null, 8 /* PROPS */, _hoisted_49), _hoisted_50, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <img :src=\"require('@/assets/icons/arrow_down.svg')\" alt=\"super25\" class=\"img-fluid img-arrow\" /> "), $setup.showMeuPerfilSubmenu ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("i", _hoisted_51)) : ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("i", _hoisted_52))])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), _hoisted_53, $setup.showMeuPerfilSubmenu ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("ul", _hoisted_54, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <li class=\"img-produtos\">\r\n                <router-link :to=\"{ name: 'minhasApostas' }\">\r\n                  <img :src=\"require(`@/assets/icons/minhas_apostas.svg`)\" alt=\"Minhas Apostas\" class=\"img-fluid img-menu\"/>\r\n                  <span>Minhas apostas</span>\r\n                </router-link>\r\n              </li> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_55, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
      to: {
        name: 'extrato'
      }
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__(/*! @/assets/icons/extrato.svg */ "./src/assets/icons/extrato.svg"),
        alt: "Extratos",
        class: "img-fluid img-menu"
      }, null, 8 /* PROPS */, _hoisted_56), _hoisted_57]),
      _: 1 /* STABLE */
    })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_58, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
      to: {
        name: 'resgate'
      }
    }, {
      default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
        src: __webpack_require__(/*! @/assets/icons/saques.svg */ "./src/assets/icons/saques.svg"),
        alt: "Saques",
        class: "img-fluid img-menu"
      }, null, 8 /* PROPS */, _hoisted_59), _hoisted_60]),
      _: 1 /* STABLE */
    })])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_61)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
      key: 4,
      class: "w-100",
      onClick: _cache[3] || (_cache[3] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)((...args) => $setup.logout && $setup.logout(...args), ["prevent"])),
      href: "javascript:void;"
    }, _hoisted_64)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), _hoisted_65, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("  isAuth login e cadastrar "), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
      key: 5,
      class: "w-100",
      onClick: _cache[4] || (_cache[4] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)($event => $setup.openModal('open::modal::login'), ["prevent"]))
    }, _hoisted_68)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_69)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
      key: 7,
      class: "w-100",
      onClick: _cache[5] || (_cache[5] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.withModifiers)($event => $setup.openModal('open::modal::cadastro'), ["prevent"]))
    }, _hoisted_72)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("hr", _hoisted_73)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <p> {{ _date('now', null, 'YYYY') }} © Bicho no pix. Todos os direitos reservados. </p> ")], 6 /* CLASS, STYLE */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]),
    _: 1 /* STABLE */
  })], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */);
}

//# sourceURL=webpack://plataforma/./src/views/layout/nav.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D