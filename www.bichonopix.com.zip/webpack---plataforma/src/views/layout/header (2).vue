__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_mixins__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/mixins */ "./src/core/mixins/index.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue_demi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-demi */ "./node_modules/vue-demi/lib/index.mjs");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var maska__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! maska */ "./node_modules/maska/dist/maska.esm.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../core/service/utils */ "./src/core/service/utils.js");








/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'header',
  mixins: [_core_mixins__WEBPACK_IMPORTED_MODULE_0__.filterMixins],
  setup() {
    const app = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const route = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRoute)();
    const redirect = () => {
      if (router.currentRoute.value.fullPath === '/revenda') router.push({
        name: 'auth'
      });
      router.push({
        name: 'home'
      });
    };
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_7__.useStore)();
    const user = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.state.login.user.phoneFormat);
    const vversion = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['_getVersion']);
    const isAuth = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['login/auth']);
    const isMenuOpenPerfil = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.ref)(false);
    const menu = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.ref)();
    const listSaldos = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['saldos/listSaldos']);
    const formatPhone = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      const dados = user.value || '';
      const mascara = (0,maska__WEBPACK_IMPORTED_MODULE_2__.mask)(dados, '(##) # ####-####');
      const part1 = String(mascara).slice(0, 4);
      const part2 = String(mascara).slice((0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(mascara) - 4, (0,lodash__WEBPACK_IMPORTED_MODULE_3__.size)(mascara));
      return `${part1} ... ${part2}`;
    });
    const toggleMenuPerfil = () => {
      isMenuOpenPerfil.value = !isMenuOpenPerfil.value;
    };
    (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__.useDetectOutsideClick)(menu, () => {
      if (isMenuOpenPerfil) {
        isMenuOpenPerfil.value = false;
      }
    });
    const logout = () => {
      store.dispatch('login/logout');
      _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].remove('auth-token');
      router.push({
        path: '/'
      });
      store.dispatch('setMenu', false);
      location.reload();
    };
    const addCredit = () => {
      router.push({
        name: 'creditos'
      });
    };
    const openRouter = routerName => {
      router.push({
        name: routerName
      });
    };
    const iframeCartelas = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      const show = ['/cartelas', '/cartelas2'];
      return show.indexOf(route.path) !== -1;
    });
    const openModal = name => Events.emit(name, true);
    const openMenu = () => {
      store.dispatch('setMenu', !store.state.menu);
    };
    const userDados = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => store.getters['perfil/oldUser']) || {};
    const isLogado = (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.computed)(() => {
      if (userDados.value.jsonFlags && userDados.value.jsonFlags.resetPassword) {
        return false;
      }
      return store.state.login.token;
    });
    const intervalCheckJWT = setInterval(() => {
      if (!isAuth.value) return;
      store.dispatch('login/checkJWT').catch(async e => {
        console.log('error', e.message);
        if (e.message === 'jwt expired') {
          store.dispatch('login/refreshToken').catch(async e => {
            store.dispatch('logout');
            _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].remove('auth-token');
            if (String(e.message).indexOf('Usuário bloqueado') !== -1) (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__._alert)(e.message, 'warning');else (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__._alert)('Sessão expirada!', 'warning');
            setTimeout(() => {
              window.location = '/';
            }, 1200);
          });
          return;
        }
        store.dispatch('logout');
        _core_service_session__WEBPACK_IMPORTED_MODULE_4__["default"].remove('auth-token');
        if (String(e.message).indexOf('Usuário bloqueado') !== -1) (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__._alert)(e.message, 'warning');else (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_5__._alert)('Sessão expirada!', 'warning');
        setTimeout(() => {
          window.location = '/';
        }, 1200);
      });
    }, 1000 * 60 * 5);
    const initCheckJWT = () => ({
      intervalCheckJWT
    });
    (0,vue_demi__WEBPACK_IMPORTED_MODULE_1__.onMounted)(() => {
      initCheckJWT();
    });
    return {
      store,
      openMenu,
      isLogado,
      router,
      route,
      redirect,
      formatPhone,
      vversion,
      iframeCartelas,
      openModal,
      isAuth,
      addCredit,
      toggleMenuPerfil,
      isMenuOpenPerfil,
      logout,
      openRouter,
      menu,
      listSaldos
    };
  },
  computed: {
    ...(0,vuex__WEBPACK_IMPORTED_MODULE_7__.mapGetters)('login', ['auth'])
  }
});

//# sourceURL=webpack://plataforma/./src/views/layout/header.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D