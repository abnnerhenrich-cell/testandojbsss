__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _core_mixins__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/mixins */ "./src/core/mixins/index.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");







/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'menu-nav',
  mixins: [_core_mixins__WEBPACK_IMPORTED_MODULE_1__.filterMixins],
  components: {
    // cardSaldos: defineAsyncComponent(() => import('./cardSaldos.vue'))
  },
  setup() {
    const app = (0,vue__WEBPACK_IMPORTED_MODULE_0__.getCurrentInstance)();
    const {
      Events,
      $loading
    } = app.appContext.config.globalProperties;
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_5__.useStore)();
    const route = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRoute)();
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const menu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.state.menu);
    const isAuth = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/auth']);
    const configBonusWeb = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/configBonusWeb']);
    const produtos = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['listagemProdutos/listProdutos']);
    const vversion = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['_getVersion']);
    const showRaspadinha = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const list = store.getters['listagemProdutos/listProdutosResultado'];
      return (0,lodash__WEBPACK_IMPORTED_MODULE_2__.size)(list) ? list.filter(v => v.id === 'RASPADINHA')[0] : false;
    });
    const listSaldos = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['saldos/listSaldos']);
    const showApostarSubmenu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(true);
    const showMeuPerfilSubmenu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const openPromocoes = () => {
      closeMenu();
      (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Promoções em Breve !', 'info', 'var(--background-gradient-dark, linear-gradient(90deg, #090A14 3.02%, #0D0F1E 100%))', 'white');
    };
    const selectProduct = async productId => {
      if (!isAuth.value) return Events.emit('open::modal::login::produto::selecionado', productId);
      const prod = await store.dispatch('listagemProdutos/setSelectProdutoAtual', productId);
      if (!prod) {
        return;
      }
      const load = $loading.show();
      Events.emit('clear::all::aposta');
      Events.emit('clear::loterias::change::date');
      Events.emit('clear::modalidade');
      store.dispatch('listagemProdutos/getModalitiesCategories', {
        id: productId
      }).then(() => {
        store.dispatch('listagemProdutos/getLoteriasProdutos', productId).then(() => {
          router.push({
            name: 'apostas'
          }).then(() => {
            load.hide();
            store.dispatch('setTabActive', 1);
          });
        });
      }).catch(e => {
        load.hide();
        if (e === 'Token não fornecido') {
          Events.emit('open::modal::login', true);
        } else {
          (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)(e, 'error');
        }
      }).finally(() => store.dispatch('setMenu', false));
    };

    // permite visualizar pix
    const isPix = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const dados = store.getters['login/getUser'];
      return dados.jsonFlags && dados.jsonFlags.pixVisible === true ? 1 : 0;
    });
    const toggleApostar = () => {
      showApostarSubmenu.value = !showApostarSubmenu.value;
    };
    const toggleMeuPerfil = () => {
      showMeuPerfilSubmenu.value = !showMeuPerfilSubmenu.value;
    };

    // Detecta click outside para fechar menu
    const closeMenuOnOutsideClick = event => {
      const menuElement = document.getElementById('menu');
      if (menuElement && !menuElement.contains(event.target)) {
        closeMenu();
      }
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(() => {
      document.addEventListener('click', closeMenuOnOutsideClick);
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onUnmounted)(() => {
      document.removeEventListener('click', closeMenuOnOutsideClick);
    });
    const openModal = name => Events.emit(name, true);
    const isResetPassword = (0,vue__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/isResetPassword']);
    const closeMenu = () => {
      store.dispatch('setMenu', false);
    };
    const logout = () => {
      store.dispatch('login/logout');
      _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].remove('auth-token');
      router.push({
        path: '/'
      });
      location.reload();
    };
    const openModalJogoResponsavel = () => {
      Events.emit('modal::produtos::jogoResponsavel', true);
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(() => route.path, async () => {
      closeMenu();
    });
    return {
      closeMenuOnOutsideClick,
      closeMenu,
      menu,
      logout,
      isAuth,
      isResetPassword,
      isPix,
      configBonusWeb,
      showRaspadinha,
      openModalJogoResponsavel,
      toggleApostar,
      toggleMeuPerfil,
      showApostarSubmenu,
      showMeuPerfilSubmenu,
      produtos,
      openPromocoes,
      listSaldos,
      selectProduct,
      router,
      openModal,
      vversion
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/layout/nav.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D