__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _assets_icons_resultados_bnp_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/icons/resultados-bnp.svg */ "./src/assets/icons/resultados-bnp.svg");
/* harmony import */ var _assets_icons_ic_apostar_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/assets/icons/ic-apostar.svg */ "./src/assets/icons/ic-apostar.svg");
/* harmony import */ var _assets_icons_cotacao_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/assets/icons/cotacao.svg */ "./src/assets/icons/cotacao.svg");
/* harmony import */ var _assets_icons_contract_2_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/assets/icons/contract-2.svg */ "./src/assets/icons/contract-2.svg");





const _withScopeId = n => ((0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-468dfdb5"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n);
const _hoisted_1 = {
  key: 0,
  class: "menu"
};
const _hoisted_2 = {
  class: "d-flex justify-content-between card"
};
const _hoisted_3 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item'])
};
const _hoisted_4 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_resultados_bnp_svg__WEBPACK_IMPORTED_MODULE_1__
}, null, -1 /* HOISTED */));
const _hoisted_5 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Resultados ", -1 /* HOISTED */));
const _hoisted_6 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item'])
};
const _hoisted_7 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_ic_apostar_svg__WEBPACK_IMPORTED_MODULE_2__
}, null, -1 /* HOISTED */));
const _hoisted_8 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Apostar ", -1 /* HOISTED */));
const _hoisted_9 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item '])
};
const _hoisted_10 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_cotacao_svg__WEBPACK_IMPORTED_MODULE_3__
}, null, -1 /* HOISTED */));
const _hoisted_11 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Cotacões ", -1 /* HOISTED */));
const _hoisted_12 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item '])
};
const _hoisted_13 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_contract_2_svg__WEBPACK_IMPORTED_MODULE_4__
}, null, -1 /* HOISTED */));
const _hoisted_14 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Bilhete ", -1 /* HOISTED */));
const _hoisted_15 = {
  key: 0,
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['position-absoluted start-100 translate-middle rounded-pill', 'badge'])
};
const _hoisted_16 = {
  class: "VERSION bold f10 d-block text-center"
};
const _hoisted_17 = {
  key: 1,
  class: "menu"
};
const _hoisted_18 = {
  class: "d-flex justify-content-between card"
};
const _hoisted_19 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item'])
};
const _hoisted_20 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_resultados_bnp_svg__WEBPACK_IMPORTED_MODULE_1__
}, null, -1 /* HOISTED */));
const _hoisted_21 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Resultados ", -1 /* HOISTED */));
const _hoisted_22 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item'])
};
const _hoisted_23 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_ic_apostar_svg__WEBPACK_IMPORTED_MODULE_2__
}, null, -1 /* HOISTED */));
const _hoisted_24 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Apostar ", -1 /* HOISTED */));
const _hoisted_25 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item '])
};
const _hoisted_26 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_cotacao_svg__WEBPACK_IMPORTED_MODULE_3__
}, null, -1 /* HOISTED */));
const _hoisted_27 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Cotacões ", -1 /* HOISTED */));
const _hoisted_28 = {
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['card-item '])
};
const _hoisted_29 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
  src: _assets_icons_contract_2_svg__WEBPACK_IMPORTED_MODULE_4__
}, null, -1 /* HOISTED */));
const _hoisted_30 = /*#__PURE__*/_withScopeId(() => /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
  class: "f10"
}, " Bilhete ", -1 /* HOISTED */));
const _hoisted_31 = {
  key: 0,
  class: /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(['position-absoluted start-100 translate-middle rounded-pill', 'badge'])
};
const _hoisted_32 = {
  class: "VERSION bold f10 d-block text-center"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_router_link = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("router-link");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" eslint-disable "), $setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['card-item ']\">\r\n          <router-link active-class=\"active\" :to=\"{ name: ''}\" class=\"v2\" :href=\"whatsappLink\" target=\"_blank\">\r\n            <img src=\"@/assets/icons/ic-suport.svg\"/>\r\n            <span class=\"f10\"> Suporte  </span>\r\n          </router-link>\r\n        </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: 'resultados'
    },
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_4, _hoisted_5]),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    onClick: $setup.setProdutoFix,
    to: {
      name: 'home'
    },
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_7, _hoisted_8]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["onClick"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['card-item ']\">\r\n          <router-link active-class=\"active\" :to=\"{ name: ''}\" class=\"v2\" @click=\"openPromocoes\">\r\n            <img src=\"@/assets/icons/ic-promocoes.svg\" />\r\n            <span class=\"f10\"> Promoções  </span>\r\n          </router-link>\r\n        </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: 'cotacoes'
    },
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_10, _hoisted_11]),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_12, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: ''
    },
    onClick: $setup.openModalCarrinho,
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_13, _hoisted_14, $setup.listCarrinho.qtd > 0 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_15, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.listCarrinho.qtd), 1 /* TEXT */)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["onClick"])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_16, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Salvar vai que volta né "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div class=\"d-flex justify-content-between card\" >\r\n      <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: 'home'}\">\r\n          <i class=\"bi bi-ui-checks-grid f19\"> </i>\r\n          <span class=\"f10\"> Apostar  </span>\r\n        </router-link>\r\n      </div>\r\n\r\n      <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: 'resultados'}\" class=\"p-2\">\r\n          <template v-if=\"router.name !== 'resultados'\">\r\n            <img src=\"@/assets/icons/resultado.svg\" class=\"icon-result\" />\r\n          </template>\r\n          <template v-else>\r\n            <img src=\"@/assets/icons/resultado-white.svg\" />\r\n          </template>\r\n          <span class=\"f10\"> Resultados  </span>\r\n        </router-link>\r\n      </div>\r\n\r\n      <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: 'indexar.bilhetes'}\" class=\"p-2\">\r\n          <i class=\"bi bi-box-arrow-in-down f19\"></i>\r\n          <span class=\"f10\"> Indexar  </span>\r\n        </router-link>\r\n      </div>\r\n\r\n\r\n      <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\"  :to=\"{ name: 'conferir.bilhetes'}\" class=\"p-2\">\r\n          <i class=\"bi bi-bookmark-check f19\"></i>\r\n          <span class=\"f10\"> Conferir  </span>\r\n        </router-link>\r\n      </div>\r\n\r\n      <div :class=\"['card-item ']\">\r\n        <router-link  active-class=\"active\" :to=\"{ name: 'creditos'}\" class=\"p-2\">\r\n          <i class=\"bi bi-coin f19\"></i>\r\n          <span class=\"f10\"> Comprar  </span>\r\n        </router-link>\r\n      </div>\r\n\r\n      <div :class=\"['card-item mx-2 ms-sm-3']\">\r\n          <a href=\"javascript:void(0)\" @click=\"openModalCarrinho\">\r\n            <i class=\"bi bi-cart4 f19\"></i>\r\n            <span class=\"f10\"> Carrinho  </span>\r\n            <span class=\"card-number center\"> {{  listCarrinho.qtd }} </span>\r\n          </a>\r\n      </div>\r\n\r\n    </div> ")])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Foooter sem autenticacao "), !$setup.isAuth ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_17, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_18, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Gambis para link apple "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-if=\"!lixoApple\" :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: 'auth'}\" class=\"v2 teste-button\">\r\n          <i class=\"bi bi-ui-checks-grid f19\"> </i> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <template v-if=\"router.name === 'auth'\">\r\n            <img src=\"@/assets/icons/mini-logo-white.svg\" />\r\n          </template>\r\n          <template v-else>\r\n            <img src=\"@/assets/icons/mini-logo.svg\" />\r\n          </template> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <span class=\"f10\"> Baixar APP  </span>\r\n        </router-link>\r\n      </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div v-else :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: 'auth'}\" class=\"v2\" @click.prevent=\"verificarToastIOS\">\r\n          <template v-if=\"router.name === 'auth'\">\r\n            <img src=\"@/assets/icons/mini-logo-white.svg\" />\r\n          </template>\r\n          <template v-else>\r\n            <img src=\"@/assets/icons/mini-logo.svg\" />\r\n          </template>\r\n\r\n          <span class=\"f10\"> Baixar APP  </span>\r\n        </router-link>\r\n      </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" Fim gambiarra "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: ''}\" class=\"p-2 v2\" :href=\"whatsappLink\" target=\"_blank\">\r\n          <img src=\"@/assets/icons/ic-suport.svg\"/>\r\n          <span class=\"f10\"> Suporte  </span>\r\n        </router-link>\r\n      </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_19, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: 'resultados'
    },
    class: "p-2 v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_20, _hoisted_21]),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_22, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    onClick: _cache[0] || (_cache[0] = $event => $setup.openModal('open::modal::login', true)),
    to: {
      name: 'home'
    },
    class: "p-2 v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_23, _hoisted_24]),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <div :class=\"['card-item ']\">\r\n        <router-link active-class=\"active\" :to=\"{ name: ''}\" @click=\"openPromocoes\" class=\"p-2 v2\">\r\n          <img src=\"@/assets/icons/ic-promocoes.svg\" />\r\n          <span class=\"f10\"> Promoções  </span>\r\n        </router-link>\r\n      </div> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_25, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: 'cotacoes'
    },
    onClick: _cache[1] || (_cache[1] = $event => $setup.openModal('open::modal::login', true)),
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_26, _hoisted_27]),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_28, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_link, {
    "active-class": "active",
    to: {
      name: 'home'
    },
    onClick: _cache[2] || (_cache[2] = $event => $setup.openModal('open::modal::login', true)),
    class: "v2"
  }, {
    default: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(() => [_hoisted_29, _hoisted_30, $setup.listCarrinho.qtd > 0 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("span", _hoisted_31, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.listCarrinho.qtd), 1 /* TEXT */)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]),
    _: 1 /* STABLE */
  })])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_32, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.vversion), 1 /* TEXT */)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 64 /* STABLE_FRAGMENT */);
}

//# sourceURL=webpack://plataforma/./src/views/layout/menuFooter.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D