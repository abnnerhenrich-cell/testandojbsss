__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_demi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-demi */ "./node_modules/vue-demi/lib/index.mjs");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _core_service_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/service/utils */ "./src/core/service/utils.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);





// eslint-disable-next-line
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'menu-footer',
  setup() {
    const app = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.getCurrentInstance)();
    const {
      Events
    } = app.appContext.config.globalProperties;
    const toast = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.inject)('$toast');
    const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_3__.useRoute)();
    const store = (0,vuex__WEBPACK_IMPORTED_MODULE_4__.useStore)();
    const isAuth = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/auth']);
    let deferredPrompt = null;
    const lixoApple = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    const addBtn = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.ref)(null);
    const vversion = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['_getVersion']);
    const listCarrinho = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      return store.getters['carrinho/listCarrinho'];
    });
    const setProdutoFix = () => {
      // store.dispatch('listagemProdutos/setSelectProdutoAtual', 'BT')
    };
    const openPromocoes = () => {
      (0,_core_service_utils__WEBPACK_IMPORTED_MODULE_1__._alert)('Promoções em Breve !', 'info', 'var(--background-gradient-dark, linear-gradient(90deg, #090A14 3.02%, #0D0F1E 100%))', 'white');
    };
    const openModal = (modal, value) => {
      Events.emit(modal, value);
    };
    const openModalCarrinho = () => Events.emit('open::modal::carrinho', true);
    const isIos = () => {
      const userAgent = window.navigator.userAgent.toLowerCase();
      return /iphone|ipad|ipod/.test(userAgent);
    };
    const isInStandaloneMode = () => 'standalone' in window.navigator && window.navigator.standalone;
    const verificarToastIOS = () => {
      if (isIos() && !isInStandaloneMode()) {
        toast('Click no ícone informado e selecione adicinar tela!', {
          positionX: 'center',
          duration: '10000000',
          type: 'passive',
          class: 'lixoApple',
          slotRight: '<span> <i class="f20 bi bi-box-arrow-up"></i> </span>'
        });
      }
    };
    const telefoneSuporte = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => store.getters['login/telefoneSuporte']);
    const whatsappLink = (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.computed)(() => {
      const message = 'Suporte Bicho no Pix, tenho uma dúvida, poderia me ajudar?';
      const tel = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.sample)(telefoneSuporte.value.whatsappSuport);
      return `https://api.whatsapp.com/send?phone=${tel}&text=${encodeURIComponent(message)}`;
    });
    window.addEventListener('beforeinstallprompt', e => {
      e.preventDefault();
      deferredPrompt = e;
      if (!addBtn.value) return;
      addBtn.value.addEventListener('click', e => {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then(choiceResult => {
          if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the A2HS prompt');
          } else {
            console.log('User dismissed the A2HS prompt');
          }
          deferredPrompt = null;
        });
      });
    });
    (0,vue_demi__WEBPACK_IMPORTED_MODULE_0__.onMounted)(() => {
      addBtn.value = document.getElementsByClassName('teste-button')[0];
    });
    return {
      isAuth,
      router,
      verificarToastIOS,
      toast,
      lixoApple,
      openModalCarrinho,
      listCarrinho,
      openModal,
      openPromocoes,
      whatsappLink,
      telefoneSuporte,
      setProdutoFix,
      vversion
    };
  }
});

//# sourceURL=webpack://plataforma/./src/views/layout/menuFooter.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/vue-loader/dist/index.js??ruleSet%5B0%5D.use%5B0%5D