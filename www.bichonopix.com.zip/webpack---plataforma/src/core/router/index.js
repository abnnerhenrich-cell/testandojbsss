__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm-bundler.js");
/* harmony import */ var _allRoutes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../allRoutes */ "./src/allRoutes.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store */ "./src/store/index.js");
/* harmony import */ var _service_session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/session */ "./src/core/service/session.js");
/* harmony import */ var _service_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/utils */ "./src/core/service/utils.js");





const routes = [..._allRoutes__WEBPACK_IMPORTED_MODULE_0__["default"]];
const router = (0,vue_router__WEBPACK_IMPORTED_MODULE_4__.createRouter)({
  history: (0,vue_router__WEBPACK_IMPORTED_MODULE_4__.createWebHistory)(({"NODE_ENV":"development","VUE_APP_API":"https://ybcpmke106.execute-api.us-east-1.amazonaws.com/","VUE_APP_KBATATINHA":"A(o)DdVA##KLJJ134nbHUASHUljkjMB6243@!.4","VUE_APP_KEY_PAIR":"BKnGtB4hjk8kD1nqUfAxOnHML4HGytEhwQQUfIXIMtVAlBQiNAt70n3TIzlipW_Sni4XrzCWjIOv-pAE28ecvLs","VUE_APP_KEY_RECAPTCHA_SITE":"6LcRn8MoAAAAANttABiOthlOimprkLZTd8f5NVmS","VUE_APP_SAVE_GAME":"prognosticos-save","VUE_APP_START_GAME":"/prognosticos-buy","VUE_APP_URL":"https://bichonopix.com/","VUE_APP_URL_AWS":"https://s3-images-plublic-bnp-prd.s3.amazonaws.com/","VUE_APP_URL_IBGE":"https://servicodados.ibge.gov.br/api/v1/localidades/estados/","BASE_URL":"/"}).URL),
  routes,
  linkActiveClass: 'link',
  linkExactActiveClass: 'link'
});
router.beforeEach(async (to, from) => {
  // rotas abertas que podem ser acessadas sem estar logado
  const notAuthNames = ['auth', 'conferir.bilhetes', 'revenda', 'iframe.cartelas', 'iframe.cartelas2', 'resultados'];
  console.log('to', to);
  console.log('from', from);
  if (String(to.name).indexOf('bnp') !== -1) notAuthNames.push(to.name);
  console.log(notAuthNames.filter(v => v === to.name)[0], to.from);
  const access = notAuthNames.filter(v => v === to.name)[0];

  /* Cadastrar influenciador */
  if (to.query.btag) {
    _service_session__WEBPACK_IMPORTED_MODULE_2__["default"].set('btag', to.query.btag);
  }
  const isAuth = _service_session__WEBPACK_IMPORTED_MODULE_2__["default"].get('auth-token');
  // console.log('rotas', from.path, to.path)

  if (from.path === '/' && to.path === '/' && !isAuth) return true;
  if (from.path !== '/' && to.path === '/' && !isAuth) return true;
  if (access) return true;

  // caso tenha logado para ver o resultado
  const resultado = _service_session__WEBPACK_IMPORTED_MODULE_2__["default"].get('redirect-result') || false;
  if (from.path === '/' && to.path === '/resultados' && !isAuth) {
    _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('login/openModal', 'resultado');
  }
  if (from.path === '/' && to.path === '/credito-pix' && !isAuth) {
    _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('login/openModal', 'resultado');
  }
  if (!isAuth && resultado) return true;
  if (!isAuth) return {
    name: 'auth'
  };
  _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('saldos/getSaldos').catch(async e => {
    console.log('error', e.message);
    _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('logout');
    _service_session__WEBPACK_IMPORTED_MODULE_2__["default"].remove('auth-token');
    if (String(e.message).indexOf('Usuário bloqueado') !== -1) (0,_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)(e.message, 'warning');else (0,_service_utils__WEBPACK_IMPORTED_MODULE_3__._alert)('Sessão expirada!', 'warning');
    setTimeout(() => {
      window.location = '/';
    }, 1200);
  });
});
/* harmony default export */ __webpack_exports__["default"] = (router);

//# sourceURL=webpack://plataforma/./src/core/router/index.js?