__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var mitt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mitt */ "./node_modules/mitt/dist/mitt.mjs");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _service_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./service/utils */ "./src/core/service/utils.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);






// eslint-disable-next-line 
const CryptoJS = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
// const CLIENTE = axios.create({
//   baseURL: _config.API
// })
(axios__WEBPACK_IMPORTED_MODULE_0___default().defaults.baseURL) = (_core_config__WEBPACK_IMPORTED_MODULE_3___default().API);
const CLIENTE = axios__WEBPACK_IMPORTED_MODULE_0___default().create({});
const Events = (0,mitt__WEBPACK_IMPORTED_MODULE_2__["default"])();
// eslint-disable-next-line 
const exceptionEncryptUrl = ['autenticar'];
CLIENTE.interceptors.request.use(config => {
  if (_core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].get('auth-token')) {
    // config.headers['authorization'] = session.get('auth-token')
    // config.setHeader()
    config.headers.common['authorization'] = _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].get('auth-token');
    config.headers['x-access-token'] = _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].get('auth-token');
  }
  if (config.headers['refresh_token']) {
    _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].set('auth-token', config.headers['refresh_token']);
  }
  config.headers['type'] = 'usuario';
  if (!config.headers['emit']) Events.emit('before-request');
  if (config.method === 'post' && !exceptionEncryptUrl.includes(config.url) && config.data) {
    const ciphertext = CryptoJS.AES.encrypt(JSON.stringify(config.data), (_core_config__WEBPACK_IMPORTED_MODULE_3___default().KBATATINHA)).toString();
    config.data = {
      key: ciphertext
    };
  }
  return config;
}, error => {
  Events.emit('request-error');
  return Promise.reject(error);
});

// Add a response interceptor
CLIENTE.interceptors.response.use(config => {
  if (!config.config.headers['emit']) Events.emit('after-response');
  // const errorToken = config && config.data && !config.data.success && config.data.message === 'Token não fornecido' ? 1 : 0
  // if (errorToken) {
  //   session.remove('auth-token')
  //   session.remove('associarJogoRevenda')
  //   setTimeout(() => { window.location.href = 'auth' }, 3000)
  // }
  if (config.data && config.data.success !== false && (0,lodash__WEBPACK_IMPORTED_MODULE_5__.size)(config.data.data)) {
    const bytes = CryptoJS.AES.decrypt(config.data.data, (_core_config__WEBPACK_IMPORTED_MODULE_3___default().KBATATINHA));
    const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    config.data.data = decryptedData;
  }
  return config;
}, error => {
  Events.emit('response-error');
  if (error.response) {
    // urls que nao emitem error e retiram o token, para nao redirecionar e continuar execução do bingo
    const exceptions = ['/bingo/list-cartelas'];
    const endpoint = error.response.config.url.replace(error.response.config.baseURL, '');
    if (exceptions.indexOf(endpoint) !== -1) {
      return Promise.reject(error.response.data);
    }
    if (error.response.status === 401) {
      (0,_service_utils__WEBPACK_IMPORTED_MODULE_4__._alert)('Sessão expirada!', 'warning');
      _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].remove('auth-token');
      _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].remove('associarJogoRevenda');
      document.getElementsByTagName('body')[0].removeAttribute('style');
      setTimeout(() => {
        window.location = '/';
      }, 1200);
    }
    // Events.$emit('response-error')
    return Promise.reject(error.response.data);
  }
});
/* harmony default export */ __webpack_exports__["default"] = (CLIENTE);

//# sourceURL=webpack://plataforma/./src/core/http.js?