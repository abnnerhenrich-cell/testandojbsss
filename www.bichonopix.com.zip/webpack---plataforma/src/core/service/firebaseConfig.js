__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   messaging: function() { return /* binding */ messaging; }
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.esm.js");
/* harmony import */ var firebase_messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/messaging */ "./node_modules/firebase/messaging/dist/index.esm.js");


// import { getMessaging as getMessagingSW } from 'firebase/messaging/sw'

const config = {
  // apiKey: 'AIzaSyDiEJ2I3jfAugnK6wI2VQFAj8HmbmyJ2vE',
  // authDomain: 'pwa-integration.firebaseapp.com',
  // projectId: 'pwa-integration',
  // databaseURL: 'https://pwa-integration.firebaseio.com',
  // storageBucket: 'pwa-integration.appspot.com',
  // messagingSenderId: '583575914436',
  // appId: '1:583575914436:web:0b829f8d2bb3e3e1704691',
  // measurementId: 'G-LSHS1WW8QC'

  apiKey: 'AIzaSyAVHQnGF3bZB5hIP5Mz5hB5SxtMPnhUp44',
  authDomain: 'vertical-bis.firebaseapp.com',
  projectId: 'vertical-bis',
  storageBucket: 'vertical-bis.appspot.com',
  messagingSenderId: '800192649358',
  appId: '1:800192649358:web:f6afceb58755a49e4cd1df',
  measurementId: 'G-PD9TFWCBXH'
};
const firebase = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(config);
const messaging = (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_1__.getMessaging)(firebase);
// export const messagingSW = getMessagingSW(firebase)

//# sourceURL=webpack://plataforma/./src/core/service/firebaseConfig.js?