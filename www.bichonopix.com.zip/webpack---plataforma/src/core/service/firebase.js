__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: function() { return /* binding */ init; }
/* harmony export */ });
/* harmony import */ var _core_service_firebaseConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/service/firebaseConfig */ "./src/core/service/firebaseConfig.js");
/* harmony import */ var firebase_messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/messaging */ "./node_modules/firebase/messaging/dist/index.esm.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config */ "./src/core/config.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config__WEBPACK_IMPORTED_MODULE_3__);


// import { onBackgroundMessage } from 'firebase/messaging/sw'


const init = () => {
  console.log('tentou registrar');
  console.info('Service worker registration is ready.');
  const isIOS = () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAppleDevice = navigator.userAgent.includes('Macintosh');
    const isTouchScreen = navigator.maxTouchPoints >= 1;
    return isIOS || isAppleDevice && isTouchScreen;
  };
  if (isIOS()) return;
  if (Notification.permission !== 'granted') {
    Notification.requestPermission(permission => {
      if (permission === 'granted') {
        (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_1__.getToken)(_core_service_firebaseConfig__WEBPACK_IMPORTED_MODULE_0__.messaging, {
          vapidKey: (_config__WEBPACK_IMPORTED_MODULE_3___default().keyPair)
        }).then(currentToken => {
          if (currentToken) {
            if (_core_service_session__WEBPACK_IMPORTED_MODULE_2__["default"].get('auth-token')) {
              console.log('teste');
            } else {
              console.log('currentToken: ', currentToken);
              _core_service_session__WEBPACK_IMPORTED_MODULE_2__["default"].set('firebase-token', currentToken);
            }
          } else {
            console.info('No registration token available. Request permission to generate one.');
          }
        }).catch(err => {
          console.error('An error occurred while retrieving token. ', err);
        });
        (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_1__.onMessage)(_core_service_firebaseConfig__WEBPACK_IMPORTED_MODULE_0__.messaging, payload => {
          console.log('Message received in foreground. ', payload);
          const notificationOptions = {
            image: payload.notification.image,
            body: payload.notification.body
          };
          return new Notification(payload.notification.title, notificationOptions);
        });
      }
    });
  }
};

//# sourceURL=webpack://plataforma/./src/core/service/firebase.js?