__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   filterMixins: function() { return /* binding */ filterMixins; }
/* harmony export */ });
/* harmony import */ var _filters_currency__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../filters/currency */ "./src/core/filters/currency.js");
/* harmony import */ var _filters_dates__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../filters/dates */ "./src/core/filters/dates.js");
/* harmony import */ var _filters_numeral__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../filters/numeral */ "./src/core/filters/numeral.js");




// tratamento de dados visualizados na tela
const filterMixins = {
  methods: {
    _currency: (val, simbol, decimal) => (0,_filters_currency__WEBPACK_IMPORTED_MODULE_0__["default"])(val || 0, simbol, decimal),
    _date: (val, format = null, convert = 'DD/MM/YYYY') => (0,_filters_dates__WEBPACK_IMPORTED_MODULE_1__["default"])(val, format, convert),
    _numeral: val => (0,_filters_numeral__WEBPACK_IMPORTED_MODULE_2__["default"])(val)
  }
};

//# sourceURL=webpack://plataforma/./src/core/mixins/index.js?