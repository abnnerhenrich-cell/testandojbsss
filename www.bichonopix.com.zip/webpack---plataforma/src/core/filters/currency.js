__webpack_require__.r(__webpack_exports__);
/* harmony import */ var currency_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! currency.js */ "./node_modules/currency.js/dist/currency.min.js");
/* harmony import */ var currency_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(currency_js__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ((value, notSimbol = false, decimal = false) => {
  // numero usado para cotacao
  if (notSimbol && decimal) return new Intl.NumberFormat('pt-BR', {
    maximumFractionDigits: 1,
    minimumFractionDigits: 0
  }).format(value);
  const valueFormat = String(value).replace('.', ',');
  if (notSimbol) return currency_js__WEBPACK_IMPORTED_MODULE_0___default()(valueFormat, {
    separator: '.',
    decimal: ',',
    symbol: '',
    pattern: '! #',
    negativePattern: '! -#'
  }).format();
  return currency_js__WEBPACK_IMPORTED_MODULE_0___default()(valueFormat, {
    separator: '.',
    decimal: ',',
    symbol: 'R$',
    pattern: '! #',
    negativePattern: '! -#'
  }).format();
});

//# sourceURL=webpack://plataforma/./src/core/filters/currency.js?