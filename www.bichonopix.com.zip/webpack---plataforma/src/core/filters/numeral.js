__webpack_require__.r(__webpack_exports__);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! numeral */ "./node_modules/numeral/numeral.js");
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(numeral__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (value => {
  const moneyFormat = '0[,]0';
  return String(numeral__WEBPACK_IMPORTED_MODULE_0___default()(value).format(moneyFormat)).replace(',', '.');
});

//# sourceURL=webpack://plataforma/./src/core/filters/numeral.js?