__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ((val, format = null, convert = 'DD/MM/YYYY') => {
  if (val === 'now') return moment__WEBPACK_IMPORTED_MODULE_0___default()().format(convert);
  if (format === null) return moment__WEBPACK_IMPORTED_MODULE_0___default()(val).format(convert);
  const data = moment__WEBPACK_IMPORTED_MODULE_0___default()(val, format).format(convert);
  if (data !== 'Invalid Date') return data;
  return val;
});

//# sourceURL=webpack://plataforma/./src/core/filters/dates.js?