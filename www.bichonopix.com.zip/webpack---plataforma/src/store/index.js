__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm-bundler.js");
/* harmony import */ var _modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules */ "./src/store/modules/index.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var youtube_player__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! youtube-player */ "./node_modules/youtube-player/dist/index.js");
/* harmony import */ var youtube_player__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(youtube_player__WEBPACK_IMPORTED_MODULE_2__);




/* harmony default export */ __webpack_exports__["default"] = ((0,vuex__WEBPACK_IMPORTED_MODULE_3__.createStore)({
  state: {
    menu: false,
    estados: [],
    tabActive: '',
    video: {
      id: false,
      config: false
    }
  },
  actions: {
    setMenu: async ({
      state
    }, payload) => {
      state.menu = payload;
    },
    setTabActive: async ({
      state
    }, payload) => {
      state.tabActive = payload;
    },
    nextTabActive: async ({
      state
    }, _) => {
      state.tabActive = state.tabActive + 1;
    },
    destroyVideo: async ({
      state
    }, _) => {
      console.log('testete', state.video.addEventListener);
      if (!state.video.addEventListener && !state.video.config) return;
      state.video.stopVideo();
      state.video.destroy();
      state.video.destroy(true);
      state.video.config = false;
    },
    playVideo: async ({
      state
    }, payload) => {
      if (state.config && payload === state.config.videoId) return;
      state.video.config = {
        controls: 1,
        autoplay: 1,
        loop: 1,
        videoId: false,
        height: '100%',
        width: '100%',
        playerVars: {
          autoplay: 1,
          controls: 0,
          autohide: 1,
          wmode: 'opaque',
          origin: `https://${window.location.host}`
        }
      };
      state.video.config = {};
      state.video.config.videoId = payload;
      try {
        state.video = youtube_player__WEBPACK_IMPORTED_MODULE_2___default()(`youtube-${payload}`, state.video.config);
        return Promise.resolve(true);
      } catch (error) {
        console.log('deu error');
        return Promise.resolve(true);
      }
    }
  },
  mutations: {},
  getters: {
    _getVersion: () => String((_core_config__WEBPACK_IMPORTED_MODULE_1___default().APP_VERSION)).toLocaleLowerCase().replace('v-', ''),
    getTabActive: state => state.tabActive
  },
  modules: {
    ..._modules__WEBPACK_IMPORTED_MODULE_0__["default"]
  }
}));

//# sourceURL=webpack://plataforma/./src/store/index.js?