__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);


// import moment from 'moment'
const state = {
  listaSolicitacoesCreditos: '',
  loader: false,
  filtros: false,
  iterationRev: false
};
const actions = {
  async solicitarCreditos({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('creditos/solicitar', {
      ...payload
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_SOLICITACOES_CREDITOS', result.data.data);
    return Promise.resolve(result.data);
  },
  async getSolicitacoesCreditos({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('creditos/solicitacoes-creditos', {
      params: {
        type: payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_SOLICITACOES_CREDITOS', result.data.data);
    return Promise.resolve(result.data);
  },
  async enviarComprovante(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('creditos/enviar-comprovante', payload);
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async cancelarSolicitacaoCredito(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('creditos/cancelar-solicitacao-credito', payload);
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async ativar(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('credits/activate', {
      ...payload
    });
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async iteracoesWebRevendas({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('creditos/iteracoes-revendas');
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_REVENDA_ITERACOES', result.data);
    return Promise.resolve(result.data);
  }
};
const mutations = {
  'SET_SOLICITACOES_CREDITOS'(state, payload) {
    state.listaSolicitacoesCreditos = payload;
  },
  'SET_REVENDA_ITERACOES'(state, {
    data
  }) {
    state.iterationRev = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(data) ? data : false;
  }
};
const getters = {
  listaSolicitacoesCreditos: state => state.listaSolicitacoesCreditos,
  iteracoesRevendas: state => state.iterationRev
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/creditos.js?