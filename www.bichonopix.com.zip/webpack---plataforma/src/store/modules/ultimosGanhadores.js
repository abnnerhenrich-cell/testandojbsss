__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

const state = {
  ganhadores: []
};
const actions = {
  async getLastWinners({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('top-winners', {
      ...payload
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_LAST_WINNERS', result.data);
    return Promise.resolve(result.data);
  }
};
const mutations = {
  'SET_LAST_WINNERS'(state, payload) {
    state.ganhadores = payload.data;
  }
};
const getters = {
  listGanhadores: state => state.ganhadores
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/ultimosGanhadores.js?