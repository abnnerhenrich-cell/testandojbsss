__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);




const state = {
  dados: {
    jsonFlags: {
      whatsappActive: ''
    }
  },
  oldDados: {
    jsonFlags: {
      resetPassword: ''
    }
  },
  estados: [],
  distritos: [],
  oldDadosPix: {},
  endereco: {}
};
const headerAuth = (userToken, password) => window.btoa(`${userToken}:${password}`);
const actions = {
  getUsuario: async ({
    commit
  }, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}cadastro/view`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    commit('ADD_USER', result.data.data);
    return Promise.resolve(result);
  },
  updatedPassword: async ({
    commit
  }, payload) => {
    const headers = {
      headers: {
        Authorization: 'Basic ' + headerAuth(payload.email, payload.senhaAtual)
      }
    };
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}senha/mudar-senha`, payload, headers);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  updatedDadosUsuario: async ({
    commit
  }, payload) => {
    // edita dados do usuario
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}cadastro`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  confirmarTelefone: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}solicitar-confirmacao-telefone`, {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  validarCodigo: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}/confirmar-telefone`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  getEstados: async ({
    commit
  }, payload) => {
    const result = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().URL_IBGE)}`);
    result.data = (0,lodash__WEBPACK_IMPORTED_MODULE_3__.orderBy)(result.data, ['sigla']);
    commit('SET_ESTADOS', result.data);
  },
  getDistrito: async ({
    commit
  }, payload) => {
    const result = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().URL_IBGE)}${payload}/distritos`);
    commit('SET_DISTRITOS', result.data);
  },
  getEndereco: async ({
    rootState,
    state
  }, payload) => {
    const result = await axios__WEBPACK_IMPORTED_MODULE_2___default().post('busca-cep', payload);
    if (result.data.data.erro) throw new Error('Endereço não encontrado');
    const dados = result.data.data;
    state.dados.city = dados.localidade;
    state.dados.state = dados.uf;
    state.dados.address = dados.logradouro;
    state.dados.neighborhood = dados.bairro;
    return Promise.resolve(dados);
  },
  gerarOTP: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}generate-otp`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  verificarOTP: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}verify-otp`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  cancelarOTP: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}cancel-otp`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  validarOTP: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}validate-otp`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  hasActiveOTP: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}has-active-otp`, {
      params: payload
    });
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  enviarCodWpp: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}send-wpp-code`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  }
};
const mutations = {
  'ADD_USER'(state, payload) {
    if (payload.pix && payload.pix.keyCode) {
      payload.pix.termoPix = true;
    } else {
      const pix = Object.assign({}, payload.pix);
      payload.pix = {
        keyCode: '',
        state: pix.state || '',
        bank: pix.bank || '',
        city: pix.city || '',
        termoPix: false
      };
    }
    // gambiarra para evitar alteracao de estado do msm objeto nos outros para evitar perca dos dados do pix
    const aaa = {};
    if (payload.pix) {
      Object.assign(aaa, payload.pix);
    }
    state.oldDadosPix = aaa;
    state.dados = (0,lodash__WEBPACK_IMPORTED_MODULE_3__.cloneDeep)(payload);
    const [birthYear, birthMonth, birthDay] = state.dados.birth.split('-');
    const [firstName, ...lastName] = state.dados.fullName.split(' ');
    state.dados.birthYear = birthYear;
    state.dados.birthMonth = birthMonth;
    state.dados.birthDay = birthDay;
    state.dados.firstName = firstName;
    state.dados.lastName = lastName.join(' ');
    state.dados.password = payload.jsonFlags.resetPassword ? payload.clearPassword : payload.password;
    state.oldDados = (0,lodash__WEBPACK_IMPORTED_MODULE_3__.assign)({}, payload);
  },
  'SET_ESTADOS'(state, payload) {
    state.estados = payload.map(v => ({
      label: v.sigla,
      value: v.sigla,
      id: v.sigla,
      text: v.sigla
    }));
  },
  'SET_DISTRITOS'(state, payload) {
    state.distritos = payload.map(v => ({
      label: v.nome,
      value: v.nome,
      id: v.nome,
      text: v.nome
    }));
  }
};
const getters = {
  listUser: state => state.dados,
  oldUser: state => state.oldDados
};
/* harmony default export */ __webpack_exports__["default"] = ({
  actions,
  mutations,
  state,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/perfil.js?