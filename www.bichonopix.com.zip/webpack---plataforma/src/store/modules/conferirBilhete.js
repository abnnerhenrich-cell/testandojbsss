__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

const state = {
  conferir: null
};
const actions = {
  async getWinnerGames({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('get-winner-games', {
      ...payload
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_WINNER_GAME', result.data);
    return Promise.resolve(result.data);
  }
};
const mutations = {
  'SET_WINNER_GAME'(state, payload) {
    state.conferir = payload;
  }
};
const getters = {};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/conferirBilhete.js?