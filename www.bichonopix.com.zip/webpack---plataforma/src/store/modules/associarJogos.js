__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_1__);


const state = {};
const actions = {
  jogosUsuarioWeb: async ({
    commit
  }, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}associated-web-user-games`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  }
};
const mutations = {};
const getters = {};
/* harmony default export */ __webpack_exports__["default"] = ({
  actions,
  mutations,
  state,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/associarJogos.js?