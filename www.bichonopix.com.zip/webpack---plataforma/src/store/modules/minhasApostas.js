__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

// import { filter, groupBy, map, orderBy, size } from 'lodash'
const state = {
  minhasApostas: [],
  minhasApostasIndexados: [],
  meusBonus: {},
  concursosBonus: [],
  resultado: null,
  resultadoInst: null,
  resultadoBonus: null,
  totalGames: 0,
  totalIndexados: 0,
  lastResultBonus: [],
  c: 0,
  loader: false
};
const actions = {
  async getMinhasApostas({
    commit
  }, payload) {
    commit('CHANGE_LOADER', true);
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('extrato/games', {
      ...payload
    });
    commit('CHANGE_LOADER', false);
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_MINHAS_APOSTAS', result.data);
    return Promise.resolve(result.data);
  },
  async getMinhasApostasIndexados({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('extrato/games-indexados', {
      ...payload,
      pageSize: 10
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_MINHAS_APOSTAS_INDEXADOS', result.data);
    return Promise.resolve(result.data);
  },
  async getResultados({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('resultados/prognosticos', {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_RESULTADO', result.data.data.result);
    return Promise.resolve(result.data);
  },
  async getResultadosInst({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('resultados/prognosticos-inst', {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_RESULTADO_INST', result.data.data.result);
    return Promise.resolve(result.data);
  },
  async obterConcursosBonus({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('extrato/concursos');
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_LISTA_CONCURSOS_BONUS', result.data);
    return Promise.resolve(result.data);
  },
  async getMeusBonus({
    commit
  }, payload) {
    commit('RESET_LISTA_BONUS');
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('extrato/cupons', {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_LISTA_BONUS', result.data);
    return Promise.resolve(result.data);
  },
  async limparListaBonus({
    commit
  }, payload) {
    commit('RESET_LISTA_BONUS');
  },
  async getResultadosBonus({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('resultados/bonus', {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_RESULTADO_BONUS', result.data.data.result);
    return Promise.resolve(result.data);
  },
  async getUltimoResultadosBonus({
    commit
  }, payload) {
    // pega o ultimo resultado do bonus
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('resultados/bonus', {
      params: {
        ...payload
      }
    });
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_ULTIMO_RESULTADO_BONUS', result.data.data.result);
    return Promise.resolve(result.data.data.result);
  },
  async resetResultados({
    commit
  }) {
    commit('RESET_RESULTADO');
  },
  async limparResultadosBonus({
    commit
  }) {
    commit('RESET_RESULTADO_BONUS');
  }
};
const mutations = {
  'SET_MINHAS_APOSTAS'(state, payload) {
    state.minhasApostas = payload.data;
    state.totalGames = payload.total;
  },
  'SET_MINHAS_APOSTAS_INDEXADOS'(state, payload) {
    state.minhasApostasIndexados = payload.data;
    state.totalIndexados = payload.total || 1;
  },
  'SET_LISTA_CONCURSOS_BONUS'(state, payload) {
    state.concursosBonus = payload.data;
  },
  'SET_LISTA_BONUS'(state, payload) {
    state.meusBonus = payload.data;
    state.totalMeusBonus = payload.total || 1;
  },
  'CHANGE_LOADER'(state, payload) {
    state.loader = payload;
  },
  'SET_RESULTADO'(state, payload) {
    state.resultado = payload;
  },
  'SET_RESULTADO_INST'(state, payload) {
    state.resultadoInst = payload;
  },
  'RESET_RESULTADO'(state, payload) {
    state.resultado = null;
    state.resultadoInst = null;
  },
  'RESET_LISTA_BONUS'(state, payload) {
    state.meusBonus = {};
    state.totalMeusBonus = 0;
  },
  'SET_RESULTADO_BONUS'(state, payload) {
    state.resultadoBonus = payload;
  },
  'SET_ULTIMO_RESULTADO_BONUS'(state, payload) {
    state.lastResultBonus = payload;
  },
  'RESET_RESULTADO_BONUS'(state, payload) {
    state.resultadoBonus = null;
  }
};
const getters = {
  minhasApostas: state => state.minhasApostas,
  minhasApostasPage: state => (page, total) => {
    const dados = state.minhasApostas;
    const paginacao = dados.slice(page * total - total, page * total);
    return paginacao;
  },
  minhasApostasIndexados: state => state.minhasApostasIndexados,
  totalGames: state => state.totalGames,
  totalIndexados: state => state.totalIndexados,
  loader: state => state.loader,
  resultado: state => state.resultado,
  resultadoInst: state => state.resultadoInst,
  meusBonus: state => state.meusBonus,
  totalMeusBonus: state => state.totalMeusBonus,
  resultadoBonus: state => state.resultadoBonus,
  concursosBonus: state => state.concursosBonus,
  ultimoResultadoBonus: state => state.lastResultBonus
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/minhasApostas.js?