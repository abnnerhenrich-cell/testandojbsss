__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

// import moment from 'moment'
const state = {
  resultado: false,
  loader: false,
  filtros: false
};
const actions = {
  async getResultados({
    commit,
    state
  }, payload) {
    state.resultado = false;
    // let result

    // if (!payload.dtEnd || payload.dtEnd === moment().format('YYYY-MM-DD')) {
    // resultado aberto
    // payload.dtEnd = moment().format('YYYY-MM-DD')

    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('resultados/prognosticos-aberto', {
      params: {
        ...payload
      }
    });
    // } else { 
    // precisa estar logado
    // result = await http.get('resultados/prognosticos', { params: { ...payload } })
    // }

    if (!result.data.success) throw Error(result.data.message);
    commit('SET_RESULTADO', result.data);
    return Promise.resolve(result.data);
  },
  // loader resultado
  async setLoader({
    commit,
    state
  }, payload) {
    state.loader = payload;
  },
  async setFiltros({
    commit,
    state
  }, payload) {
    state.filtros = payload;
  },
  async resetarResultados({
    commit
  }) {
    commit('LIMPAR_RESULTADO', false);
  }
};
const mutations = {
  'SET_RESULTADO'(state, payload) {
    state.resultado = payload.data.result || false;
  },
  'LIMPAR_RESULTADO'(state, payload) {
    state.resultado = payload;
  }
};
const getters = {
  listResultados: state => state.resultado,
  getLoader: state => state.loader,
  getFiltro: state => state.filtros
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/resultados.js?