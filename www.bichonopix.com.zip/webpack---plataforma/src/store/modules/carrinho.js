__webpack_require__.r(__webpack_exports__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_4__);





const state = {
  carrinho: [],
  comprovante: [],
  resultadoInsta: []
};
const calculoValorPalpite = payload => {
  const {
    total,
    palpites
  } = payload;
  const premios = sizePremios(+payload.formatPremios.id, payload.modalidade);
  const calculo = parseFloat(total / premios / (0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(palpites)).toFixed(2);
  return calculo;
};

// eslint-disable-next-line
const sizePremios = (dados, modalidade) => {
  if (modalidade.MULT_PREMIOS_WEB === 1) return 1;
  if (dados === 12) return 2;
  if (dados === 13) return 3;
  if (dados === 14) return 4;
  if (dados === 15) return 5;
  return (0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(dados) || 1;
};
const actions = {
  addShop: async ({
    state
  }, payload) => {
    const dados = Object.assign({}, payload);
    state.carrinho.push(dados);
    _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].set('user-shop', state.carrinho);
  },
  setSessionCart: async ({
    state
  }, payload) => {
    const shop = _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].get('user-shop');
    if (!shop) {
      state.carrinho = [];
      return Promise.resolve(true);
    }
    state.carrinho = shop;
  },
  deleteShop: async ({
    state
  }, payload) => {
    const teste = [...state.carrinho];
    state.carrinho = [];
    setTimeout(() => {
      state.carrinho = teste.filter((v, k) => k !== payload);
      _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].set('user-shop', state.carrinho);
    });
  },
  deletePalpiteShop: async ({
    state
  }, payload) => {
    const dados = Object.assign(state.carrinho);
    if (dados[payload.indice]) {
      const palpites = dados[payload.indice].palpites;
      dados[payload.indice].palpites = palpites.filter((v, k) => k !== payload.deleted);
    }
    state.carrinho[payload.indice].palpites = dados[payload.indice].palpites;
    // state.carrinho = dados
    _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].set('user-shop', state.carrinho);
    return Promise.resolve(state.carrinho[payload.indice].total);
  },
  updateValue: async ({
    state
  }, payload) => {
    const item = state.carrinho.filter((v, k) => k === payload.indice)[0];
    if (!item) {
      return Promise.resolve(true);
    }

    /* calculo valor carrinho */
    item.palpiteValue = payload.value;
    // const loterias = size(item.loterias.loteria)
    // const palpites = size(item.palpites)
    // const premios = sizePremios(item.formatPremios.id, item.modalidade, item.formatPremios.value)
    const total = payload.value;
    item.total = total;
    item.valorPorPalpite = calculoValorPalpite(state.carrinho[payload.indice]);
    item.valorPalpite = payload.value;
    state.carrinho[payload.indice] = item;
    _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].set('user-shop', state.carrinho);
  },
  finalizarAposta: async ({
    commit,
    rootGetters
  }, payload) => {
    const itens = state.carrinho;
    const results = [];
    const defaults = {
      D: moment__WEBPACK_IMPORTED_MODULE_1___default()().format('YYMMDD'),
      // data aposta
      H: '',
      T: rootGetters['carrinho/listCarrinho'].total,
      U: itens[0].userId,
      B: [],
      palpiteDigitado: itens[0].palpiteValue
      // possitions: session.get('gps')
    };

    if (payload.isBonus) defaults.type = 'bonus';
    for (const payload of itens) {
      const formatLoterias = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)([payload.formatLoterias], v => {
        const {
          data,
          modalidade,
          palpites,
          formatPremios,
          valorPalpite,
          productId
        } = payload;
        const validate = [!data, !modalidade, !palpites, !formatPremios, !valorPalpite, !productId];
        if (validate.indexOf(true) !== -1) {
          console.log('validate', validate);
          throw new Error('Dados invalidos para aposta');
        }
        if (modalidade.IN_PREMIO_SAO_DEZENAS === 1) {
          const qtdPalpite = palpites[0].val.split('-').length;
          formatPremios.id = modalidade.CD_PREM.indexOf(qtdPalpite) !== -1 ? qtdPalpite : false;
          if (!formatPremios.id) throw new Error(`Prêmios invalido para tamanho do palpite ${qtdPalpite}`);
        }
        return {
          data,
          idLoteria: v.ID_LOT,
          modalidade,
          palpites: [palpites],
          premios: [formatPremios.id],
          valorPalpite,
          produtoId: productId
        };
      });
      const _bilhetes = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(formatLoterias, (it, k) => {
        return {
          Produto: it.produtoId,
          A: moment__WEBPACK_IMPORTED_MODULE_1___default()(it.data).format('YYMMDD'),
          // data aposta
          L: [it.idLoteria],
          // loteria
          R: it.repeticao || 1,
          // numero de repeticoes
          P: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(it.palpites, o => {
            // palpites
            return {
              M: it.modalidade.ID_MODAL,
              // modalidades
              R: it.repeticao || 1,
              // numero de repeticoes
              E: it.premios,
              // premios
              J: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.flatten)((value => {
                // palpites do jogo
                if (it.modalidade.IN_PALP_ORD === 1) return (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(value, v => (0,lodash__WEBPACK_IMPORTED_MODULE_0__.sortBy)(String(v.val).split('-')).join('').replace(/,/g, ''));
                return (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(value, v => String(v.val).replace(/-/g, '').replace(/,/g, ''));
              })(o)),
              V: it.valorPalpite // valor por palpite
            };
          })
        };
      });

      defaults.B.push(_bilhetes[0]);
    }
    if (payload.saveHistory) {
      const historyCarrinho = await _core_http__WEBPACK_IMPORTED_MODULE_2__["default"].post((_core_config__WEBPACK_IMPORTED_MODULE_4___default().SAVE), defaults);
      return Promise.resolve(historyCarrinho.data);
    }
    const aposta = await _core_http__WEBPACK_IMPORTED_MODULE_2__["default"].post((_core_config__WEBPACK_IMPORTED_MODULE_4___default().START_GAME), defaults);
    if (!aposta.data.success) throw new Error(aposta.data.message);
    results.push(aposta.data.data);
    _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].remove('user-shop');
    // commit('ADD_COMPROVANTE', { response: results, request: itens })

    return Promise.resolve(results);
  },
  finalizarApostaRaspadinha: async ({
    commit
  }, payload) => {
    payload.date = moment__WEBPACK_IMPORTED_MODULE_1___default()().format('YYMMDD');
    const aposta = await _core_http__WEBPACK_IMPORTED_MODULE_2__["default"].post('scratch/buy', payload);
    if (!aposta.data.success) throw new Error(aposta.data.message);
    commit('ADD_COMPROVANTE_RASPADINHA', {
      response: aposta.data.data,
      request: payload
    });
    return Promise.resolve(aposta);
  },
  clearCarrinho: async ({
    commit,
    state
  }, _) => {
    state.carrinho = [];
    _core_service_session__WEBPACK_IMPORTED_MODULE_3__["default"].remove('user-shop');
  },
  clearComprovante: async ({
    commit,
    state
  }, _) => {
    state.comprovante = [];
  },
  addParseJson: async ({
    commit
  }, _) => {
    const request = await _core_http__WEBPACK_IMPORTED_MODULE_2__["default"].post((_core_config__WEBPACK_IMPORTED_MODULE_4___default().SAVE), state.carrinho);
    if (!request.data.success) throw new Error('Dados do carrinho e enviados inválidos.!');
  }
};
const mutations = {
  'ADD_COMPROVANTE'(state, payload) {
    state.comprovante = payload;
    console.log(JSON.stringify(payload));
  },
  'ADD_COMPROVANTE_RASPADINHA'(state, payload) {
    state.comprovante = payload;
    console.log(JSON.stringify(payload));
  }
};
const getters = {
  listCarrinho: state => {
    const updateValues = state.carrinho[0] ? state.carrinho.map(v => ({
      ...v,
      palpiteValue: v.palpiteValue * 100,
      valorPorPalpite: calculoValorPalpite(v),
      qtdPalpites: v.palpites.length
    })) : [];
    return {
      qtd: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(state.carrinho),
      list: updateValues,
      total: updateValues.reduce((acc, item) => item.total + acc, 0)
    };
  },
  getComprovante: state => {
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(state.comprovante)) return false;
    const req = state.comprovante.request;
    const res = state.comprovante.response.responseJson;
    const format = {
      bilheteUnico: 'GYN.' + res.I,
      // id Bilhete Unico
      dataHora: moment__WEBPACK_IMPORTED_MODULE_1___default()(res.A, 'YYMMDDHHmmss').format('DD/MM/YYYY [-] HH:mm'),
      games: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(res.B, v => {
        return {
          dataAposta: moment__WEBPACK_IMPORTED_MODULE_1___default()(v.D, 'YYMMDDHHmmss').format('DD/MM/YYYY HH:mm:ss'),
          // vendo ws
          dataApostaFormat: moment__WEBPACK_IMPORTED_MODULE_1___default()(v.D, 'YYMMDDHHmmss').format('DD/MM/YYYY'),
          loterias: req.formatLoterias,
          modalidade: req.modalidade,
          premios: req.formatPremios,
          palpites: req.formatPalpites,
          total: req.total,
          valorPalpite: req.valorPalpite
        };
      }),
      gameBonus: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(state.comprovante.response.gameBonus) ? state.comprovante.response.gameBonus : {
        format: false
      },
      resultadoInsta: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(state.comprovante.response.instaRes) ? state.comprovante.response.instaRes : false
    };
    return format;
  },
  formatCarrinhoRequest: state => {
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_0__.size)(state.carrinho)) return false;
    const group = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.groupBy)(state.carrinho, v => `${moment__WEBPACK_IMPORTED_MODULE_1___default()(v.data).format('DD/MM/YYYY')}#${v.modalidade.ID_MODAL}#${v.total}`);
    return group;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/carrinho.js?