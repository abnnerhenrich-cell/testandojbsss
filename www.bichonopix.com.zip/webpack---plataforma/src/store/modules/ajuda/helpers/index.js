__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   tabelaGrupos: function() { return /* binding */ tabelaGrupos; }
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);

const tabelaGrupos = () => {
  const bichos = ['Avestruz', 'Águia', 'Burro', 'Borboleta', 'Cachorro', 'Cabra', 'Carneiro', 'Camelo', 'Cobra', 'Coelho', 'Cavalo', 'Elefante', 'Galo', 'Gato', 'Jacaré', 'Leão', 'Macaco', 'Porco', 'Pavão', 'Peru', 'Touro', 'Tigre', 'Urso', 'Veado', 'Vaca'];
  const items = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.range)(1, 26);
  let count = 1;
  const format = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.map)(items, (v, k) => {
    let dezenas;
    let isDezenas;
    if (k === 0) {
      dezenas = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.range)(count, v + 4);
      isDezenas = `${String(dezenas[0]).padStart(2, '0')} - ${String((0,lodash__WEBPACK_IMPORTED_MODULE_0__.last)(dezenas)).padStart(2, '0')}`;
    }
    if (k > 0) {
      count = count + 4;
      dezenas = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.range)(count, count + 4);
      isDezenas = `${String(dezenas[0]).padStart(2, '0')} - ${String((0,lodash__WEBPACK_IMPORTED_MODULE_0__.last)(dezenas)).padStart(2, '0')}`;
    }
    return {
      dezenas: isDezenas,
      bicho: bichos[v - 1],
      index: String(v).padStart(2, '0')
    };
  });
  return format;
};

//# sourceURL=webpack://plataforma/./src/store/modules/ajuda/helpers/index.js?