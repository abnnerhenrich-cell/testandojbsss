__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_service_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/service/session */ "./src/core/service/session.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);



const state = {
  user: {},
  config: null,
  token: false,
  modal: null,
  questions: false,
  configPixFinancial: false,
  configBonusWeb: false,
  dadosWhatsapp: []
};
const headerAuth = (userToken, password) => window.btoa(`${userToken}:${password}`);
const actions = {
  async userLogin({
    commit
  }, payload) {
    const headers = {
      headers: {
        authorization: 'Basic ' + headerAuth(payload.name, payload.password)
      }
    };
    const data = {
      lang: payload.lang || 'pt-br',
      tipo: 'cpf',
      recaptcha: payload.recaptcha,
      otptoken: payload.otptoken
    };
    const firebaseToken = _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].get('firebase-token');
    const messageChannelId = _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].get('message-channel-id');
    if (firebaseToken) data.firebaseToken = firebaseToken;
    if (messageChannelId) data.messageChannelId = messageChannelId;
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('autenticar', data, headers);
    if (!result.data.success) throw new Error(result.data.message);
    commit('LOGIN_SUCCESS', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async getDadosUsuario({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('regiao');
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_CONFIG', result.data.data);
    return Promise.resolve(result.data);
  },
  async recuperarSenha(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('recuperar', payload);
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async alterarSenha(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('senha/reset-password', payload);
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async alterarSenhaOtp(_, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('senha/reset-password-otp', payload);
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result.data);
  },
  async addPositions(_, payload) {
    if (payload && payload.latitude) await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('add-positions', payload);
  },
  async openModal({
    commit
  }, payload) {
    commit('OPEN_MODAL', payload);
    return Promise.resolve(true);
  },
  async logout() {
    _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].remove('auth-token');
    state.token = false;
    state.config = null;
    state.user = {};
    window.location = '/';
  },
  async suporteWhatsapp({
    state
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('suporte-watsapp', payload);
    if (!result.data.success) throw Error(result.data.message);
    state.dadosWhatsapp = result.data.data;
    return Promise.resolve(result.data);
  },
  async refreshToken({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('refresh-token-web');
    commit('LOGIN_SUCCESS_REFRESH', result.data.data);
    return Promise.resolve(result);
  },
  async checkJWT() {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('check-jwt');
    if (!result.data.success) throw Error(result.data.message);
    return Promise.resolve(result);
  },
  startIntervalCheckJWT: ({
    commit
  }) => {
    commit('ADD_INTERVAL_JWT');
  }
};
const mutations = {
  'OPEN_MODAL'(state, payload) {
    state.modal = payload;
  },
  'LOGIN_SUCCESS'(state, payload) {
    _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].set('auth-token', payload.token);
    state.token = true;
  },
  'LOGIN_SUCCESS_REFRESH'(state, payload) {
    _core_service_session__WEBPACK_IMPORTED_MODULE_1__["default"].set('auth-token', payload.token);
    state.token = true;
  },
  'ADD_INTERVAL_JWT'(state, payload) {
    state.intervalCheckJWT = setInterval(() => {
      console.log('teste');
      _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('/check-jwt');
    }, 1000 * 60 * 5);
  },
  'SET_CONFIG'(state, payload) {
    state.config = payload.data;
    state.user = {
      ...payload.user,
      id: payload.id
    };
    state.token = true;
    state.configPixFinancial = payload.configPixFinancial;
    state.configBonusWeb = payload.configBonusWeb;
    // resposta de questionario ativadas e usuario ainda nao respondeu formulario
    const isRespondeu = payload.user.jsonFlags.answeredQuestion === undefined;
    state.questions = payload.globalQuestions === true && isRespondeu;
    state.user.revenda = state.user.jsonFlags && state.user.jsonFlags.revenda && state.user.jsonFlags.revenda.text ? state.user.jsonFlags.revenda.text : '';
    state.user.phoneRevenda = state.user.jsonFlags && state.user.jsonFlags.revenda && state.user.jsonFlags.revenda.phone ? state.user.jsonFlags.revenda.phone : '';
    state.user.limitPremioViaPix = state.user.jsonFlags && state.user.jsonFlags.limitPremioViaPix ? state.user.jsonFlags.limitPremioViaPix : 700;
  }
};
const getters = {
  globalConfigProdutos: state => (0,lodash__WEBPACK_IMPORTED_MODULE_2__.size)(state.config) ? state.config.CONFIG : null,
  getToken: () => state.token,
  isActiveQuestions: () => state.questions,
  getUser: state => state.user,
  loginOpenModal: state => state.modal,
  auth: (state, getters) => {
    const user = state.user;
    if (user.id && state.token && !user.jsonFlags.resetPassword) return true;
    return false;
  },
  isResetPassword: (state, getters) => {
    const user = state.user;
    if (user.id && state.token && user.jsonFlags.resetPassword) return true;
    return false;
  },
  isResgatePremiosPix: state => state.user.jsonFlags && state.user.jsonFlags.pixResgatePremiosVisible === true,
  urlRepositorioAWS: state => {
    const {
      CONFIG: {
        URL_REPSITORIO_AWS
      }
    } = state.config;
    if (URL_REPSITORIO_AWS) return URL_REPSITORIO_AWS;
    return '';
  },
  telefoneSuporte: state => state.dadosWhatsapp || '5562998386563',
  configPixFinancial: state => state.configPixFinancial,
  configBonusWeb: state => state.configBonusWeb
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/loginCadastro.js?