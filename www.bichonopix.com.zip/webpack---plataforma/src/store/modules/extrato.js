__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);

// eslint-disable-next-line

const state = {
  extrato: [],
  total: 0,
  loader: false,
  extratoComprovante: false
};
const actions = {
  async getExtrato({
    commit
  }, payload) {
    commit('CHANGE_LOADER', true);
    // const result = await http.post('extrato/credito', payload)
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('extrato/credito', payload);
    commit('CHANGE_LOADER', false);
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_MINHAS_APOSTAS', result.data);
    return Promise.resolve(result.data);
  },
  getBilheteTransmissions: async ({
    commit
  }, payload) => {
    const aposta = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('extrato/games', payload);
    if (!aposta.data.success) throw new Error(aposta.data.message);
    commit('ADD_COMPROVANTE_EXTRATO', aposta.data.data);
    return Promise.resolve(aposta);
  },
  clearExtrato: async ({
    state
  }, _) => {
    state.extratoComprovante = false;
    return Promise.resolve(true);
  }
};
const mutations = {
  'SET_MINHAS_APOSTAS'(state, payload) {
    state.extrato = payload.data;
    state.total = payload.total;
  },
  'ADD_COMPROVANTE_EXTRATO'(state, payload) {
    state.extratoComprovante = payload;
  },
  'CHANGE_LOADER'(state, payload) {
    state.loader = payload;
  }
};
const getters = {
  extrato: state => state.extrato,
  extratoPage: state => (page, total) => {
    const dados = state.extrato;
    const paginacao = dados.slice(page * total - total, page * total);
    return paginacao;
  },
  total: state => state.total,
  loader: state => state.loader,
  extratoComprovante: state => {
    if (!state.extratoComprovante) return false;
    const obj = state.extratoComprovante;
    const dados = {
      dataHora: obj.dataHora,
      resultadoInsta: false,
      gameBonus: {
        format: false
      },
      total: obj.total,
      games: obj.games
      // games: [{
      //   dataApostaFormat: obj.dataApostaFormat,
      //   loterias: obj.dados.formatLoterias,
      //   modalidade: obj.dados.modalidade,
      //   palpites: obj.dados.formatPalpites,
      //   palpiteArray: obj.dados.palpites,
      //   premios: obj.dados.formatPremios,
      //   premiosArray: obj.dados.premios,
      //   total: obj.dados.total,
      //   resultadoInsta: false,
      //   produtoId: obj.dados.produtoId
      // }]
    };

    return dados;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/extrato.js?