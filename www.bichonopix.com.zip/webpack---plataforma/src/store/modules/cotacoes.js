__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

const state = {
  cotacoes: []
};
const actions = {
  async getCotacoes({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('cotacoes');
    if (!result.data.success) throw Error(result.data.message);
    commit('ADD_COTACAO', result.data.data);
    return Promise.resolve(result.data.data);
  }
};
const mutations = {
  'ADD_COTACAO'(state, payload) {
    state.cotacoes = payload;
  }
};
const getters = {
  listCotacoes: state => {
    return state.cotacoes;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/cotacoes.js?