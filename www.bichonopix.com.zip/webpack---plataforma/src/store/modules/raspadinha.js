__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

const state = {
  raspadinhas: [],
  animacao: false,
  winners: false
};
const actions = {
  async getRaspadinhas({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('raspadinhas');
    if (!result.data.success) throw new Error(result.data.message);
    commit('SET_DADOS', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async confirmationWinners({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('scratch/confirmation', payload);
    if (!result.data.success) throw new Error(result.data.message);
    commit('SET_DADOS_WINNERS', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async startAnimacaoRaspadinha({
    commit
  }, payload = false) {
    commit('SET_START_ANIMACAO', payload);
    return Promise.resolve(true);
  },
  async clearRaspadinha({
    state
  }, payload) {
    state.winners = false;
    state.raspadinhas = false;
  }
};
const mutations = {
  'SET_DADOS'(state, payload) {
    state.raspadinhas = payload;
  },
  'SET_START_ANIMACAO'(state, payload) {
    state.animacao = payload;
  },
  'SET_DADOS_WINNERS'(state, payload) {
    state.winners = payload;
  }
};
const getters = {
  listRaspadinhas: state => state.raspadinhas,
  getWinnerRaspadinha: state => state.winers
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/raspadinha.js?