__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");

const state = {
  saldos: {
    saldo: 0,
    credito: 0,
    premio: 0,
    bonus: 0
  }
};
const actions = {
  async getSaldos({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('saldos');
    if (!result.data.success) throw new Error(result.data.message);
    commit('SET_SALDOS', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async setSaldos({
    commit
  }, payload) {
    commit('SET_SALVO_LOGIN', payload);
    return Promise.resolve(payload);
  }
};
const mutations = {
  'SET_SALVOS_LOGIN'(state, payload) {
    state.saldos = payload;
  },
  'SET_SALDOS'(state, payload) {
    state.saldos = payload;
  }
};
const getters = {
  listSaldos(state) {
    return state.saldos;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/saldos.js?