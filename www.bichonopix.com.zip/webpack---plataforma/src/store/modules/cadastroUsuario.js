__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_1__);


const state = {
  dadosCPF: {}
};
const actions = {
  cadastrar: async ({
    commit
  }, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}cadastro/user-create`, payload);
    if (!result.data.success) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  verificaCPF: async ({
    commit
  }, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('cadastro/busca-dados-cpf', payload);
    if (!result.data.success) throw new Error(result.data.message);
    commit('SET_DADOS_CPF', result.data.data);
    return Promise.resolve(result.data.data);
  }
};
const mutations = {
  'SET_DADOS_CPF'(state, result) {
    state.dadosCPF = result;
  }
};
const getters = {
  getDadosCPF: state => {
    return state.dadosCPF;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  actions,
  mutations,
  state,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/cadastroUsuario.js?