__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/core/config */ "./src/core/config.js");
/* harmony import */ var _core_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_config__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);



const state = {
  bonus: {
    id: '',
    status: '',
    bonusValue: '',
    rollOverValue: '',
    rollOverValueTotal: '',
    formatExpirationDate: '',
    rollOverValueRestante: '',
    webBonuses: {
      minRollOver: '',
      description: ''
    }
  }
};
const actions = {
  getBonus: async ({
    commit
  }) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}bonus-web`);
    if (!result.data) throw new Error(result.data.message);
    commit('ADD_BONUS', result.data);
    return Promise.resolve(result);
  },
  cancelarBonus: async (_, payload) => {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${(_core_config__WEBPACK_IMPORTED_MODULE_1___default().API)}cancel-bonus`, payload);
    if (!result.data) throw new Error(result.data.message);
    return Promise.resolve(result);
  },
  limparBonus: ({
    commit
  }) => {
    commit('LIMPAR_BONUS');
  }
};
const mutations = {
  'ADD_BONUS'(state, payload) {
    state.bonus = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.cloneDeep)(payload.data);
  },
  'LIMPAR_BONUS'(state) {
    state.bonus = {
      id: '',
      status: '',
      bonusValue: '',
      rollOverValue: '',
      rollOverValueTotal: '',
      formatExpirationDate: '',
      rollOverValueRestante: '',
      webBonuses: {
        minRollOver: '',
        description: ''
      }
    };
  }
};
const getters = {
  listBonus: state => state.bonus
};
/* harmony default export */ __webpack_exports__["default"] = ({
  actions,
  mutations,
  state,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/bonus.js?