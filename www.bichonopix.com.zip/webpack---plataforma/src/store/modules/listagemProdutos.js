__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/core/http */ "./src/core/http.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_filters_numeral__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/core/filters/numeral */ "./src/core/filters/numeral.js");



const state = {
  produtos: null,
  total: 0,
  select: null,
  loterias: null,
  modalidades: null,
  permutacoes: []
};
const formatPremioModalidade = (v, {
  IN_PREMIO_SAO_DEZENAS
}) => {
  if (IN_PREMIO_SAO_DEZENAS) {
    return {
      text: v,
      id: v
    };
  }
  let result = '';
  const text = String(v).split('');
  if ((0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(text) !== 1) result = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(text, it => `${it}º`).join('-');
  if ((0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(text) === 1) result = `${text[0]}º`;
  return {
    text: result,
    id: v,
    value: 0
  };
};
const formatPremio = modalidade => {
  const dados = modalidade;
  if ((0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(dados) && dados.ID_MODAL === undefined) {
    const itens = modalidade.CD_PREM.map(v => formatPremioModalidade(v, dados));
    return itens;
  }

  // se dezenas for premio formata pelo CD_PREM
  if (dados.IN_PREMIO_SAO_DEZENAS) {
    console.log(dados.IN_PREMIO_SAO_DEZENAS);
    const dezenas = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(dados.CD_PREM, it => ({
      text: it,
      id: it
    }));
    return dezenas;
  }
  const itens = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(dados.CD_PREM, v => formatPremioModalidade(v, dados));
  return itens;
};
const actions = {
  async getProdutos({
    commit
  }) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].post('lista-produtos');
    if (!result.data.success) throw Error(result.data.message);
    commit('SET_LIST_PRODUTOS', result.data);
    return Promise.resolve(result.data);
  },
  async setSelectProdutoAtual({
    commit
  }, payload) {
    if (state.select === payload) {
      return Promise.resolve(false);
    }
    commit('SET_PRODUTO_ATUAL', payload === 'QUINZAO' ? '15ZAO' : payload);
    return Promise.resolve(payload);
  },
  async getLoteriasProdutos({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('lista-produto-loterias', {
      params: {
        id: payload === 'QUINZAO' ? '15ZAO' : payload
      }
    });
    if (!result.data.success) throw result.data.message;
    commit('SET_LOTERIAS_ATUAL', result.data.data);
    return Promise.resolve(payload);
  },
  async getModalitiesCategories({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('lista-produto-modalidades', {
      params: {
        id: payload.id === 'QUINZAO' ? '15ZAO' : payload.id
      }
    });
    if (!result.data.success) throw result.data.message;
    commit('SET_MODALIDADES_ATUAL', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async obterPermutacao({
    commit
  }, payload) {
    const result = await _core_http__WEBPACK_IMPORTED_MODULE_0__["default"].get('generate-permutations', {
      params: payload
    });
    if (!result.data.success) throw result.data.message;
    commit('SET_PERMUTACOES', result.data.data);
    return Promise.resolve(result.data.data);
  },
  async limparPermutacao({
    commit
  }, payload) {
    commit('LIMPAR_PERMUTACOES');
  },
  validateSelectedProduct({
    getters,
    state
  }, payload) {
    console.log(state.select);
    payload = payload === '15ZAO' ? 'QUINZAO' : state.select;
    return Promise.resolve(payload === getters.getSelect);
  }
};
const mutations = {
  'SET_LIST_PRODUTOS'(state, payload) {
    state.produtos = payload.data;
    state.total = payload.total;
  },
  'SET_PRODUTO_ATUAL'(state, payload) {
    state.select = payload;
  },
  'SET_LOTERIAS_ATUAL'(state, payload) {
    state.loterias = payload;
  },
  'SET_MODALIDADES_ATUAL'(state, payload) {
    state.modalidades = payload;
  },
  'SET_PERMUTACOES'(state, payload) {
    state.permutacoes = payload && payload.map(it => it.guessespermutations);
  },
  'LIMPAR_PERMUTACOES'(state) {
    state.permutacoes = [];
  }
};
const getters = {
  listProdutos: state => (0,lodash__WEBPACK_IMPORTED_MODULE_1__.orderBy)(state.produtos, 'config.NR_ORD_WEB', 'asc').filter(it => it.config.IN_JOGAVEL === undefined || it.config.IN_JOGAVEL),
  listProdutosResultado: state => (0,lodash__WEBPACK_IMPORTED_MODULE_1__.orderBy)(state.produtos, 'config.NR_ORD_WEB', 'asc').filter(it => it.config.IN_JOGAVEL === undefined || !it.config.IN_JOGAVEL),
  getSelect: state => state.select === '15ZAO' ? 'QUINZAO' : state.select,
  produtoSelecionado: state => {
    if (!state.select) return {
      config: {}
    };
    return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.filter)(state.produtos, v => v.id === state.select)[0] || false;
  },
  getProdActive: state => state.select,
  listLoterias: state => state.loterias,
  // para resultado
  getModalidades: state => state.modalidades,
  // modalidades de um produto

  // Agrupa pelo numero da coluna que esta configurado no json de cada modalidade
  modalidadesAgrupadas: state => {
    const modalidades = state.modalidades;
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(modalidades)) return false;
    const formatLabel = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)((0,lodash__WEBPACK_IMPORTED_MODULE_1__.orderBy)(modalidades, ['NR_ORD_NO_PROD'], ['asc']), v => {
      // formata label das modalidades
      if (!v) return [];
      const label = String(v.DS_MODAL).split(' ');
      const labelFormat = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(label, (v, k) => k !== 1 ? String(v[0]).toUpperCase() : v[0]).join('');
      v.LABEL = labelFormat;
      if (labelFormat === 'MeC') v.LABEL = 'MC';
      if (labelFormat === 'MeCI') v.LABEL = 'MeC';
      if (labelFormat === 'DdD') v.LABEL = 'DD';
      if (labelFormat === 'DDF') v.LABEL = 'DF';
      if (labelFormat === 'TdD') v.LABEL = 'TD';
      if (labelFormat === 'TDC') v.LABEL = 'TC';
      if (labelFormat === 'TDC') v.LABEL = 'TC';
      if (labelFormat === 'DdG') v.LABEL = 'D';
      if (labelFormat === 'TdG') v.LABEL = 'TG';
      if (labelFormat === 'TGC') v.LABEL = 'TC';
      if (labelFormat === 'QdG') v.LABEL = 'Q';
      if (labelFormat === 'S5A7') v.LABEL = '7';
      if (labelFormat === 'S5') v.LABEL = '5';
      if (labelFormat === 'S5A6') v.LABEL = '6';
      if (labelFormat === 'S5A8') v.LABEL = '8';
      if (v.DS_MODAL.indexOf('-') === -1) {
        let cotacoes;
        if ((0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(v.AR_COTACAO)) {
          cotacoes = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(v.AR_COTACAO, item => ({
            ...item,
            VL_PREMIO: parseFloat(item.VL_PREMIO)
          }));
        }
        const cotacao = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(cotacoes) ? (0,lodash__WEBPACK_IMPORTED_MODULE_1__.maxBy)(cotacoes, 'VL_PREMIO') : {
          VL_PREMIO: 0
        };
        v.DS_MODAL = cotacao && cotacao.VL_PREMIO ? `${v.DS_MODAL}` : v.DS_MODAL;
        v.COTACAO = cotacao.VL_PREMIO;
        v.DS_COTACAO = (0,_core_filters_numeral__WEBPACK_IMPORTED_MODULE_2__["default"])(cotacao.VL_PREMIO) + 'X';
      }
      const prizesFormat = formatPremio(v);
      return {
        ...v,
        id: v.ID_MODAL,
        value: v,
        sig: v.DS_SIG,
        label: v.DS_MODAL,
        modalityPrizeFormat: prizesFormat
      };
    });
    return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.groupBy)(formatLabel, v => v.COL_GROUP);
  },
  modalidadesInLine: state => {
    const modalidades = state.modalidades;
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(modalidades)) return false;
    const formatLabel = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)((0,lodash__WEBPACK_IMPORTED_MODULE_1__.orderBy)(modalidades, ['NR_ORD_NO_PROD'], ['asc']), v => {
      // formata label das modalidades
      if (!v) return [];
      const label = String(v.DS_MODAL).split(' ');
      const labelFormat = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.map)(label, (v, k) => k !== 1 ? String(v[0]).toUpperCase() : v[0]).join('');
      v.LABEL = labelFormat;
      if (labelFormat === 'MeC') v.LABEL = 'MC';
      if (labelFormat === 'MeCI') v.LABEL = 'MeC';
      if (labelFormat === 'DdD') v.LABEL = 'DD';
      if (labelFormat === 'DDF') v.LABEL = 'DF';
      if (labelFormat === 'TdD') v.LABEL = 'TD';
      if (labelFormat === 'TDC') v.LABEL = 'TC';
      if (labelFormat === 'TDC') v.LABEL = 'TC';
      if (labelFormat === 'DdG') v.LABEL = 'D';
      if (labelFormat === 'TdG') v.LABEL = 'TG';
      if (labelFormat === 'TGC') v.LABEL = 'TC';
      if (labelFormat === 'QdG') v.LABEL = 'Q';
      if (labelFormat === 'QdG') v.LABEL = 'Q';
      if (labelFormat === 'S5A7') v.LABEL = '7';
      if (labelFormat === 'S5') v.LABEL = '5';
      if (labelFormat === 'S5A6') v.LABEL = '6';
      if (labelFormat === 'S5A8') v.LABEL = '8';
      const prizesFormat = formatPremio(v);
      console.log('prizesFormat', prizesFormat);
      return {
        ...v,
        id: v.ID_MODAL,
        label: 'label',
        value: v,
        text: v.DS_MODAL,
        modalityPrizeFormat: prizesFormat
      };
    });
    return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.orderBy)(formatLabel, e => e.COL_GROUP);
  },
  apostaLoterias: state => {
    // para realizar aposta
    let dados = state.loterias;
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_1__.size)(dados)) return [];
    dados = dados.flat();
    return dados.filter(v => v.DS_LOT !== 'Todas');
  },
  listProdutosSelect: state => state.produtos?.map(it => ({
    text: it.name.replaceAll('_', ' '),
    value: it.id
  })),
  listModalitiesSelect: state => state.modalidades?.map(it => ({
    text: it.NO_MODAL.replaceAll('_', ' '),
    value: it.ID_MODAL
  })),
  permutacoes: state => state.permutacoes
};
/* harmony default export */ __webpack_exports__["default"] = ({
  state,
  actions,
  mutations,
  getters,
  namespaced: true
});

//# sourceURL=webpack://plataforma/./src/store/modules/listagemProdutos.js?